# IG Ratio

*by Oeng Kimchour*

Reads the likes and views off an Instagram profile grid, then ranks the posts by **likes ÷ views** — best engagement at the top. Filter to photos only or reels only with one tap.

## Install

1. Open `chrome://extensions` and turn on **Developer mode** (top right).
2. Click **Load unpacked** and pick the **`extension`** folder.
4. Open any Instagram profile on desktop web — the main grid, the **Reels** tab, or **Tagged**. A **Post performance** button appears bottom right.

**After installing or updating, refresh any Instagram tab that was already open.** The part that collects the counts has to be running before the page loads.

Chrome, Edge, Brave, Arc — anything Chromium.

The extension asks for access to `claude.ai` as well as Instagram. That's only for the **Send to Claude** button; nothing is read from your Claude conversations.

## Two modes

**On a profile** — the grid, the Reels tab or Tagged — you get the full panel: read everything, rank it, filter, download in bulk.

**On the feed** — the home feed, the Reels feed, Explore, or a single post page — controls appear on each post instead, in the top-right of its own header. They stay hidden until you hover the post, because that's when you're deciding about it.

| Button | What it does |
| --- | --- |
| Eye | Preview the post without leaving the feed |
| Download | Save that one post straight away |
| Keep | Add it to a collection |

Kept posts pile up behind a small counter in the bottom-right corner. Click that and the panel opens on them — same sorting, same selection, same ZIP and CSV as a profile read. Filenames include the author, since the collection spans accounts.

The feed's own responses carry more than the profile grid does — caption, video, author and date all arrive with the post — so a capture usually needs no extra lookup at all.

If they don't arrive, a capture still works. Counts are read off the page, and the media id is decoded from the post's shortcode, which is that id written in base64 — so the post can be looked up even when the feed told us nothing. Exact counts from that lookup replace the rounded figures on screen, since the page only ever renders "1.1K".

Kept posts survive moving between feed pages. Opening a profile grid starts a fresh set.

## Using it

- Set **Max** (60 is a good first run; 300 posts takes a few minutes).
- Press **Read grid**. The page scrolls itself while it reads each post. Leave the mouse alone during a read — a real hover can land on the wrong tile.
- Press it again to stop. Whatever was read stays on screen.
- **All / Photos / Reels** filters by post type, instantly, no re-reading needed.
- **Sort** offers two groups: by performance (Likes / views, Likes, Views) or by date posted (Newest, Oldest).
- The summary strip shows how many posts, the median, and your best — so you know what "good" looks like on this account.
- The **eye** on each row opens a preview: the actual photo, or the reel playing, with the caption and counts underneath.
- The **refresh** button next to Read grid reads the grid again while keeping your sort, tab and ticked posts — for checking numbers on a post you just published.
- The download icon in the toolbar saves the table as CSV.
- **Tick posts** to select them, or use **Select all** to take everything currently listed. Change the tab and Select all applies to that tab instead.
- **Download ZIP** bundles what you picked. Reels come as video, photos as images.
- **Reel quality** picks which rendition to pull: best, medium, or smallest.

Inside a preview there's a **Download** button for that single post, plus three copy buttons:

| Button | What lands on your clipboard |
| --- | --- |
| Copy image | The picture itself, ready to paste anywhere |
| Copy caption | The whole caption text, nothing trimmed |
| Copy both | The picture and the caption together in one paste |

**How "Copy both" works.** A clipboard entry isn't a list of things to paste — it's one thing described several ways, and the app you paste into picks the version it understands. So an entry holding only an image and some text gives a rich editor the image and nothing else.

The fix is a third version, written as HTML, containing the picture and the caption in one fragment. Anywhere that accepts formatted content — Docs, Word, Notion, an email — pastes both together. A plain text box still gets the caption on its own, and an image-only target still gets the picture.

For a reel, "image" means the cover frame. If Instagram's CDN blocks the copy, the button says **Link copied** and you get the image URL instead.

Sorting by date doesn't hide the numbers — each row still shows its ratio, with the post date on the line underneath. So "newest first" answers *how has my engagement been trending lately*, not just *what did I post last*.

If a post's timestamp never arrived, the tool falls back to grid position, which is already newest-first, and says so under the sort box.

In a preview, the arrows (or ← and →) page through the list in the order you sorted it, so you can flick through your top performers without leaving the panel. **Esc** closes it, and **Open on Instagram** takes you to the real post.

Your filter, sort and appearance choices are remembered for next time.

The big number on each row is the ratio as a percentage. 9.86% means about 10 likes for every 100 views. The bar underneath shows that post against your best one.

## Downloads

**Reels always download as video.** If the archive would otherwise contain a cover image instead of the clip, that post is skipped and counted in the status bar rather than quietly swapped.

Files are named from the post itself, so they stay recognisable in a folder:

```
2025-10-13 - First line of the caption - SHORT000.mp4
```

Date, then the caption's first line, then the shortcode to keep every name unique. The ZIP stores files rather than compressing them — photos and videos are already compressed, so there's nothing to gain and it avoids dragging in a compression library.

**The reels tab sends a stripped-down feed** — counts and a thumbnail, no video URL, no caption, no date. So before fetching anything, the tool asks Instagram's own media endpoint for each post it needs, using the same headers the page signs its own calls with (watched as they go past, never hardcoded). That's what fills in the video, the caption for the filename, and the date. You'll see *Looking up 4 of 20* in the status bar while it does.

Everything is fetched in the browser as you, using the same access the page already has. Some Instagram CDN responses refuse a cross-origin read; those posts are skipped and the status bar says how many. A single download that gets blocked opens in a tab instead, where the browser can save it normally.

Large selections are held in memory while the archive is built, so a hundred reels at best quality is a lot to ask of a tab. Work in batches if it struggles.

## Where the numbers come from

Instagram's grid markup doesn't contain like counts — not in the tile, not on hover. Trying to read them off the page gets you nothing.

So the extension listens instead. Instagram's own app fetches these numbers to render your profile, and `net.js` sits in the page and reads those replies as they come back. It never makes a request of its own, which is why there are no tokens or API keys involved and nothing to break when Instagram rotates its endpoints. Whatever the page can see, the tool sees.

Practical effect: **counts arrive as posts load.** Press Read grid, the page scrolls itself, and each batch brings its numbers with it. If a post shows no counts, scroll past it once and read again.

If nothing at all comes through, the panel tells you to refresh — that means the page loaded before the extension did.

## Sending a post to Claude

**Send to Claude** puts the picture and the full caption into Claude's message box for you. There's a button in the preview card and a small arrow icon on each post in the feed, so it's one click from wherever you are.

It finds your Claude tab rather than making a new one every time — whichever claude.ai tab you looked at most recently. If none is open it opens one. Either way the tab comes to the front so you can see what landed and type your own instruction before sending.

On a carousel it sends the slide you're looking at, not the first one.

**Why it pastes rather than types.** Claude's message box is a rich text editor that keeps its own model of the document, so text written straight into the page is ignored or wiped on the next keystroke. A paste event goes through the editor's own code, and it's also how the attachment pipeline picks up a file. That's the only route that works for both at once.

**Images are shrunk to 1600px on the long edge** before travelling between tabs. A full-size Instagram photo is several megabytes, which is slow through the extension's messaging channel and more resolution than a chat needs.

### When it doesn't work

This drives another site's interface, which makes it the most fragile part of the extension. Claude's layout can change, and when it does this breaks before anything else here does.

It fails softly and tells you which half landed:

- *Sent* — both went in.
- *Sent, partly* — the status bar says which half is missing.
- *Couldn't send* — nothing went in; the status bar says why.

If it stops working entirely, **Copy both** still puts the image and caption on your clipboard for a manual Ctrl+V. That path doesn't depend on Claude's markup at all, so it's the reliable fallback.

Reload your Claude tab after updating the extension, or it won't be listening.

## Carousels

A post with several slides is handled as several slides, not one image.

In the preview, arrows sit on the image itself, at its left and right edges, and the ← → keys do the same thing. They step through the slides first and only move on to the next post at either end — the way they behave on Instagram. An arrow disappears when there's nowhere further to go in that direction.

Up to ten slides you get dots underneath, and you can click one to jump straight there. Past that the dots stop being aimable, so it shows a plain **7 / 13** count instead.

The heading reads *Image 2 of 3*, and **Download**, **Copy image** and **Copy both** all act on the slide you're looking at.

Opening a post at a particular slide (`instagram.com/p/CODE/?img_index=2`) starts the preview on that slide.

In the list, a carousel is badged `×3` instead of IMG or REEL. Selecting one for a ZIP gets every slide, each numbered:

```
2026-08-08 - @account - First line of the caption - DboXilRFIKk - (1 of 3).jpg
2026-08-08 - @account - First line of the caption - DboXilRFIKk - (2 of 3).jpg
2026-08-08 - @account - First line of the caption - DboXilRFIKk - (3 of 3).mp4
```

A video slide inside a carousel comes down as `.mp4`, an image slide as `.jpg`.

## Reel playback

The preview plays the smallest rendition so it starts instead of buffering. Those direct URLs are signed and expire, and the profile feed doesn't always carry them at all — so if one fails, the player swaps itself for Instagram's own embed, which always works and needs no credentials. You shouldn't ever see a dead player.

## About photos

Instagram shows view counts on the grid for reels and videos. Photos and carousels usually only show likes and comments on hover.

So when you filter to **Photos**, if no view counts came through, the tool says so and sorts by likes instead. If your grid does show views on photos, it picks them up automatically and sorts by ratio as normal. Nothing to configure either way.

In the **All** view, posts with both numbers come first ranked by ratio, and posts missing a view count sit below ranked by likes.

## Limits, honestly

- **Grid views are play counts**, not the reach number in your Insights. Use it to rank posts against each other, not for reporting.
- **A post has to load before its counts exist.** Nothing is fetched behind the scenes, so a post you never scrolled past has no numbers. Read again after scrolling further.
- **Refresh after installing or updating.** An Instagram tab opened beforehand has already fetched its counts and missed them.
- **Private profiles you can't view** give nothing, same as in the browser.
- **A preview needs the post to have loaded**, same as the counts. Reels play the low-quality version on purpose so they start instantly instead of buffering.
- Slow connection? Raise `SCROLL_MS` at the top of `content.js` so each batch has longer to arrive.

## About the interface

It's built to read as an instrument rather than an accessory. Three ideas hold it together:

**Solid surfaces.** Nothing translucent, nothing floating. A docked panel with one hairline border sits in the workspace instead of hovering over it.

**Every figure is monospaced and tabular.** Digits line up down the column, so two ratios can be compared by eye without reading them.

**The ranking bar lives behind each row**, the way a spreadsheet draws a data bar, with a marker at its end. The list becomes its own chart — you can see the drop-off from your best post to your worst without looking at a single number.

Motion is short and flat: 140ms, no bounce. Rows travel to their new position when you re-sort so you can follow one, and that's about the extent of it. Reduce Motion turns it off.

The button beside the close X cycles Auto → Light → Dark. **Auto reads the page's own background**, not your operating system — Instagram has its own dark mode setting, so following the OS gets it wrong for anyone whose two settings disagree. If you switch Instagram's theme mid-session, the panel follows within a second.

## Where things are in the code

| Thing | Where |
| --- | --- |
| Wait timings | `HOVER_MS`, `SCROLL_MS` at the top of `content.js` |
| Number parsing (12.3K → 12300) | `parseCount()` |
| Photo vs reel detection | `classify()` |
| Watching Instagram's responses | `harvest()`, `digest()` in `net.js` |
| Merging those counts into rows | `applyNet()` |
| Preview lightbox | `openPreview()`, `showShot()` |
| Copy buttons | `runCopy()`, `copyBundle()` |
| Selection and downloads | `toggleAll()`, `saveOne()`, `downloadZip()` |
| Download filenames | `fileName()` |
| Video quality choice | `videoUrl()` |
| Per-post lookup | `lookupMedia()`, `absorb()` |
| Controls on each post | `mountInline()`, `postFromArticle()` |
| Reading counts off the page | `readIcons()` |
| Media id from a shortcode | `pkFromShortcode()` |
| Carousel slides | `pickSlides()` in `net.js`, `viewOf()`, `mountSlideControls()` |
| Send to Claude | `sendToClaude()`, `background.js`, `claude.js` |
| Finding the Claude tab | `findClaudeTab()` in `background.js` |
| Putting text in the editor | `insertText()`, `insertImage()` in `claude.js` |
| Archive writer | `zip.js` |
| Theme detection | `pageIsDark()` |
| Licence checking | `license.js`, `checkLicence()` |
| Update check | `checkUpdate()`, `readVersionFile()` in `background.js` |
| Repo it looks at | `REPO` in `background.js` |
| Cutting a release | `release.py` |
| Key issuing | `licence-generator.html` |
| Hover fallback for stragglers | `readIcons()`, `readTile()` |
| Scroll and collect loop | `scan()` |
| Ratio and sort order | `withRatio()`, `ranked()`, `BY_DATE` |
| Colours, spacing, motion | tokens at the top of `ui.css` |


## Updates

Installed copies read one small file from the repo's main branch:

```
https://raw.githubusercontent.com/Kimchour/IG-ratio/main/version.json
```

That file *is* the release announcement. Nothing goes through GitHub's release machinery, there's no API rate limit to hit, and pushing a new version.json is what makes every installed copy notice.

### Cutting a release

```
python3 release.py 4.4.0 "What changed in this one"
```

It bumps `extension/manifest.json`, builds `ig-ratio-4.4.0.zip` (a fresh name every release, so nobody's browser hands them the previous one), writes `version.json`, and prints the three files to commit. Push them to main and you're done — installed copies see it within about a minute.

It refuses to run if the version isn't higher than the current one, because installed copies would silently ignore it.

### What people see

The footer shows the version they're running. It checks quietly twice a day, and they can click it to check immediately:

| It says | Meaning |
| --- | --- |
| `v4.3.0 · latest` | They're current |
| **Update now** | Newer version out — a notice appears in the panel with your release notes and a download button |
| `v4.3.0 · no version file` | No version.json in the repo yet |
| `v4.3.0 · check failed` | The tooltip says whether GitHub was unreachable or the file is malformed |

The notice tells them to unzip over their existing folder and press reload — never to uninstall. **Their licence key and settings live in the browser's storage for instagram.com, not in the extension folder**, so replacing the files leaves both untouched. Uninstalling would lose them.

### What it can't do

It can't install the update. Chrome only auto-updates extensions from the Web Store; an unpacked folder has to be replaced by hand. The button opens the download and the notice explains the two steps. A button claiming more than that would be lying.

If you ever want silent auto-updates, the route is a self-hosted `.crx` plus an `update.xml` and a Windows registry policy — the same arrangement you chose for PromptSnap.

## Subscriptions

The tool runs free for **7 days**, then asks for a key. Reading and downloading are what's gated; the panel itself always opens.

### Issuing keys

Open `licence-generator.html` in a browser. Enter the customer, pick Monthly, Quarterly, Yearly or Lifetime, press **Generate key**, send them the text. The end date fills in automatically from the plan and you can override it. Everything issued is listed underneath and exports to CSV, so you have a customer list without running anything.

The page works offline and sends nothing anywhere.

### How keys work

Keys are signed with ECDSA P-256. The generator holds the private key; the extension carries only the public half. That means a customer with a copy of the extension **cannot mint keys** — they can only check them. Each key carries the holder's name, plan and end date, all covered by the signature, so none of it can be edited without breaking it.

### What this does and doesn't protect

Worth being straight with you, because it affects how you price and sell this.

**It stops:** key sharing between customers being undetectable, forged keys, edited expiry dates, and a lapsed subscription continuing to work.

**It doesn't stop:** a determined person opening `license.js` and deleting the check. An unpacked extension is plain JavaScript on someone else's computer, and no client-side scheme can survive that — not this one, not an obfuscated one. The same is true of the trial: clearing site data resets it, and winding the system clock back extends a licence.

If the revenue matters enough to defend properly, the fix is a server: the extension sends the key to an endpoint you run, the server answers, and the answer is what unlocks the tool. Then deleting the check locally gains nothing because the tool has no data without your reply. That's a bigger build — it needs hosting, a domain and payment plumbing — but it's the only version that actually holds.

For selling to a modest number of customers who mostly won't try, what's here is reasonable and costs you nothing to run.

### Rotating your signing key

Under **Signing key → Rotate the key pair** in the generator. It invalidates every key already issued, so only do it if the private key leaks. Afterwards paste the new public key into `PUBLIC_JWK` in `extension/license.js`, replace `PRIVATE_JWK` in the generator, and ship the update.

### Never send the generator to a customer

`licence-generator.html` contains your signing key. It sits outside the `extension` folder on purpose — zip and ship `extension/` on its own and the generator can't go out by accident.
