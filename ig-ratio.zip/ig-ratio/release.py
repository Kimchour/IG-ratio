#!/usr/bin/env python3
"""Cut a release of IG Ratio.

    python3 release.py 4.4.0 "What changed in this one"

Does four things, in the order that keeps them consistent:

  1. sets "version" in extension/manifest.json
  2. builds extension/ into ig-ratio-<version>.zip  (a unique name per release,
     so a browser or a download folder never serves you the previous one)
  3. writes version.json, which is what installed copies read to notice the
     release
  4. tells you what to commit

Run it from the folder this file is in. The private licence generator is never
included in the zip — only extension/ goes in.
"""

import json
import os
import re
import subprocess
import sys
import zipfile
from datetime import date

HERE = os.path.dirname(os.path.abspath(__file__))
EXT = os.path.join(HERE, "extension")
REPO = "Kimchour/IG-ratio"


def fail(message):
    print(f"error: {message}")
    raise SystemExit(1)


def main():
    if len(sys.argv) < 2:
        fail('usage: python3 release.py <version> ["release notes"]')

    version = sys.argv[1].lstrip("vV")
    if not re.fullmatch(r"\d+\.\d+\.\d+", version):
        fail(f"version should look like 4.4.0, not {version!r}")

    notes = sys.argv[2] if len(sys.argv) > 2 else ""

    manifest_path = os.path.join(EXT, "manifest.json")
    if not os.path.isfile(manifest_path):
        fail("can't find extension/manifest.json — run this from the project folder")

    manifest = json.load(open(manifest_path))
    previous = manifest.get("version", "0.0.0")

    def parts(v):
        return [int(n) for n in v.split(".")]

    if parts(version) <= parts(previous):
        fail(f"{version} isn't newer than the current {previous} — installed copies would ignore it")

    # 1. manifest
    manifest["version"] = version
    json.dump(manifest, open(manifest_path, "w"), indent=2)
    print(f"manifest      {previous} -> {version}")

    # 2. zip, named for this release only
    zip_name = f"ig-ratio-{version}.zip"
    zip_path = os.path.join(HERE, zip_name)
    if os.path.exists(zip_path):
        os.remove(zip_path)

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as bundle:
        for folder, _, files in os.walk(EXT):
            for name in sorted(files):
                full = os.path.join(folder, name)
                inside = os.path.join("extension", os.path.relpath(full, EXT))
                bundle.write(full, inside)
    size = os.path.getsize(zip_path) / 1024
    print(f"built         {zip_name}  ({size:.0f} KB)")

    # 3. version.json — the file installed copies actually read
    version_file = {
        "version": version,
        "date": date.today().isoformat(),
        "download": f"https://github.com/{REPO}/raw/main/{zip_name}",
        "notes": notes,
    }
    json.dump(version_file, open(os.path.join(HERE, "version.json"), "w"), indent=2)
    print("wrote         version.json")

    if not notes:
        print("\nnote: no release notes given, so the update notice will show only the version.")

    print(
        "\nNow commit these three to the main branch:\n"
        f"    git add extension/manifest.json version.json {zip_name}\n"
        f'    git commit -m "Release {version}"\n'
        "    git push\n"
        "\nInstalled copies notice within about a minute. Nothing else is needed —\n"
        "version.json in the main branch is the whole release mechanism."
    )

    # Old release zips pile up in the repo; point them out rather than deleting
    # anything, since their download links may still be live somewhere.
    old = sorted(f for f in os.listdir(HERE)
                 if f.startswith("ig-ratio-") and f.endswith(".zip") and f != zip_name)
    if old:
        print("\nOlder zips still in the folder: " + ", ".join(old))


if __name__ == "__main__":
    main()
