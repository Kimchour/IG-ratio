#!/usr/bin/env python3
"""Cut a release of IG Ratio.

    python3 release.py 4.4.0 --added "Thing you added" --fixed "Thing you fixed"

Does four things, in the order that keeps them consistent:

  1. sets "version" in extension/manifest.json
  2. builds extension/ into ig-ratio-<version>.zip  (a unique name per release,
     so a browser or a download folder never serves you the previous one)
  3. writes version.json, which is what installed copies read to notice the
     release
  4. tells you what to commit

Run it from the folder this file is in. The private licence generator is never
included in the zip — only extension/ goes in.
"""

import json
import os
import re
import subprocess
import sys
import zipfile
from datetime import date

HERE = os.path.dirname(os.path.abspath(__file__))
EXT = os.path.join(HERE, "extension")
REPO = "Kimchour/IG-ratio"


def fail(message):
    print(f"error: {message}")
    raise SystemExit(1)


def main():
    if len(sys.argv) < 2:
        fail('usage: python3 release.py <version> [--added "..."] [--fixed "..."]')

    version = sys.argv[1].lstrip("vV")
    if not re.fullmatch(r"\d+\.\d+\.\d+", version):
        fail(f"version should look like 4.4.0, not {version!r}")

    # Repeat --added / --fixed once per line of the changelog.
    added, fixed, notes = [], [], ""
    bucket = None
    for token in sys.argv[2:]:
        if token == "--added":
            bucket = added
        elif token == "--fixed":
            bucket = fixed
        elif token == "--notes":
            bucket = None
        elif bucket is not None:
            bucket.append(token)
        else:
            notes = token

    manifest_path = os.path.join(EXT, "manifest.json")
    if not os.path.isfile(manifest_path):
        fail("can't find extension/manifest.json — run this from the project folder")

    manifest = json.load(open(manifest_path))
    previous = manifest.get("version", "0.0.0")

    def parts(v):
        return [int(n) for n in v.split(".")]

    if parts(version) <= parts(previous):
        fail(f"{version} isn't newer than the current {previous} — installed copies would ignore it")

    # 1. manifest
    manifest["version"] = version
    json.dump(manifest, open(manifest_path, "w"), indent=2)
    print(f"manifest      {previous} -> {version}")

    # 2. zip, named for this release only
    zip_name = f"ig-ratio-{version}.zip"
    zip_path = os.path.join(HERE, zip_name)
    if os.path.exists(zip_path):
        os.remove(zip_path)

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as bundle:
        for folder, _, files in os.walk(EXT):
            for name in sorted(files):
                full = os.path.join(folder, name)
                inside = os.path.join("extension", os.path.relpath(full, EXT))
                bundle.write(full, inside)
    size = os.path.getsize(zip_path) / 1024
    print(f"built         {zip_name}  ({size:.0f} KB)")

    # 3. version.json — the file installed copies actually read.
    #    The release being replaced moves into history so that anyone still on
    #    it can see what their own version contained, not just what's coming.
    version_path = os.path.join(HERE, "version.json")
    history = []
    if os.path.isfile(version_path):
        try:
            old = json.load(open(version_path))
            history = old.get("history", []) or []
            if old.get("version"):
                history.insert(0, {
                    "version": old["version"],
                    "date": old.get("date", ""),
                    "added": old.get("added", []),
                    "fixed": old.get("fixed", []),
                    "notes": old.get("notes", ""),
                })
        except Exception:
            print("note: existing version.json couldn't be read, so history starts fresh")

    version_file = {
        "version": version,
        "date": date.today().isoformat(),
        "download": f"https://github.com/{REPO}/raw/main/{zip_name}",
        "added": added,
        "fixed": fixed,
        "history": history[:20],
    }
    if notes:
        version_file["notes"] = notes
    json.dump(version_file, open(version_path, "w"), indent=2)
    print(f"wrote         version.json  ({len(added)} added, {len(fixed)} fixed, "
          f"{len(history[:20])} in history)")

    if not added and not fixed and not notes:
        print("\nnote: no changelog given, so the update window will show the version alone.")

    print(
        "\nNow commit these three to the main branch:\n"
        f"    git add extension/manifest.json version.json {zip_name}\n"
        f'    git commit -m "Release {version}"\n'
        "    git push\n"
        "\nInstalled copies notice within about a minute. Nothing else is needed —\n"
        "version.json in the main branch is the whole release mechanism."
    )

    # Old release zips pile up in the repo; point them out rather than deleting
    # anything, since their download links may still be live somewhere.
    old = sorted(f for f in os.listdir(HERE)
                 if f.startswith("ig-ratio-") and f.endswith(".zip") and f != zip_name)
    if old:
        print("\nOlder zips still in the folder: " + ", ".join(old))


if __name__ == "__main__":
    main()
