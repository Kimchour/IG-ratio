/* IG Ratio — sound.
 *
 * Short tones built with the Web Audio API rather than shipped as files: three
 * blips would otherwise be a few hundred kilobytes of assets for something
 * that lasts a fifth of a second.
 *
 * The rules that keep this from being annoying:
 *   - nothing plays until the person has clicked something, which is also what
 *     browsers require before audio is allowed at all
 *   - one tone per event, never overlapping, never longer than ~400ms
 *   - sine waves with a soft attack and a long tail, so it reads as a chime
 *     rather than a beep
 *   - a single toggle turns the lot off, and that choice is remembered
 */

(() => {
  "use strict";
  if (window.__igRatioSound) return;

  const STORE = "igratio:sound";
  let context = null;
  let enabled = true;

  try {
    const saved = localStorage.getItem(STORE);
    if (saved !== null) enabled = saved === "1";
  } catch (_) { /* private mode: leave it on */ }

  function ready() {
    if (!enabled) return null;
    if (!context) {
      const Ctor = window.AudioContext || window.webkitAudioContext;
      if (!Ctor) return null;
      context = new Ctor();
    }
    // Browsers park the context until a gesture; a click has always happened
    // by the time anything here is called.
    if (context.state === "suspended") context.resume().catch(() => {});
    return context;
  }

  /** One note. `at` is an offset in seconds from now. */
  function note(freq, { at = 0, length = 0.18, gain = 0.05, type = "sine" } = {}) {
    const ctx = ready();
    if (!ctx) return;

    const start = ctx.currentTime + at;
    const osc = ctx.createOscillator();
    const level = ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, start);

    // A ramp rather than a straight start, or it clicks.
    level.gain.setValueAtTime(0.0001, start);
    level.gain.exponentialRampToValueAtTime(gain, start + 0.012);
    level.gain.exponentialRampToValueAtTime(0.0001, start + length);

    osc.connect(level).connect(ctx.destination);
    osc.start(start);
    osc.stop(start + length + 0.02);
  }

  const TONES = {
    // Two notes rising: something arrived.
    update() {
      note(659.25, { at: 0, length: 0.14 });          // E5
      note(987.77, { at: 0.11, length: 0.26, gain: 0.045 }); // B5
    },
    // One soft note: nothing to do.
    current() {
      note(587.33, { at: 0, length: 0.2, gain: 0.035 }); // D5
    },
    // Two notes falling, quieter: it didn't work.
    fail() {
      note(392.0, { at: 0, length: 0.13, gain: 0.04 }); // G4
      note(311.13, { at: 0.1, length: 0.22, gain: 0.035 }); // D#4
    },
    // A short tick for a finished job — a download, a send.
    done() {
      note(880.0, { at: 0, length: 0.11, gain: 0.04 }); // A5
      note(1174.66, { at: 0.08, length: 0.18, gain: 0.03 }); // D6
    },
  };

  window.__igRatioSound = {
    play(name) {
      const tone = TONES[name];
      if (tone && enabled) {
        try { tone(); } catch (_) { /* audio is never worth an error */ }
      }
    },
    get enabled() { return enabled; },
    set(on) {
      enabled = !!on;
      try { localStorage.setItem(STORE, enabled ? "1" : "0"); } catch (_) {}
      if (enabled) this.play("current"); // so the toggle demonstrates itself
    },
  };
})();
