/* IG Ratio — page-world listener.
 *
 * The grid markup no longer carries like counts, so reading tiles gets us
 * nothing. Instagram's own app already fetches these numbers over the network
 * to render the page, so this script sits in the page world, watches those
 * responses go by, and forwards anything post-shaped to the extension.
 *
 * Nothing is requested here. It only reads replies to calls Instagram makes
 * on its own, which is why there are no query hashes or tokens to keep up
 * with — whatever the app can see, this sees.
 */

(() => {
  "use strict";
  if (window.__igRatioNet) return;
  window.__igRatioNet = true;

  const WATCH = /\/graphql|\/api\/v1\//;
  const MAX_NODES = 60000; // stop walking absurd payloads

  const num = (v) => (typeof v === "number" && isFinite(v) ? v : null);

  // Candidates come widest-first, so the head is the preview and the tail is
  // the little list thumbnail.
  function pickImages(o) {
    const c = o.image_versions2 && o.image_versions2.candidates;
    if (Array.isArray(c) && c.length) {
      return { preview: c[0].url || null, thumb: c[c.length - 1].url || c[0].url || null };
    }
    const one = o.thumbnail_src || o.display_url || null;
    return { preview: one, thumb: one };
  }

  /* A carousel keeps its slides in carousel_media, each one a small media
   * object of its own with its own images and, for video slides, its own
   * renditions. Without this only the first slide is ever seen. */
  function pickSlides(o) {
    const items = o.carousel_media;
    if (!Array.isArray(items) || items.length < 2) return null;
    return items.map((item, i) => {
      const img = pickImages(item);
      return {
        n: i + 1,
        kind: item.media_type === 2 || item.video_versions ? "reel" : "photo",
        preview: img.preview,
        thumb: img.thumb,
        videos: pickVideos(item),
      };
    });
  }

  // Every rendition, widest first, so the download can offer a quality choice.
  function pickVideos(o) {
    const v = o.video_versions;
    if (Array.isArray(v) && v.length) {
      const list = v
        .map((x) => ({ url: x.url, width: x.width || 0, height: x.height || 0 }))
        .filter((x) => x.url)
        .sort((a, b) => b.width - a.width);
      if (list.length) return list;
    }
    return o.video_url ? [{ url: o.video_url, width: 0, height: 0 }] : null;
  }

  function pickCaption(o) {
    let t = o.caption && typeof o.caption.text === "string" ? o.caption.text : null;
    if (!t) {
      const e = o.edge_media_to_caption && o.edge_media_to_caption.edges;
      if (Array.isArray(e) && e[0] && e[0].node) t = e[0].node.text;
    }
    return typeof t === "string" ? t.slice(0, 2200) : null;
  }

  function kindOf(o) {
    if (o.product_type === "clips" || o.product_type === "igtv") return "reel";
    if (o.media_type === 2 || o.is_video === true) return "reel";
    return "photo";
  }

  // Walk the response looking for anything that has a shortcode and a count.
  function harvest(node, out, budget) {
    if (!node || typeof node !== "object" || budget.n > MAX_NODES) return;
    budget.n++;

    if (Array.isArray(node)) {
      for (const item of node) harvest(item, out, budget);
      return;
    }

    const code = node.code || node.shortcode;
    if (typeof code === "string" && code.length >= 5 && !code.includes(" ")) {
      const likes =
        num(node.like_count) ??
        num(node.edge_liked_by && node.edge_liked_by.count) ??
        num(node.edge_media_preview_like && node.edge_media_preview_like.count);
      const views =
        num(node.play_count) ??
        num(node.ig_play_count) ??
        num(node.view_count) ??
        num(node.video_view_count);
      const comments =
        num(node.comment_count) ??
        num(node.edge_media_to_comment && node.edge_media_to_comment.count) ??
        num(node.edge_media_preview_comment && node.edge_media_preview_comment.count);

      if (likes != null || views != null) {
        const img = pickImages(node);
        const slides = pickSlides(node);
        out.push({
          code, likes, views, comments,
          pk: node.pk != null ? String(node.pk).split("_")[0]
            : typeof node.id === "string" ? node.id.split("_")[0] : null,
          author: (node.user && node.user.username) || (node.owner && node.owner.username) || null,
          time: num(node.taken_at) ?? num(node.taken_at_timestamp) ?? num(node.device_timestamp) ?? null,
          kind: kindOf(node),
          thumb: img.thumb,
          preview: img.preview,
          videos: pickVideos(node),
          slides,
          caption: pickCaption(node),
        });
      }
    }

    for (const key in node) {
      const v = node[key];
      if (v && typeof v === "object") harvest(v, out, budget);
    }
  }

  /* This script starts with the document; the extension's own script starts
   * when the document goes idle. Anything Instagram fetched in between would
   * otherwise be harvested into a void — which is exactly what happens on the
   * home feed, where the first batch of posts arrives immediately. So keep
   * every item and re-send the lot once the other side says it is listening. */
  const harvested = new Map();

  function remember(items) {
    for (const item of items) {
      if (!item || !item.code) continue;
      const prev = harvested.get(item.code);
      harvested.set(item.code, prev ? { ...prev, ...item } : item);
    }
  }

  const tryParse = (text) => { try { return JSON.parse(text); } catch (_) { return null; } };

  function digest(text) {
    if (!text || typeof text !== "string" || text.length < 20) return;
    const first = text[0];
    if (first !== "{" && first !== "[") return;

    let data = tryParse(text);
    if (!data) {
      /* The home feed streams: the reply is several JSON documents, one per
       * line, rather than one. Parsing the whole body fails, which is why
       * feed posts came through with no counts, caption or date. */
      const documents = [];
      for (const line of text.split("\n")) {
        const trimmed = line.trim();
        if (!trimmed || (trimmed[0] !== "{" && trimmed[0] !== "[")) continue;
        const doc = tryParse(trimmed);
        if (doc) documents.push(doc);
      }
      if (!documents.length) return;
      data = documents;
    }

    const out = [];
    harvest(data, out, { n: 0 });
    if (!out.length) return;
    remember(out);
    window.postMessage({ source: "ig-ratio-net", items: out }, "*");
  }

  window.addEventListener("message", (e) => {
    if (e.source !== window || !e.data || e.data.source !== "ig-ratio-ready") return;
    if (harvested.size) {
      window.postMessage({ source: "ig-ratio-net", items: [...harvested.values()] }, "*");
    }
    if (lastSent) window.postMessage({ source: "ig-ratio-headers", headers: JSON.parse(lastSent) }, "*");
  });

  /* --------------------------------------------------------------- headers

  Instagram's private endpoints want an app id and a couple of companion
  headers. Rather than hardcode values that go stale, watch what the page
  itself sends and reuse exactly that. */

  const WANTED = ["x-ig-app-id", "x-asbd-id", "x-ig-www-claim", "x-csrftoken"];
  let lastSent = "";

  function noteHeaders(map) {
    if (!map || !map["x-ig-app-id"]) return;
    const json = JSON.stringify(map);
    if (json === lastSent) return;
    lastSent = json;
    window.postMessage({ source: "ig-ratio-headers", headers: map }, "*");
  }

  function collectHeaders(source) {
    const out = {};
    if (!source) return out;
    try {
      if (typeof source.forEach === "function" && typeof source.get === "function") {
        source.forEach((v, k) => { if (WANTED.includes(k.toLowerCase())) out[k.toLowerCase()] = v; });
      } else if (Array.isArray(source)) {
        for (const [k, v] of source) if (WANTED.includes(String(k).toLowerCase())) out[String(k).toLowerCase()] = v;
      } else {
        for (const k in source) if (WANTED.includes(k.toLowerCase())) out[k.toLowerCase()] = source[k];
      }
    } catch (_) {}
    return out;
  }

  /* ------------------------------------------------------------------ fetch */

  const nativeFetch = window.fetch;
  window.fetch = function (...args) {
    const result = nativeFetch.apply(this, args);
    try {
      const input = args[0];
      const url = typeof input === "string" ? input : (input && input.url) || "";
      if (WATCH.test(url)) {
        noteHeaders({
          ...collectHeaders(input && input.headers),
          ...collectHeaders(args[1] && args[1].headers),
        });
        result.then((res) => { res.clone().text().then(digest).catch(() => {}); }).catch(() => {});
      }
    } catch (_) { /* never let the tap break the page's own request */ }
    return result;
  };

  /* ------------------------------------------------------------------- xhr */

  const nativeOpen = XMLHttpRequest.prototype.open;
  const nativeSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this.__igRatioUrl = url;
    this.__igRatioHeaders = {};
    return nativeOpen.call(this, method, url, ...rest);
  };

  const nativeSetHeader = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.setRequestHeader = function (name, value) {
    try {
      if (WANTED.includes(String(name).toLowerCase())) {
        (this.__igRatioHeaders || (this.__igRatioHeaders = {}))[String(name).toLowerCase()] = value;
      }
    } catch (_) {}
    return nativeSetHeader.call(this, name, value);
  };

  XMLHttpRequest.prototype.send = function (...args) {
    try {
      if (WATCH.test(this.__igRatioUrl || "")) {
        noteHeaders(this.__igRatioHeaders);
        this.addEventListener("load", () => {
          try {
            if (this.responseType === "" || this.responseType === "text") digest(this.responseText);
            else if (this.responseType === "json") digest(JSON.stringify(this.response));
          } catch (_) {}
        });
      }
    } catch (_) {}
    return nativeSend.apply(this, args);
  };
})();
