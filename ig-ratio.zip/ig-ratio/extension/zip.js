/* IG Ratio — a small ZIP writer.
 *
 * Photos and videos are already compressed, so every entry is stored rather
 * than deflated. That removes the need for a compression library entirely and
 * costs nothing in file size worth having.
 */

(() => {
  "use strict";
  if (window.__igRatioZip) return;

  const CRC_TABLE = (() => {
    const t = new Uint32Array(256);
    for (let i = 0; i < 256; i++) {
      let c = i;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      t[i] = c >>> 0;
    }
    return t;
  })();

  function crc32(bytes) {
    let c = 0xffffffff;
    for (let i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 0xff] ^ (c >>> 8);
    return (c ^ 0xffffffff) >>> 0;
  }

  const dosTime = (d) => (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1);
  const dosDate = (d) => (Math.max(1980, d.getFullYear()) - 1980) << 9 | (d.getMonth() + 1) << 5 | d.getDate();

  // Names repeat inside one archive more often than you'd think.
  function unique(name, taken) {
    if (!taken.has(name)) { taken.add(name); return name; }
    const dot = name.lastIndexOf(".");
    const stem = dot > 0 ? name.slice(0, dot) : name;
    const ext = dot > 0 ? name.slice(dot) : "";
    let n = 2;
    while (taken.has(`${stem} (${n})${ext}`)) n++;
    const out = `${stem} (${n})${ext}`;
    taken.add(out);
    return out;
  }

  /**
   * @param {{name: string, blob: Blob, date?: Date}[]} entries
   * @returns {Promise<Blob>}
   */
  async function build(entries) {
    const enc = new TextEncoder();
    const parts = [];
    const central = [];
    const taken = new Set();
    let offset = 0;

    for (const entry of entries) {
      const bytes = new Uint8Array(await entry.blob.arrayBuffer());
      const name = enc.encode(unique(entry.name, taken));
      const crc = crc32(bytes);
      const when = entry.date instanceof Date && !isNaN(entry.date) ? entry.date : new Date();
      const time = dosTime(when);
      const date = dosDate(when);

      const local = new DataView(new ArrayBuffer(30));
      local.setUint32(0, 0x04034b50, true);
      local.setUint16(4, 20, true);      // version needed
      local.setUint16(6, 0x0800, true);  // UTF-8 names
      local.setUint16(8, 0, true);       // stored
      local.setUint16(10, time, true);
      local.setUint16(12, date, true);
      local.setUint32(14, crc, true);
      local.setUint32(18, bytes.length, true);
      local.setUint32(22, bytes.length, true);
      local.setUint16(26, name.length, true);
      local.setUint16(28, 0, true);
      parts.push(new Uint8Array(local.buffer), name, bytes);

      const dir = new DataView(new ArrayBuffer(46));
      dir.setUint32(0, 0x02014b50, true);
      dir.setUint16(4, 20, true);        // version made by
      dir.setUint16(6, 20, true);        // version needed
      dir.setUint16(8, 0x0800, true);
      dir.setUint16(10, 0, true);
      dir.setUint16(12, time, true);
      dir.setUint16(14, date, true);
      dir.setUint32(16, crc, true);
      dir.setUint32(20, bytes.length, true);
      dir.setUint32(24, bytes.length, true);
      dir.setUint16(28, name.length, true);
      dir.setUint32(42, offset, true);
      central.push(new Uint8Array(dir.buffer), name);

      offset += 30 + name.length + bytes.length;
    }

    const centralSize = central.reduce((n, c) => n + c.length, 0);
    const end = new DataView(new ArrayBuffer(22));
    end.setUint32(0, 0x06054b50, true);
    end.setUint16(8, entries.length, true);
    end.setUint16(10, entries.length, true);
    end.setUint32(12, centralSize, true);
    end.setUint32(16, offset, true);

    return new Blob([...parts, ...central, new Uint8Array(end.buffer)], { type: "application/zip" });
  }

  window.__igRatioZip = { build };
})();
