/* IG Ratio — the Claude side.
 *
 * Puts an image and a caption into the message box. It does that by handing
 * the editor a real paste event rather than writing into the DOM: Claude's
 * composer is a rich text editor that keeps its own model of the document, so
 * text poked directly into the HTML is ignored or thrown away on the next
 * keystroke. A paste is the one route that goes through the editor's own code,
 * and it is also how the attachment pipeline gets hold of a file.
 *
 * This drives another site's interface, so it is the most fragile part of the
 * extension. Everything here fails softly and reports back rather than
 * throwing, and the image is left on the clipboard so a manual paste always
 * remains possible.
 */

(() => {
  "use strict";
  if (window.__igRatioClaude) return;
  window.__igRatioClaude = true;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  function findComposer() {
    const candidates = [
      'div[contenteditable="true"].ProseMirror',
      'div[contenteditable="true"][role="textbox"]',
      "fieldset div[contenteditable='true']",
      'div[contenteditable="true"]',
    ];
    for (const selector of candidates) {
      const matches = [...document.querySelectorAll(selector)].filter((node) => {
        const box = node.getBoundingClientRect();
        return box.width > 120 && box.height > 12 && node.isContentEditable;
      });
      // The composer is the lowest box on screen; older messages sit above it.
      if (matches.length) {
        return matches.sort(
          (a, b) => b.getBoundingClientRect().top - a.getBoundingClientRect().top
        )[0];
      }
    }
    return null;
  }

  async function waitForComposer(timeout = 8000) {
    const started = Date.now();
    while (Date.now() - started < timeout) {
      const editor = findComposer();
      if (editor) return editor;
      await sleep(200);
    }
    return null;
  }

  function pasteInto(editor, build) {
    const data = new DataTransfer();
    build(data);
    editor.focus();
    return editor.dispatchEvent(
      new ClipboardEvent("paste", { clipboardData: data, bubbles: true, cancelable: true })
    );
  }

  const editorText = (editor) => (editor.innerText || "").trim();

  async function insertText(editor, text) {
    if (!text) return true;
    const before = editorText(editor);

    pasteInto(editor, (data) => data.setData("text/plain", text));
    await sleep(220);
    if (editorText(editor) !== before) return true;

    // Some builds ignore a synthetic paste; the old editing command still
    // goes through the editor's own input handling, so try that next.
    editor.focus();
    try {
      if (document.execCommand("insertText", false, text)) {
        await sleep(160);
        if (editorText(editor) !== before) return true;
      }
    } catch (_) { /* fall through */ }

    // Last resort: write it in and tell the editor something was typed.
    editor.textContent = text;
    editor.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
    await sleep(160);
    return editorText(editor) !== before;
  }

  function attachmentCount() {
    // Attachments render as thumbnails near the composer. Counting images that
    // aren't part of the conversation is close enough to know one landed.
    return document.querySelectorAll(
      'img[alt*="preview" i], img[src^="blob:"], [data-testid*="file" i], [class*="thumbnail" i]'
    ).length;
  }

  async function insertImage(editor, file) {
    if (!file) return true;
    const before = attachmentCount();

    pasteInto(editor, (data) => data.items.add(file));
    for (let i = 0; i < 20; i++) {
      await sleep(200);
      if (attachmentCount() > before) return true;
    }
    return false;
  }

  function dataUriToFile(uri, name, type) {
    const [head, body] = String(uri).split(",");
    if (!body) return null;
    const binary = atob(body);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    const mime = type || (head.match(/data:([^;]+)/) || [])[1] || "image/jpeg";
    return new File([bytes], name, { type: mime });
  }

  async function handle(payload) {
    const editor = await waitForComposer();
    if (!editor) {
      return { ok: false, reason: "Couldn't find Claude's message box on this page" };
    }

    editor.scrollIntoView({ block: "center" });
    editor.focus();
    await sleep(120);

    const file = payload.image
      ? dataUriToFile(payload.image, payload.filename || "instagram.jpg", payload.mime)
      : null;

    // Image first: an attachment is slower to process, and pasting text on top
    // of a pending upload sometimes drops one or the other.
    const imageOk = await insertImage(editor, file);
    if (file) await sleep(400);
    const textOk = await insertText(editor, payload.text || "");

    if (imageOk && textOk) return { ok: true };
    if (!imageOk && textOk) {
      return { ok: true, partial: "caption only — the image didn't attach, paste it with Ctrl+V" };
    }
    if (imageOk && !textOk) return { ok: true, partial: "image only — the caption didn't go in" };
    return { ok: false, reason: "Claude's message box wouldn't accept it" };
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message) return;
    if (message.type === "igr-ping") {
      sendResponse({ ready: !!findComposer() });
      return;
    }
    if (message.type === "igr-insert") {
      handle(message.payload || {})
        .then(sendResponse)
        .catch((err) => sendResponse({ ok: false, reason: String(err && err.message) }));
      return true; // async reply
    }
  });
})();
