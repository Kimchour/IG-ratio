/* IG Ratio — the bridge between tabs.
 *
 * Content scripts can't talk to each other, so a post travels Instagram tab ->
 * here -> Claude tab. This worker's only jobs are finding the right Claude tab
 * and relaying the payload once that tab says it is ready.
 */

const CLAUDE_MATCH = "https://claude.ai/*";

/* Which Claude tab. If several are open the newest conversation is rarely the
 * one meant; the one the person looked at last is. Chrome doesn't expose a
 * last-focused time for tabs, so track it as they go. */
const lastSeen = new Map();

chrome.tabs.onActivated.addListener(({ tabId }) => {
  chrome.tabs.get(tabId, (tab) => {
    if (chrome.runtime.lastError || !tab || !tab.url) return;
    if (tab.url.startsWith("https://claude.ai/")) lastSeen.set(tabId, Date.now());
  });
});

chrome.tabs.onRemoved.addListener((tabId) => lastSeen.delete(tabId));

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/* The chat's name is the tab title, which Claude sets to the conversation and
 * suffixes with its own name. Trimming that leaves something recognisable. */
function chatName(tab) {
  const raw = String(tab.title || "").trim();
  const cleaned = raw.replace(/\s*[-–—|]\s*Claude\s*$/i, "").trim();
  if (!cleaned || /^claude$/i.test(cleaned)) return "New chat";
  return cleaned.slice(0, 80);
}

async function listClaudeTabs() {
  const tabs = await chrome.tabs.query({ url: CLAUDE_MATCH });
  return tabs
    .map((tab) => ({
      id: tab.id,
      name: chatName(tab),
      url: tab.url || "",
      active: !!tab.active,
      seen: lastSeen.get(tab.id) || 0,
    }))
    // Most recently looked at first: that's nearly always the one meant.
    .sort((a, b) => b.seen - a.seen || Number(b.active) - Number(a.active));
}

async function findClaudeTab() {
  const tabs = await chrome.tabs.query({ url: CLAUDE_MATCH });
  if (!tabs.length) return null;

  // Prefer the one most recently looked at, then the one already focused,
  // then whatever is left.
  tabs.sort((a, b) => (lastSeen.get(b.id) || 0) - (lastSeen.get(a.id) || 0));
  const active = tabs.find((t) => t.active);
  return lastSeen.has(tabs[0].id) ? tabs[0] : active || tabs[0];
}

async function openClaudeTab() {
  const tab = await chrome.tabs.create({ url: "https://claude.ai/new", active: true });
  // A fresh tab has no content script yet; wait for it to announce itself.
  for (let i = 0; i < 40; i++) {
    await sleep(250);
    try {
      const reply = await chrome.tabs.sendMessage(tab.id, { type: "igr-ping" });
      if (reply && reply.ready) return tab;
    } catch (_) { /* not listening yet */ }
  }
  return tab;
}

async function deliver(payload) {
  let tab = null;
  let opened = false;

  // A chosen tab wins, as long as it's still open.
  if (payload && payload.tabId) {
    try {
      tab = await chrome.tabs.get(payload.tabId);
      if (!tab || !String(tab.url || "").startsWith("https://claude.ai/")) tab = null;
    } catch (_) {
      tab = null;
    }
  }
  if (!tab) tab = await findClaudeTab();

  if (!tab) {
    tab = await openClaudeTab();
    opened = true;
  }

  // Bring it forward: the person needs to see what landed, and an editor that
  // isn't visible often won't take a paste at all.
  await chrome.tabs.update(tab.id, { active: true });
  try {
    await chrome.windows.update(tab.windowId, { focused: true });
  } catch (_) { /* single-window setups */ }

  await sleep(opened ? 400 : 250);

  try {
    const result = await chrome.tabs.sendMessage(tab.id, { type: "igr-insert", payload });
    return result || { ok: false, reason: "Claude didn't answer" };
  } catch (err) {
    return {
      ok: false,
      reason: "Couldn't reach the Claude tab — reload it and try again",
    };
  }
}

/* ------------------------------------------------------------- update check

Reads a small version.json from the repo's main branch — the same arrangement
as PromptSnap. Nothing needs publishing through GitHub's release machinery and
there is no API rate limit to run into; editing one file announces a release.

The fetch happens here rather than in the page: a service worker isn't subject
to the page's CORS rules, and it keeps GitHub out of Instagram's network log.
*/

const REPO = "Kimchour/IG-ratio";
const REPO_URL = `https://github.com/${REPO}`;
const VERSION_URL = `https://raw.githubusercontent.com/${REPO}/main/version.json`;

async function readVersionFile() {
  // raw.githubusercontent sits behind a CDN that caches for a few minutes, so
  // a changing query string is the difference between "checked" and "checked
  // five minutes ago".
  const res = await fetch(`${VERSION_URL}?t=${Date.now()}`, { cache: "no-store" });
  if (res.status === 404) return { missing: true };
  if (!res.ok) throw new Error(`github ${res.status}`);

  const text = await res.text();
  let data;
  try {
    data = JSON.parse(text);
  } catch (_) {
    throw new Error("version.json isn't valid JSON");
  }
  return { data };
}

async function checkForUpdate() {
  try {
    const { missing, data } = await readVersionFile();
    if (missing) {
      return { ok: false, missing: true, reason: "No version.json in the repo yet", repo: REPO_URL };
    }

    const version = String(data.version || data.latest || "").trim();
    if (!version) {
      return { ok: false, reason: "version.json has no version field", repo: REPO_URL };
    }

    const lines = (value) =>
      (Array.isArray(value) ? value : [])
        .map((item) => String(item).trim())
        .filter(Boolean)
        .slice(0, 12);

    const entry = (item) => ({
      version: String((item && item.version) || "").trim(),
      date: String((item && item.date) || ""),
      added: lines(item && item.added),
      fixed: lines(item && item.fixed),
      notes: String((item && (item.notes || item.changelog)) || "").slice(0, 600),
    });

    return {
      ok: true,
      version,
      url: data.download || data.url || `${REPO_URL}/releases/latest`,
      date: String(data.date || ""),
      added: lines(data.added),
      fixed: lines(data.fixed),
      notes: String(data.notes || data.changelog || "").slice(0, 600),
      // Past releases, so the changelog can show what the reader already has.
      history: (Array.isArray(data.history) ? data.history : []).slice(0, 20).map(entry),
      repo: REPO_URL,
    };
  } catch (err) {
    // A bad version.json is the author's problem to fix, and saying "couldn't
    // reach GitHub" would send them looking in the wrong place.
    const malformed = String(err.message).includes("valid JSON");
    return {
      ok: false,
      reason: malformed ? "version.json isn't valid JSON" : "Couldn't reach GitHub",
      repo: REPO_URL,
    };
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message) return;

  if (message.type === "igr-send-to-claude") {
    deliver(message.payload).then(sendResponse);
    return true; // keep the channel open for the async reply
  }

  if (message.type === "igr-check-update") {
    checkForUpdate().then(sendResponse);
    return true;
  }

  if (message.type === "igr-list-claude-tabs") {
    listClaudeTabs().then((tabs) => sendResponse({ ok: true, tabs }));
    return true;
  }
});
