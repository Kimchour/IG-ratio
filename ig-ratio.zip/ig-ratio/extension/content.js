/* IG Ratio — reads likes and views off an Instagram profile grid and ranks
 * posts by likes ÷ views, highest first.
 *
 * Notes on why it's built this way:
 *  - Instagram recycles grid tiles while you scroll, so each tile is read the
 *    moment it appears rather than after a full scroll to the bottom.
 *  - View counts sit on the tile. Like counts only appear on hover, so each
 *    tile gets a synthetic mouseover.
 *  - Icons are matched by aria-label, not class name. Class names are
 *    obfuscated and change constantly; the labels survive much longer.
 */

(() => {
  "use strict";

  if (window.__igRatioLoaded) return;
  window.__igRatioLoaded = true;

  const HOVER_MS = 420;   // wait for the hover overlay to paint
  const SCROLL_MS = 1100; // wait for the next batch of tiles
  const STALL_LIMIT = 4;  // scrolls with no new posts before stopping
  const HOVER_FALLBACK_MAX = 24; // tiles worth hovering when the network gave nothing
  const SPRING = "cubic-bezier(0.34, 1.24, 0.44, 1)";
  const PREF_KEY = "igratio:prefs";

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const reduceMotion = () => window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  const state = {
    posts: new Map(),
    running: false,
    cancel: false,
    filter: "all",   // all | photo | reel
    sort: "ratio",   // ratio | likes | views
    theme: "auto",   // auto | light | dark
    quality: "high", // high | medium | low — which video rendition to download
    selected: new Set(),
    saving: false,
  };

  /* ================================================================= updates

  An unpacked extension can't replace itself — Chrome only auto-updates things
  installed from a store. So this checks GitHub, tells you whether your copy is
  behind, and takes you to the download. The install is still two steps you do
  by hand, and saying otherwise would be a lie dressed up as a button. */

  const REPO_URL = "https://github.com/Kimchour/IG-ratio";
  const UPDATE_CACHE = "igratio:update";
  const CHECK_EVERY = 12 * 60 * 60 * 1000; // twice a day is plenty

  const update = {
    state: "idle", latest: "", url: REPO_URL, notes: "", date: "", reason: "",
    added: [], fixed: [], history: [], checkedAt: 0,
  };

  const sound = (name) => { try { window.__igRatioSound?.play(name); } catch (_) {} };

  const thisVersion = () => {
    try { return chrome.runtime.getManifest().version; } catch (_) { return "0.0.0"; }
  };

  // "v4.3.0" and "4.3" both mean the same thing here.
  function compareVersions(a, b) {
    const parts = (v) => String(v).replace(/^v/i, "").split(/[.\-+]/).map((n) => parseInt(n, 10) || 0);
    const left = parts(a);
    const right = parts(b);
    for (let i = 0; i < Math.max(left.length, right.length); i++) {
      const diff = (left[i] || 0) - (right[i] || 0);
      if (diff) return diff > 0 ? 1 : -1;
    }
    return 0;
  }

  function readUpdateCache() {
    try { return JSON.parse(localStorage.getItem(UPDATE_CACHE) || "null"); } catch (_) { return null; }
  }

  function writeUpdateCache(entry) {
    try { localStorage.setItem(UPDATE_CACHE, JSON.stringify(entry)); } catch (_) {}
  }

  function applyUpdateResult(result) {
    if (!result || !result.ok) {
      Object.assign(update, {
        state: result && result.missing ? "unpublished" : "failed",
        url: (result && result.repo) || REPO_URL,
        reason: (result && result.reason) || "Couldn't check",
      });
      return update;
    }

    const mine = thisVersion();

    const behind = compareVersions(result.version, mine) > 0;
    Object.assign(update, {
      state: behind ? "behind" : "current",
      latest: result.version,
      url: result.url || REPO_URL,
      notes: result.notes || "",
      date: result.date || "",
      added: result.added || [],
      fixed: result.fixed || [],
      history: result.history || [],
      reason: "",
    });
    return update;
  }

  async function checkUpdate({ quiet = false, announce = false } = {}) {
    const cached = readUpdateCache();
    if (quiet && cached && Date.now() - (cached.at || 0) < CHECK_EVERY) {
      applyUpdateResult(cached.result);
      update.checkedAt = cached.at || 0;
      return update;
    }

    update.state = "checking";
    if (!quiet) { updateDismissed = false; refreshUpdateUI(); }
    if (updateModal && updateModal.classList.contains("is-open")) renderUpdateModal();

    let result;
    try {
      result = await chrome.runtime.sendMessage({ type: "igr-check-update" });
    } catch (err) {
      result = { ok: false, reason: "Couldn't reach GitHub" };
    }

    if (result && result.ok) writeUpdateCache({ at: Date.now(), result });
    update.checkedAt = (readUpdateCache() || {}).at || Date.now();
    applyUpdateResult(result);
    refreshUpdateUI();
    if (updateModal && updateModal.classList.contains("is-open")) renderUpdateModal();
    if (announce) {
      sound(update.state === "behind" ? "update" : update.state === "current" ? "current" : "fail");
    }
    return update;
  }

  /* ================================================================ licence */

  const LICENCE_KEY = "igratio:licence";
  const TRIAL_KEY = "igratio:trial";
  const TRIAL_DAYS = 7;

  const licence = { state: "checking", holder: "", plan: "", expires: null, reason: "", trialLeft: 0 };

  function trialDaysLeft() {
    let started;
    try {
      started = Number(localStorage.getItem(TRIAL_KEY));
      if (!started) {
        started = Date.now();
        localStorage.setItem(TRIAL_KEY, String(started));
      }
    } catch (_) {
      return TRIAL_DAYS; // private mode — don't lock someone out over storage
    }
    const used = (Date.now() - started) / 86400000;
    return Math.max(0, Math.ceil(TRIAL_DAYS - used));
  }

  async function checkLicence() {
    let saved = "";
    try { saved = localStorage.getItem(LICENCE_KEY) || ""; } catch (_) {}

    if (saved && window.__igRatioLicence) {
      const result = await window.__igRatioLicence.verify(saved);
      if (result.ok) {
        Object.assign(licence, {
          state: "licensed", holder: result.holder, plan: result.plan,
          expires: result.expires, reason: "",
        });
        return;
      }
      licence.reason = result.reason || "";
      if (result.expired) {
        Object.assign(licence, { state: "expired", holder: result.holder, plan: result.plan });
        return;
      }
    }

    const left = trialDaysLeft();
    Object.assign(licence, { state: left > 0 ? "trial" : "locked", trialLeft: left });
  }

  async function activate(key) {
    if (!window.__igRatioLicence) return { ok: false, reason: "Licence check unavailable" };
    const result = await window.__igRatioLicence.verify(key);
    if (result.ok) {
      try { localStorage.setItem(LICENCE_KEY, String(key).trim()); } catch (_) {}
      Object.assign(licence, {
        state: "licensed", holder: result.holder, plan: result.plan,
        expires: result.expires, reason: "",
      });
    }
    return result;
  }

  const unlocked = () => licence.state === "licensed" || licence.state === "trial";

  function licenceLine() {
    if (licence.state === "licensed") return licence.plan || "Licensed";
    if (licence.state === "trial") return `Trial · ${licence.trialLeft}d`;
    if (licence.state === "expired") return "Ended";
    return "Not activated";
  }

  // The full wording, for the tooltip and the status bar.
  function licenceDetail() {
    if (licence.state === "licensed") {
      return licence.expires ? `${licence.plan} licence, to ${licence.expires}` : `${licence.plan} licence`;
    }
    if (licence.state === "trial") {
      return `Trial · ${licence.trialLeft} day${licence.trialLeft === 1 ? "" : "s"} left`;
    }
    if (licence.state === "expired") return "Subscription ended";
    return "Not activated";
  }

  /* ============================================================ preferences */

  function loadPrefs() {
    try {
      const saved = JSON.parse(localStorage.getItem(PREF_KEY) || "{}");
      for (const k of ["filter", "sort", "theme", "quality"]) {
        if (saved[k]) state[k] = saved[k];
      }
    } catch (_) { /* private mode, or nothing saved yet */ }
  }

  function savePrefs() {
    try {
      localStorage.setItem(PREF_KEY, JSON.stringify({
        filter: state.filter, sort: state.sort, theme: state.theme, quality: state.quality,
      }));
    } catch (_) { /* not worth bothering the user about */ }
  }

  /* ====================================================== counts from the page

  The grid markup doesn't carry like counts any more, so the real source is
  net.js in the page world, which forwards whatever Instagram itself fetches. */

  const netData = new Map();
  let netTimer = null;

  // Headers Instagram signs its own API calls with, forwarded by net.js.
  // The fallback app id is the long-standing public web one.
  let igHeaders = { "x-ig-app-id": "936619743392459" };

  window.addEventListener("message", (e) => {
    if (e.source !== window) return;
    const d = e.data;
    if (d && d.source === "ig-ratio-headers" && d.headers) {
      igHeaders = { ...igHeaders, ...d.headers };
      return;
    }
    if (!d || d.source !== "ig-ratio-net" || !Array.isArray(d.items)) return;

    for (const item of d.items) {
      if (!item || !item.code) continue;
      const prev = netData.get(item.code) || {};
      netData.set(item.code, {
        likes: item.likes ?? prev.likes ?? null,
        views: item.views ?? prev.views ?? null,
        comments: item.comments ?? prev.comments ?? null,
        kind: item.kind || prev.kind || null,
        pk: item.pk || prev.pk || null,
        author: item.author || prev.author || null,
        time: item.time ?? prev.time ?? null,
        thumb: prev.thumb || item.thumb || null,
        preview: prev.preview || item.preview || null,
        videos: prev.videos || item.videos || null,
        slides: prev.slides || item.slides || null,
        caption: prev.caption || item.caption || null,
      });
    }

    // Late arrivals are normal, so refresh the list once things settle.
    if (panel && !state.running && state.posts.size) {
      clearTimeout(netTimer);
      netTimer = setTimeout(() => { if (applyNet()) render(); }, 400);
    }
  });

  // net.js starts earlier than this script does, so ask it for the backlog.
  window.postMessage({ source: "ig-ratio-ready" }, "*");

  function applyNet() {
    let changed = false;
    for (const p of state.posts.values()) {
      const d = netData.get(p.code);
      if (!d) continue;
      for (const k of ["likes", "views", "comments"]) {
        if (p[k] == null && d[k] != null) { p[k] = d[k]; changed = true; }
      }
      if (d.kind && d.kind !== p.kind) { p.kind = d.kind; changed = true; }
      for (const k of ["thumb", "preview", "videos", "slides", "caption", "time", "pk", "author"]) {
        if (!p[k] && d[k]) { p[k] = d[k]; changed = true; }
      }
    }
    return changed;
  }

  /* ================================================================ parsing */

  // "1,234" -> 1234   "12.3K" -> 12300   "1.2M" -> 1200000
  function parseCount(text) {
    if (!text) return null;
    const t = text.replace(/\u00a0/g, " ").trim();
    const m = t.match(/^([\d.,]+)\s*([KMB])?$/i);
    if (!m) return null;
    const suffix = (m[2] || "").toUpperCase();
    let raw = m[1];
    if (suffix) raw = raw.replace(/,/g, ".");
    else raw = raw.replace(/[.,]/g, ""); // no suffix: separators are thousands
    const n = parseFloat(raw);
    if (!isFinite(n)) return null;
    const mult = suffix === "K" ? 1e3 : suffix === "M" ? 1e6 : suffix === "B" ? 1e9 : 1;
    return Math.round(n * mult);
  }

  const fmt = (n) => (n == null ? "—" : n.toLocaleString("en-US"));

  // Row lines are narrow, so they get rounded figures. Exact numbers live in
  // the preview card and the CSV.
  function compact(n) {
    if (n == null) return "—";
    if (n >= 1e6) return `${(n / 1e6).toFixed(n >= 1e7 ? 0 : 1)}M`;
    if (n >= 1e4) return `${Math.round(n / 1e3)}K`;
    if (n >= 1e3) return `${(n / 1e3).toFixed(1)}K`;
    return String(n);
  }

  function pct(r) {
    if (r == null) return "—";
    if (r >= 1) return `${(r * 100).toFixed(0)}%`;
    if (r >= 0.1) return `${(r * 100).toFixed(1)}%`;
    return `${(r * 100).toFixed(2)}%`;
  }

  // Instagram sends seconds, not milliseconds.
  function shortDate(t) {
    if (!t) return null;
    return new Date(t * 1000).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "2-digit" });
  }

  function fullDate(t) {
    if (!t) return null;
    return new Date(t * 1000).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
  }

  // Renditions arrive widest-first.
  function videoUrl(p, want = state.quality) {
    const v = p.videos;
    if (!v || !v.length) return null;
    if (want === "high") return v[0].url;
    if (want === "low") return v[v.length - 1].url;
    return v[Math.floor((v.length - 1) / 2)].url;
  }

  // Smallest rendition for playback: a preview should start, not buffer.
  const previewUrl = (p) => videoUrl(p, "low");

  // Files are named from the post's own caption so they stay recognisable
  // once they're sitting in a folder.
  function fileName(p, ext) {
    const date = p.time ? new Date(p.time * 1000).toISOString().slice(0, 10) : "";
    const title = (p.caption || "")
      .split("\n")[0]
      .replace(/[\\/:*?"<>|\u0000-\u001f]+/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 70)
      .replace(/[\s.]+$/, "");
    const who = p.fromFeed && p.author ? `@${p.author}` : "";
    const slide = p.slideCount ? `(${p.slideNumber} of ${p.slideCount})` : "";
    return `${[date, who, title, p.code, slide].filter(Boolean).join(" - ")}${ext}`;
  }

  /* =========================================================== tile reading */

  function gridAnchors() {
    const root = document.querySelector("main") || document.body;
    return [...root.querySelectorAll('a[href*="/p/"], a[href*="/reel/"]')];
  }

  function idOf(anchor) {
    const m = (anchor.getAttribute("href") || "").match(/\/(p|reel|tv)\/([^/?#]+)/);
    return m ? { seg: m[1], code: m[2] } : null;
  }

  // Reels and videos on one side, photos and carousels on the other.
  function classify(anchor, seg) {
    if (seg === "reel" || seg === "tv") return "reel";
    const labels = [...anchor.querySelectorAll("svg[aria-label]")]
      .map((s) => (s.getAttribute("aria-label") || "").toLowerCase())
      .join(" ");
    if (/clip|reel|video/.test(labels)) return "reel";
    return "photo"; // covers single images and carousels
  }

  // Find the number belonging to an icon by walking up a few parents.
  function countNearIcon(svg) {
    let node = svg;
    for (let i = 0; i < 4 && node; i++) {
      node = node.parentElement;
      if (!node) break;
      for (const span of node.querySelectorAll("span")) {
        if (span.querySelector("svg")) continue;
        const v = parseCount(span.textContent);
        if (v != null) return v;
      }
    }
    return null;
  }

  const LABELLED = /^\s*([\d.,]+\s*[KMB]?)\s+(likes?|comments?|views?|plays?)\s*$/i;

  /* Counts are read in two passes.
   *
   * First anything self-describing — "1,148 likes" — because that needs no
   * guessing at all.
   *
   * Then by icon adjacency, walking the subtree in document order and giving
   * each number to the icon that most recently preceded it. That matches how
   * the row actually reads on screen: heart, count, bubble, count. The old
   * approach climbed the tree from each icon and grabbed the first number it
   * found, which on the feed handed the like count to the comment icon. */
  function readIcons(scope) {
    const out = { likes: null, comments: null, views: null };
    const bucket = (label) => {
      const l = label.toLowerCase();
      if (l.includes("comment")) return "comments";
      if (l.includes("like")) return "likes";        // covers "Unlike"
      if (l.includes("view") || l.includes("play")) return "views";
      return null;
    };

    const walker = document.createTreeWalker(scope, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT);
    let pending = null;

    while (walker.nextNode()) {
      const node = walker.currentNode;

      if (node.nodeType === Node.ELEMENT_NODE) {
        if (node.tagName.toLowerCase() === "svg") pending = bucket(node.getAttribute("aria-label") || "");
        continue;
      }

      const text = node.nodeValue;
      if (!text || !text.trim()) continue;

      const described = text.match(LABELLED);
      if (described) {
        const key = bucket(described[2]);
        const value = parseCount(described[1]);
        if (key && value != null) out[key] = value; // self-describing wins
        pending = null;
        continue;
      }

      if (!pending || out[pending] != null) continue;
      const value = parseCount(text);
      if (value != null) { out[pending] = value; pending = null; }
    }
    return out;
  }

  // The first image in a feed post is the author's avatar, not the post.
  function postImage(scope) {
    let best = null;
    let biggest = 0;
    for (const img of scope.querySelectorAll("img")) {
      if ((img.getAttribute("alt") || "").toLowerCase().includes("profile picture")) continue;
      const box = img.getBoundingClientRect();
      const area = box.width * box.height;
      if (area > biggest) { biggest = area; best = img; }
    }
    return biggest >= 5000 ? best : null;
  }

  function merge(base, extra) {
    for (const k of ["likes", "comments", "views"]) {
      if (base[k] == null && extra[k] != null) base[k] = extra[k];
    }
    return base;
  }

  function clearHover(anchor) {
    const o = { bubbles: true, cancelable: true, view: window };
    anchor.dispatchEvent(new MouseEvent("mouseout", o));
    anchor.dispatchEvent(new MouseEvent("mouseleave", { ...o, bubbles: false }));
  }

  async function readTile(anchor) {
    const stats = readIcons(anchor); // views usually show without hovering

    const o = { bubbles: true, cancelable: true, view: window };
    anchor.dispatchEvent(new MouseEvent("mouseover", o));
    anchor.dispatchEvent(new MouseEvent("mouseenter", { ...o, bubbles: false }));
    anchor.dispatchEvent(new MouseEvent("mousemove", o));
    await sleep(HOVER_MS);
    merge(stats, readIcons(anchor));
    clearHover(anchor);

    const img = anchor.querySelector("img");
    return { ...stats, thumb: img ? img.src : null, alt: img ? (img.alt || "").slice(0, 120) : "" };
  }

  /* ============================================================== scanning */

  async function scan(limit, onTick) {
    state.cancel = false;
    let stalls = 0;

    // Pass one: walk the grid for post links and whatever the tiles show
    // outright, scrolling to make Instagram fetch the next batch.
    while (!state.cancel) {
      let foundNew = false;

      for (const anchor of gridAnchors()) {
        if (state.cancel) break;
        if (limit && state.posts.size >= limit) break;
        const id = idOf(anchor);
        if (!id || state.posts.has(id.code)) continue;

        const img = anchor.querySelector("img");
        state.posts.set(id.code, {
          code: id.code,
          order: state.posts.size, // the grid runs newest-first; used if no timestamp arrives
          kind: classify(anchor, id.seg),
          url: `https://www.instagram.com/${id.seg}/${id.code}/`,
          thumb: img ? img.src : null,
          alt: img ? (img.alt || "").slice(0, 120) : "",
          ...readIcons(anchor),
        });
        foundNew = true;
        onTick(state.posts.size);
      }

      applyNet();
      for (const p of state.posts.values()) if (!p.pk) p.pk = pkFromShortcode(p.code);
      if (limit && state.posts.size >= limit) break;
      stalls = foundNew ? 0 : stalls + 1;
      if (stalls >= STALL_LIMIT) break;

      window.scrollTo(0, document.body.scrollHeight);
      await sleep(SCROLL_MS);
    }

    // Responses for the last batch are often still in the air, so give them
    // a moment rather than reporting gaps that fill in a second later.
    if (!state.cancel) {
      onTick(state.posts.size, "Waiting for the last counts");
      await sleep(1400);
      applyNet();
    }

    // Pass two: anything the network didn't cover gets one hover attempt.
    const gaps = [...state.posts.values()].filter((p) => p.likes == null).slice(0, HOVER_FALLBACK_MAX);
    if (gaps.length && !state.cancel) {
      const byCode = new Map();
      for (const a of gridAnchors()) {
        const id = idOf(a);
        if (id) byCode.set(id.code, a);
      }
      let done = 0;
      for (const p of gaps) {
        if (state.cancel) break;
        const anchor = byCode.get(p.code);
        if (!anchor) continue;
        merge(p, await readTile(anchor));
        onTick(state.posts.size, `filling gaps ${++done} of ${gaps.length}`);
      }
    }

    applyNet();

    // A synthetic hover can outlive the scan if the page scrolled mid-read.
    // Sweep the grid so no overlay is left stuck open.
    gridAnchors().forEach(clearHover);
    return state.posts.size;
  }

  /* =============================================================== ranking */

  function visible() {
    const all = [...state.posts.values()];
    return state.filter === "all" ? all : all.filter((p) => p.kind === state.filter);
  }

  const withRatio = (p) => ({ ...p, ratio: p.likes != null && p.views ? p.likes / p.views : null });

  // Attach the number this row is being judged on, plus how to show it.
  function decorate(p, mode) {
    const chosen = {
      likes: [p.likes, fmt(p.likes), "likes"],
      views: [p.views, fmt(p.views), "views"],
      ratio: [p.ratio, pct(p.ratio), "likes / views"],
    }[mode];
    if (chosen[0] != null) return { ...p, metric: chosen[0], display: chosen[1], unit: chosen[2] };

    // This post doesn't carry the chosen number, so show whatever it does have.
    if (p.likes != null) return { ...p, metric: null, display: fmt(p.likes), unit: "likes" };
    if (p.views != null) return { ...p, metric: null, display: fmt(p.views), unit: "views" };
    return { ...p, metric: null, display: "—", unit: "" };
  }

  const BY_DATE = { newest: -1, oldest: 1 };

  function ranked() {
    const base = visible().map(withRatio);
    const wanted = state.sort;
    const byDate = wanted in BY_DATE;

    // Sorting by date shouldn't hide the numbers, so the rows still display
    // the performance figure — only the running order changes.
    const shown = byDate ? "ratio" : wanted;
    const usable =
      shown === "ratio" ? base.some((p) => p.ratio != null)
      : shown === "views" ? base.some((p) => p.views != null)
      : base.some((p) => p.likes != null);
    const mode = usable ? shown : "likes";

    const rows = base.map((p) => decorate(p, mode));
    const top = rows.reduce((best, p) => (p.metric != null && p.metric > best ? p.metric : best), 0) || null;
    const missing = rows.filter((p) => p.metric == null).length;

    if (byDate) {
      // Real timestamps when every post has one, otherwise grid position —
      // the profile grid is already newest-first.
      const dated = rows.every((p) => p.time != null);
      const key = dated ? (p) => p.time : (p) => -p.order;
      const dir = BY_DATE[wanted];
      rows.sort((a, b) => (key(a) - key(b)) * dir);
      return { rows, mode, wanted, top, missing, dated };
    }

    const have = rows.filter((p) => p.metric != null).sort((a, b) => b.metric - a.metric);
    const rest = rows.filter((p) => p.metric == null).sort((a, b) => (b.likes ?? -1) - (a.likes ?? -1));
    return { rows: [...have, ...rest], mode, wanted, top, missing };
  }

  function noteFor({ mode, wanted, missing, dated }) {
    if (wanted in BY_DATE) {
      const figures = `Figures show ${mode === "ratio" ? "likes ÷ views" : mode}`;
      return dated ? figures : `${figures} · ordered by grid position, no dates`;
    }
    if (mode !== wanted) {
      return wanted === "ratio"
        ? "No view counts on these posts — sorted by likes"
        : "No view counts on these posts — sorted by likes instead";
    }
    if (mode === "likes") return "Most likes first";
    if (mode === "views") return `Most views first${missing ? ` · ${missing} without views` : ""}`;
    return `Highest likes ÷ views first${missing ? ` · ${missing} without views` : ""}`;
  }

  /* ==================================================================== UI */

  let panel = null;
  let launcher = null;
  let updateModal = null;
  let chatPicker = null;
  let shownRows = []; // what the list is showing right now, in order

  const el = (tag, cls, text) => {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  };

  const ICON = {
    chart: '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M2 13.2h12M4.4 13V8.2M8 13V3.4M11.6 13V6.1"/></svg>',
    close: '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M3.6 3.6l8.8 8.8M12.4 3.6l-8.8 8.8"/></svg>',
    eye: '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M1.4 8S3.8 3.9 8 3.9 14.6 8 14.6 8 12.2 12.1 8 12.1 1.4 8 1.4 8z"/><circle cx="8" cy="8" r="1.9"/></svg>',
    refresh: '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M13.4 8a5.4 5.4 0 1 1-1.6-3.8"/><path d="M13.6 2.2v3.4h-3.4"/></svg>',
    tickBig: '<svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.6l4.6 4.6L19 6.4"/></svg>',
    plus: '<svg viewBox="0 0 16 16" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M8 3.4v9.2M3.4 8h9.2"/></svg>',
    warn: '<svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M12 7.4v6.2"/><circle cx="12" cy="17.2" r="1.2" fill="currentColor" stroke="none"/></svg>',
    sound: '<svg viewBox="0 0 16 16" width="12" height="12" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M7.2 3.2L4.4 5.6H2.4v4.8h2l2.8 2.4V3.2z"/><path d="M10.4 6.2a2.6 2.6 0 010 3.6"/><path d="M12.4 4.4a5.2 5.2 0 010 7.2"/></svg>',
    mute: '<svg viewBox="0 0 16 16" width="12" height="12" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M7.2 3.2L4.4 5.6H2.4v4.8h2l2.8 2.4V3.2z"/><path d="M10.6 6.4l3.2 3.2M13.8 6.4l-3.2 3.2"/></svg>',
    tick: '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3.2 8.6l3.1 3.1 6.5-7.4"/></svg>',
    cross: '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M4 4l8 8M12 4l-8 8"/></svg>',
    dots: '<svg viewBox="0 0 16 16" width="13" height="13" fill="currentColor"><circle cx="3.2" cy="8" r="1.4"><animate attributeName="opacity" values="1;.3;1" dur="1s" repeatCount="indefinite" begin="0s"/></circle><circle cx="8" cy="8" r="1.4"><animate attributeName="opacity" values="1;.3;1" dur="1s" repeatCount="indefinite" begin=".2s"/></circle><circle cx="12.8" cy="8" r="1.4"><animate attributeName="opacity" values="1;.3;1" dur="1s" repeatCount="indefinite" begin=".4s"/></circle></svg>',
    send: '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2L7.3 8.7"/><path d="M14 2l-4.3 12-2.4-5.3L2 6.3 14 2z"/></svg>',
    lock: '<svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3.2" y="7" width="9.6" height="6.6" rx="1.6"/><path d="M5.6 7V5.2a2.4 2.4 0 014.8 0V7"/></svg>',
    down: '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M8 2.4v8M5 7.6l3 3 3-3M2.6 13.4h10.8"/></svg>',
    prev: '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M9.8 3.2L5 8l4.8 4.8"/></svg>',
    next: '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M6.2 3.2L11 8l-4.8 4.8"/></svg>',
    auto: '<svg viewBox="0 0 16 16" width="13" height="13"><circle cx="8" cy="8" r="5.6" fill="none" stroke="currentColor" stroke-width="1.5"/><path d="M8 2.4a5.6 5.6 0 000 11.2z" fill="currentColor"/></svg>',
    light: '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><circle cx="8" cy="8" r="2.9"/><path d="M8 1.6v1.5M8 12.9v1.5M1.6 8h1.5M12.9 8h1.5M3.5 3.5l1.1 1.1M11.4 11.4l1.1 1.1M12.5 3.5l-1.1 1.1M4.6 11.4l-1.1 1.1"/></svg>',
    dark: '<svg viewBox="0 0 16 16" width="13" height="13"><path d="M12.8 9.8A5.4 5.4 0 016.2 3.2a5.6 5.6 0 106.6 6.6z" fill="currentColor"/></svg>',
  };

  const THEME_ORDER = ["auto", "light", "dark"];

  /* Instagram has its own dark mode, set in its settings and independent of
   * the operating system. Following prefers-color-scheme therefore gets it
   * wrong for anyone whose two settings disagree — a white panel on a black
   * page. Reading the page's own background is the only thing that always
   * matches what the user is actually looking at. */
  function pageIsDark() {
    for (const node of [document.body, document.documentElement]) {
      if (!node) continue;
      const parsed = (getComputedStyle(node).backgroundColor || "")
        .match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/);
      if (!parsed) continue;
      if (parsed[4] !== undefined && parseFloat(parsed[4]) < 0.5) continue; // see-through, keep looking
      const [r, g, b] = [1, 2, 3].map((i) => Number(parsed[i]));
      return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255 < 0.5;
    }
    return window.matchMedia("(prefers-color-scheme: dark)").matches;
  }

  function resolvedTheme() {
    return state.theme === "auto" ? (pageIsDark() ? "dark" : "light") : state.theme;
  }

  function paint(node, resolved) {
    if (!node) return;
    node.classList.toggle("igr-light", resolved === "light");
    node.classList.toggle("igr-dark", resolved === "dark");
  }

  function applyTheme() {
    const resolved = resolvedTheme();
    for (const node of [panel, launcher, modal, tally, updateModal, chatPicker]) paint(node, resolved);
    // The per-post controls are scattered through Instagram's own markup.
    for (const node of document.querySelectorAll(".igr-inline")) paint(node, resolved);
    const btn = panel && panel.querySelector('[data-role="theme"]');
    if (btn) {
      btn.innerHTML = ICON[state.theme];
      const suffix = state.theme === "auto" ? ` (matching this page: ${resolved})` : "";
      btn.title = `Appearance: ${state.theme}${suffix}`;
      btn.setAttribute("aria-label", `Appearance: ${state.theme}${suffix}. Click to change.`);
    }
  }

  function handle() {
    const first = location.pathname.split("/").filter(Boolean)[0];
    return first ? `@${first}` : "Profile";
  }

  /* ---------------------------------------------------------------- panel */

  function buildPanel() {
    panel = el("aside", "igr");
    panel.setAttribute("role", "complementary");
    panel.setAttribute("aria-label", "Post performance");
    panel.innerHTML = `
      <header class="igr-top">
        <div class="igr-ident">
          <h2 class="igr-brand">IG Ratio</h2>
          <p class="igr-by">Created By Oeng Kimchour</p>
        </div>
        <div class="igr-top-actions">
          <button class="igr-icon" data-role="theme"></button>
          <button class="igr-icon" data-role="close" aria-label="Close">${ICON.close}</button>
        </div>
      </header>

      <div class="igr-scope">
        <span class="igr-scope-label" data-role="eyebrow">Post performance</span>
        <span class="igr-scope-handle" data-role="handle"></span>
      </div>

      <div class="igr-toolbar">
        <button class="igr-btn igr-btn--primary" data-role="run">Read grid</button>
        <button class="igr-icon" data-role="refresh" aria-label="Read again" title="Read again, keeping your sort and selection">${ICON.refresh}</button>
        <label class="igr-field">
          <span>Limit</span>
          <input type="number" min="1" step="12" value="60" data-role="limit" aria-label="Maximum posts to read">
        </label>
        <button class="igr-icon" data-role="csv" aria-label="Export CSV" title="Export CSV">${ICON.down}</button>
        <button class="igr-btn igr-feed-only" data-role="clear">Clear kept</button>
      </div>

      <nav class="igr-tabs" data-role="tabs" role="tablist">
        <button class="igr-tab" data-filter="all" role="tab">All<span class="igr-tab-n" data-count="all"></span></button>
        <button class="igr-tab" data-filter="photo" role="tab">Photos<span class="igr-tab-n" data-count="photo"></span></button>
        <button class="igr-tab" data-filter="reel" role="tab">Reels<span class="igr-tab-n" data-count="reel"></span></button>
        <span class="igr-underline" data-role="underline"></span>
      </nav>

      <div class="igr-sortbar">
        <span class="igr-select">
          <select data-role="sort" aria-label="Sort by">
            <optgroup label="Performance">
              <option value="ratio">Likes / views</option>
              <option value="likes">Likes</option>
              <option value="views">Views</option>
            </optgroup>
            <optgroup label="Date posted">
              <option value="newest">Newest first</option>
              <option value="oldest">Oldest first</option>
            </optgroup>
          </select>
        </span>
        <span class="igr-note" data-role="note"></span>
      </div>

      <div class="igr-updatebar" data-role="updatebar" hidden></div>

      <div class="igr-summary" data-role="summary" hidden></div>

      <div class="igr-picker" data-role="picker" hidden>
        <div class="igr-picker-row">
          <label class="igr-check">
            <input type="checkbox" data-role="selall">
            <span data-role="sellabel">Select all</span>
          </label>
          <span class="igr-select igr-select--sm">
            <select data-role="quality" aria-label="Reel download quality">
              <option value="high">Best quality</option>
              <option value="medium">Medium</option>
              <option value="low">Smallest</option>
            </select>
          </span>
        </div>
        <button class="igr-btn igr-picker-go" data-role="zip" disabled>Download ZIP</button>
      </div>
      <div class="igr-list" data-role="list"></div>

      <footer class="igr-foot">
        <div class="igr-status">
          <span data-role="status">READY</span>
          <span class="igr-progress"><span data-role="progress"></span></span>
        </div>
        <div class="igr-credit">
          <button class="igr-update-btn" data-role="update"></button>
          <button class="igr-licence-btn" data-role="licence"></button>
        </div>
      </footer>
    `;
    document.body.appendChild(panel);

    const q = (r) => panel.querySelector(`[data-role="${r}"]`);
    panel.classList.toggle("is-feed", pageKind() === "feed");
    q("eyebrow").textContent = pageKind() === "feed" ? "Kept from feed" : "Post performance";
    q("handle").textContent = pageKind() === "feed" ? "Kept posts" : handle();
    q("close").onclick = closePanel;
    q("run").onclick = () => run();
    q("csv").onclick = exportCsv;
    q("theme").onclick = cycleTheme;
    q("refresh").onclick = () => run({ keepSelection: true });
    // The window is where everything about updates lives, so the footer button
    // opens it rather than doing one of several half-jobs itself.
    q("update").onclick = () => openUpdateModal({ recheck: update.state !== "behind" });
    q("clear").onclick = () => {
      state.posts.clear();
      state.selected.clear();
      render();
    };
    q("licence").onclick = () => openLicence();

    const sortSelect = q("sort");
    sortSelect.value = state.sort;
    sortSelect.onchange = () => {
      state.sort = sortSelect.value;
      savePrefs();
      renderWithFlip();
    };

    panel.querySelectorAll("[data-filter]").forEach((b) => {
      b.classList.toggle("is-on", b.dataset.filter === state.filter);
      b.onclick = () => setFilter(b);
    });

    const quality = q("quality");
    quality.value = state.quality;
    quality.onchange = () => { state.quality = quality.value; savePrefs(); };

    q("selall").onchange = (e) => toggleAll(e.target.checked);
    q("zip").onclick = downloadZip;

    applyTheme();
    refreshLicenceUI();
    refreshUpdateUI();
    checkUpdate({ quiet: true });
    requestAnimationFrame(() => {
      moveUnderline(panel.querySelector(".igr-tab.is-on"), false);
      panel.classList.add("is-open");
    });
    render();
  }

  function closePanel() {
    state.cancel = true;
    closePreview();
    if (!panel) return;
    const node = panel;
    panel = null;
    node.classList.remove("is-open");
    setTimeout(() => node.remove(), reduceMotion() ? 0 : 240);
    if (launcher) launcher.classList.remove("is-hidden");
  }

  function cycleTheme() {
    state.theme = THEME_ORDER[(THEME_ORDER.indexOf(state.theme) + 1) % THEME_ORDER.length];
    applyTheme();
    savePrefs();
  }

  // The thumb sits inside the track's 3px padding, so its travel is measured
  // from the track rather than the panel.
  function moveUnderline(tab, animate = true) {
    const thumb = panel && panel.querySelector('[data-role="underline"]');
    const track = panel && panel.querySelector('[data-role="tabs"]');
    if (!thumb || !tab || !track) return;

    const t = tab.getBoundingClientRect();
    const r = track.getBoundingClientRect();
    const place = () => {
      thumb.style.width = `${t.width}px`;
      thumb.style.transform = `translateX(${t.left - r.left - 3}px)`;
    };

    if (!animate || reduceMotion()) {
      const keep = thumb.style.transition;
      thumb.style.transition = "none";
      place();
      void thumb.offsetWidth;
      thumb.style.transition = keep;
      return;
    }
    place();
  }

  function setFilter(tab) {
    if (tab.classList.contains("is-on")) return;
    panel.querySelectorAll("[data-filter]").forEach((b) => b.classList.toggle("is-on", b === tab));
    state.filter = tab.dataset.filter;
    savePrefs();
    moveUnderline(tab);
    renderWithFlip();
  }

  /* -------------------------------------------------------------- scanning */

  function setStatus(t) {
    const n = panel && panel.querySelector('[data-role="status"]');
    if (n) n.textContent = t.toUpperCase();
  }

  function setProgress(pctDone) {
    const n = panel && panel.querySelector('[data-role="progress"]');
    if (n) n.style.width = `${pctDone}%`;
  }

  async function run(opts = {}) {
    if (state.running || !panel) return;
    if (!unlocked()) return openLicence();
    state.running = true;
    state.posts.clear();
    if (!opts.keepSelection) state.selected.clear();

    const runBtn = panel.querySelector('[data-role="run"]');
    const refreshBtn = panel.querySelector('[data-role="refresh"]');
    refreshBtn.disabled = true;
    const limit = parseInt(panel.querySelector('[data-role="limit"]').value, 10) || 0;
    const startY = window.scrollY;

    runBtn.textContent = "Stop";
    runBtn.classList.remove("igr-btn--primary");
    runBtn.onclick = () => { state.cancel = true; };

    try {
      await scan(limit, (n, note) => {
        setStatus(note || `Reading ${n}${limit ? ` of ${limit}` : ""}`);
        if (limit) setProgress(Math.min(100, (n / limit) * 100));
      });
    } catch (err) {
      setStatus("Stopped early");
      console.error("[IG Ratio]", err);
    }

    window.scrollTo(0, startY);
    setProgress(0);
    runBtn.textContent = "Read grid";
    runBtn.classList.add("igr-btn--primary");
    runBtn.onclick = () => run();
    refreshBtn.disabled = false;
    state.running = false;
    renderWithFlip();
  }

  /* ------------------------------------------------------------- rendering */

  function median(values) {
    if (!values.length) return null;
    const s = [...values].sort((a, b) => a - b);
    const mid = Math.floor(s.length / 2);
    return s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
  }

  function renderSummary(result) {
    const box = panel.querySelector('[data-role="summary"]');
    const scored = result.rows.filter((p) => p.metric != null);
    if (!scored.length) { box.hidden = true; return; }
    box.hidden = false;

    const asText = (v) => (result.mode === "ratio" ? pct(v) : fmt(Math.round(v)));
    box.innerHTML = "";
    for (const [k, v] of [["Posts", String(result.rows.length)],
                          ["Median", asText(median(scored.map((p) => p.metric)))],
                          ["Best", asText(Math.max(...scored.map((p) => p.metric)))]]) {
      const cell = el("div", "igr-stat");
      cell.append(el("p", "igr-eyebrow", k), el("div", "igr-stat-v", v));
      box.appendChild(cell);
    }
  }

  function renderTabCounts() {
    const all = [...state.posts.values()];
    const counts = {
      all: all.length,
      photo: all.filter((p) => p.kind === "photo").length,
      reel: all.filter((p) => p.kind === "reel").length,
    };
    panel.querySelectorAll("[data-count]").forEach((n) => {
      n.textContent = state.posts.size ? counts[n.dataset.count] : "";
    });
  }

  function render() {
    if (!panel) return;
    const list = panel.querySelector('[data-role="list"]');
    const note = panel.querySelector('[data-role="note"]');

    refreshLicenceUI();
    if (!unlocked()) {
      list.innerHTML = "";
      list.appendChild(licenceView());
      note.textContent = "";
      panel.querySelector('[data-role="summary"]').hidden = true;
      panel.querySelector('[data-role="picker"]').hidden = true;
      setStatus(licenceDetail());
      return;
    }

    const result = ranked();
    shownRows = result.rows;

    list.innerHTML = "";
    note.textContent = noteFor(result);
    renderTabCounts();

    if (!state.posts.size) {
      list.appendChild(el("p", "igr-empty", pageKind() === "feed"
        ? "Nothing kept yet. Scroll the feed and press Keep on the bar to collect posts here."
        : "Press Read grid. The page scrolls itself and picks up each post's counts as they load."));
      panel.querySelector('[data-role="summary"]').hidden = true;
      panel.querySelector('[data-role="picker"]').hidden = true;
      return;
    }
    if (!result.rows.length) {
      list.appendChild(el("p", "igr-empty", "No posts of this type in what was read."));
      panel.querySelector('[data-role="summary"]').hidden = true;
      panel.querySelector('[data-role="picker"]').hidden = true;
      return;
    }

    renderSummary(result);
    if (!state.running) setStatus(`${result.rows.length} shown / ${state.posts.size} read`);

    if (!result.rows.some((p) => p.likes != null || p.views != null)) {
      list.appendChild(el("p", "igr-hint",
        "No counts came through. Refresh the page, then read again — the numbers are picked up as Instagram loads them."));
    }

    result.rows.forEach((p, i) => list.appendChild(rowEl(p, i + 1, result.top)));
    refreshPicker();
    refreshCapture();

    if (modal && modal.classList.contains("is-open") && previewList === shownRows) {
      viewIndex = Math.min(viewIndex, shownRows.length - 1);
      showShot();
    }
  }

  // Re-sorting reads better if rows travel to their new place.
  function renderWithFlip() {
    if (!panel) return;
    const list = panel.querySelector('[data-role="list"]');
    const before = new Map();
    list.querySelectorAll(".igr-row").forEach((r) => before.set(r.dataset.code, r.getBoundingClientRect().top));

    render();
    if (reduceMotion()) return;

    list.querySelectorAll(".igr-row").forEach((r) => {
      const wasAt = before.get(r.dataset.code);
      if (wasAt == null) return;
      const dy = wasAt - r.getBoundingClientRect().top;
      if (!dy) return;
      r.style.animation = "none";
      r.animate([{ transform: `translateY(${dy}px)` }, { transform: "none" }],
        { duration: 260, easing: "cubic-bezier(0.2, 0, 0, 1)" });
    });
  }

  function rowEl(p, rank, top) {
    const row = el("div", "igr-row");
    row.dataset.code = p.code;
    row.style.setProperty("--i", Math.min(rank, 20));
    if (rank === 1 && p.metric != null) row.classList.add("igr-row--lead");

    const box = el("label", "igr-check igr-check--row");
    const tick = el("input");
    tick.type = "checkbox";
    tick.checked = state.selected.has(p.code);
    tick.disabled = !canDownload(p);
    tick.title = canDownload(p) ? "Select for download" : "Nothing downloadable for this post yet";
    tick.setAttribute("aria-label", `Select post ${rank}`);
    tick.onchange = () => togglePost(p.code, tick.checked);
    box.appendChild(tick);


    const link = el("a", "igr-row-main");
    link.href = p.url;
    link.target = "_blank";
    link.rel = "noopener";

    const rankNum = el("span", "igr-rank", String(rank).padStart(2, "0"));

    const thumb = el("span", "igr-thumb");
    if (p.thumb) {
      const img = el("img");
      img.src = p.thumb;
      img.alt = p.alt || "";
      thumb.appendChild(img);
    }
    const slides = slidesOf(p);
    thumb.appendChild(el("span", "igr-kind",
      slides ? `×${slides.length}` : p.kind === "reel" ? "REEL" : "IMG"));

    const body = el("span", "igr-body");
    const bar = el("span", "igr-bar");
    bar.style.width = p.metric != null && top ? `${Math.max(2, (p.metric / top) * 100)}%` : "0%";
    body.appendChild(bar);

    const value = el("span", "igr-value", p.display);
    value.appendChild(el("span", "igr-unit", p.unit));

    const byDate = state.sort in BY_DATE;
    const bits = [];
    const stamp = byDate && shortDate(p.time);
    if (stamp) bits.push(stamp);
    if (p.likes != null && p.unit !== "likes") bits.push(`${compact(p.likes)} likes`);
    if (p.views != null && p.unit !== "views") bits.push(`${compact(p.views)} views`);
    // Two figures is what the row width holds. Comments fill the third slot
    // only when it's free; they're always in the preview card anyway.
    if (p.comments != null && bits.length < 2) bits.push(`${compact(p.comments)} comments`);
    body.append(value, el("span", "igr-counts", bits.join(" · ") || "no counts for this post"));

    link.append(rankNum, thumb, body);

    const eye = el("button", "igr-icon igr-eye");
    eye.innerHTML = ICON.eye;
    eye.title = "Preview";
    eye.setAttribute("aria-label", `Preview post ${rank}`);
    eye.onclick = (e) => { e.preventDefault(); openPreview(rank - 1); };

    row.append(box, link, eye);
    return row;
  }

  /* --------------------------------------------------------------- licence */

  let updateDismissed = false;

  /* ------------------------------------------------------- changelog window

  Two states share one layout. When there is nothing to install it reports the
  version you have and lists what that version brought; when something is
  waiting it shows old -> new and lists what is coming. Labelling both "what's
  new" would be a small lie in the first case, which is the trap worth
  avoiding: the reader can't tell whether they already have those changes. */

  // The changelog entry for a given version: the top of the file if it matches,
  // otherwise whichever past release does.
  function entryFor(version) {
    if (!version) return null;
    if (update.latest && compareVersions(update.latest, version) === 0) {
      return { version: update.latest, date: update.date, added: update.added,
               fixed: update.fixed, notes: update.notes };
    }
    return (update.history || []).find((h) => compareVersions(h.version, version) === 0) || null;
  }

  function changeList(title, items, kind) {
    if (!items || !items.length) return null;
    const block = el("section", "igr-change");

    const head = el("div", `igr-change-head igr-change-head--${kind}`);
    const badge = el("span", "igr-change-badge");
    badge.innerHTML = kind === "added" ? ICON.plus : ICON.tick;
    head.append(badge, el("span", "igr-change-title", title));
    block.appendChild(head);

    const list = el("ul", "igr-change-list");
    items.forEach((text, i) => {
      const item = el("li", "igr-change-item", text);
      item.style.setProperty("--i", Math.min(i, 10));
      list.appendChild(item);
    });
    block.appendChild(list);
    return block;
  }

  function lastCheckedLine() {
    if (!update.checkedAt) return "Not checked yet";
    const when = new Date(update.checkedAt);
    return `Last checked: ${when.toLocaleDateString()}, ${when.toLocaleTimeString()}`;
  }

  function buildUpdateModal() {
    updateModal = el("div", "igr-modal igr-upmodal");
    updateModal.setAttribute("role", "dialog");
    updateModal.setAttribute("aria-modal", "true");
    updateModal.innerHTML = `
      <div class="igr-scrim" data-role="upscrim"></div>
      <div class="igr-card igr-upcard">
        <button class="igr-icon igr-upclose" data-role="upclose" aria-label="Close">${ICON.close}</button>
        <div class="igr-upbody" data-role="upbody"></div>
      </div>`;
    document.body.appendChild(updateModal);

    updateModal.querySelector('[data-role="upscrim"]').onclick = closeUpdateModal;
    updateModal.querySelector('[data-role="upclose"]').onclick = closeUpdateModal;

    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && updateModal && updateModal.classList.contains("is-open")) {
        e.preventDefault();
        closeUpdateModal();
      }
    });
  }

  function openUpdateModal({ recheck = false } = {}) {
    if (!updateModal) buildUpdateModal();
    applyTheme();
    renderUpdateModal();
    updateModal.classList.add("is-open");
    if (recheck) checkUpdate({ announce: true });
  }

  function closeUpdateModal() {
    if (updateModal) updateModal.classList.remove("is-open");
  }

  function renderUpdateModal() {
    if (!updateModal) return;
    const body = updateModal.querySelector('[data-role="upbody"]');
    const mine = thisVersion();
    const busy = update.state === "checking";
    const behind = update.state === "behind";
    const failed = update.state === "failed" || update.state === "unpublished";

    body.innerHTML = "";

    // --- crest -------------------------------------------------------------
    const crest = el("div", `igr-crest igr-crest--${behind ? "new" : failed ? "warn" : "ok"}`);
    crest.innerHTML = busy ? ICON.dots : behind ? ICON.down : failed ? ICON.warn : ICON.tickBig;
    body.appendChild(crest);

    body.appendChild(el("h2", "igr-uptitle",
      busy ? "Checking for updates"
      : behind ? "An update is ready"
      : failed ? "Couldn't check for updates"
      : "You're on the latest version"));

    // --- version pills -----------------------------------------------------
    const pills = el("div", "igr-pills");
    if (behind) {
      pills.append(
        el("span", "igr-pilllabel", "Installed"),
        el("span", "igr-pill igr-pill--old", `v${mine}`),
        (() => { const a = el("span", "igr-pillarrow"); a.innerHTML = ICON.next; return a; })(),
        el("span", "igr-pill igr-pill--new", `v${update.latest.replace(/^v/i, "")}`)
      );
    } else {
      pills.append(el("span", "igr-pilllabel", "Installed"), el("span", "igr-pill", `v${mine}`));
    }
    body.appendChild(pills);

    body.appendChild(el("p", "igr-upnote",
      busy ? "Asking GitHub…"
      : behind ? "Download it, unzip over your existing folder, then press reload on chrome://extensions. Your licence key and settings stay as they are."
      : failed ? update.reason
      : "Nothing to install right now."));

    // --- what changed ------------------------------------------------------
    const subject = behind ? entryFor(update.latest) : entryFor(mine);
    const heading = behind ? "What's new" : "In this version";

    if (subject) {
      const added = changeList(heading, subject.added, "added");
      const fixed = changeList(behind ? "Fixed" : "Fixed in this version", subject.fixed, "fixed");
      if (added) body.appendChild(added);
      if (fixed) body.appendChild(fixed);
      if (!added && !fixed && subject.notes) {
        body.appendChild(el("p", "igr-upnotes", subject.notes));
      }
    } else if (!busy && !failed) {
      body.appendChild(el("p", "igr-upnotes",
        "No changelog published for this version."));
    }

    // --- earlier releases --------------------------------------------------
    const earlier = (update.history || []).filter(
      (h) => h.version && compareVersions(h.version, behind ? update.latest : mine) < 0
    );
    if (earlier.length) {
      const fold = el("details", "igr-earlier");
      const sum = el("summary", "igr-earlier-sum", "Earlier versions");
      fold.appendChild(sum);
      earlier.forEach((h) => {
        const row = el("div", "igr-earlier-row");
        row.append(el("span", "igr-earlier-v", `v${h.version.replace(/^v/i, "")}`));
        if (h.date) row.append(el("span", "igr-earlier-d", h.date));
        fold.appendChild(row);
        [...(h.added || []), ...(h.fixed || [])].forEach((text) =>
          fold.appendChild(el("p", "igr-earlier-item", text)));
      });
      body.appendChild(fold);
    }

    // --- actions -----------------------------------------------------------
    const actions = el("div", "igr-upactions");
    if (behind) {
      const get = el("a", "igr-btn igr-btn--primary igr-upget", `Download v${update.latest.replace(/^v/i, "")}`);
      get.href = update.url;
      get.target = "_blank";
      get.rel = "noopener";
      get.onclick = () => sound("done");
      actions.appendChild(get);
    }
    const again = el("button", `igr-btn${behind ? "" : " igr-btn--primary"}`, busy ? "Checking…" : "Check now");
    again.disabled = busy;
    again.onclick = () => checkUpdate({ announce: true });
    actions.appendChild(again);
    body.appendChild(actions);

    // --- footer ------------------------------------------------------------
    const foot = el("div", "igr-upfoot");
    foot.appendChild(el("span", "igr-upchecked", lastCheckedLine()));

    // Remembering a chat is easy to do and, without this, impossible to undo.
    const saved = rememberedChat();
    if (saved) {
      const chip = el("button", "igr-chatchip");
      chip.innerHTML = `<span>${saved.replace(/</g, "&lt;")}</span>${ICON.close}`;
      chip.title = "Always sending to this chat — click to be asked again";
      chip.onclick = () => { rememberChat(""); renderUpdateModal(); };
      foot.appendChild(chip);
    }

    const audible = !!(window.__igRatioSound && window.__igRatioSound.enabled);
    const toggle = el("button", `igr-soundtoggle${audible ? " is-on" : ""}`);
    toggle.innerHTML = `${audible ? ICON.sound : ICON.mute}<span>Sound</span>`;
    toggle.title = audible ? "Sounds are on" : "Sounds are off";
    toggle.onclick = () => {
      if (!window.__igRatioSound) return;
      window.__igRatioSound.set(!window.__igRatioSound.enabled);
      renderUpdateModal();
    };
    foot.appendChild(toggle);
    body.appendChild(foot);
  }

  function renderUpdateBar() {
    if (!panel) return;
    const bar = panel.querySelector('[data-role="updatebar"]');
    if (!bar) return;

    if (update.state !== "behind" || updateDismissed) {
      bar.hidden = true;
      bar.innerHTML = "";
      return;
    }

    bar.hidden = false;
    bar.innerHTML = "";

    const text = el("span", "igr-updatebar-title",
      `Version ${update.latest.replace(/^v/i, "")} is ready`);

    const view = el("button", "igr-updatebar-view", "See what's new");
    view.onclick = () => openUpdateModal();

    const close = el("button", "igr-icon igr-updatebar-x");
    close.innerHTML = ICON.close;
    close.title = "Hide until next check";
    close.setAttribute("aria-label", "Hide this notice");
    close.onclick = () => { updateDismissed = true; renderUpdateBar(); };

    bar.append(text, view, close);
  }

  function refreshUpdateUI() {
    if (!panel) return;
    renderUpdateBar();

    const btn = panel.querySelector('[data-role="update"]');
    if (!btn) return;

    const mine = thisVersion();
    btn.textContent = {
      idle: `v${mine}`,
      checking: "Checking…",
      current: `v${mine} · latest`,
      behind: "Update now",
      unpublished: `v${mine} · no version file`,
      failed: `v${mine} · check failed`,
    }[update.state] || `v${mine}`;

    btn.className = `igr-update-btn${update.state === "behind" ? " is-behind" : ""}`;
    btn.title =
      update.state === "behind" ? `Version ${update.latest} is ready — see what changed`
      : update.state === "current" ? `You're on the latest version (${mine})`
      : update.state === "unpublished" ? "No version.json in the repo yet"
      : update.state === "failed" ? update.reason
      : "Check GitHub for a newer version";
  }

  function refreshLicenceUI() {
    if (!panel) return;
    const btn = panel.querySelector('[data-role="licence"]');
    if (btn) {
      btn.textContent = licenceLine();
      btn.className = `igr-licence-btn${licence.state === "licensed" ? " is-ok" : ""}`;
      btn.title = licenceDetail();
    }
    panel.classList.toggle("is-locked", !unlocked());
  }

  function openLicence() {
    if (!panel) return;
    const list = panel.querySelector('[data-role="list"]');
    list.innerHTML = "";
    list.appendChild(licenceView());
    list.scrollTop = 0;
  }

  function licenceView() {
    const box = el("div", "igr-gate");

    const mark = el("div", "igr-gate-mark");
    mark.innerHTML = ICON.lock;
    box.appendChild(mark);

    const headings = {
      licensed: "Licence active",
      trial: `Trial · ${licence.trialLeft} day${licence.trialLeft === 1 ? "" : "s"} left`,
      expired: "Subscription ended",
      locked: "Trial finished",
    };
    box.append(el("h3", "igr-gate-title", headings[licence.state] || "Activate"));

    if (licence.state === "licensed") {
      box.append(el("p", "igr-gate-copy",
        `Licensed to ${licence.holder}. ${licence.expires ? `Runs until ${licence.expires}.` : "No expiry."}`));
    } else if (licence.state === "trial") {
      box.append(el("p", "igr-gate-copy",
        "Everything is unlocked during the trial. Enter a key any time to keep going after it ends."));
    } else {
      box.append(el("p", "igr-gate-copy",
        licence.reason || "Enter your subscription key to carry on reading and downloading."));
    }

    const field = el("textarea", "igr-gate-field");
    field.rows = 3;
    field.placeholder = "Paste your subscription key";
    field.spellcheck = false;
    box.appendChild(field);

    const note = el("p", "igr-gate-note");
    const go = el("button", "igr-btn igr-btn--primary igr-gate-go", "Activate");
    go.onclick = async () => {
      go.disabled = true;
      const result = await activate(field.value);
      go.disabled = false;
      if (result.ok) {
        note.textContent = "";
        refreshLicenceUI();
        render();
        return;
      }
      note.textContent = result.reason || "That key isn't valid";
      note.classList.add("is-bad");
    };
    box.append(go, note);

    if (licence.state === "licensed") {
      const drop = el("button", "igr-gate-drop", "Remove this licence");
      drop.onclick = () => {
        try { localStorage.removeItem(LICENCE_KEY); } catch (_) {}
        checkLicence().then(() => { refreshLicenceUI(); render(); });
      };
      box.appendChild(drop);
    }

    box.append(el("p", "igr-gate-by", "IG Ratio · by Oeng Kimchour"));
    return box;
  }

  /* --------------------------------------------------------------- preview */

  let modal = null;
  let viewIndex = 0;
  let previewList = [];
  let slideIndex = 0;   // which slide of a carousel is showing

  const slidesOf = (p) => (p && Array.isArray(p.slides) && p.slides.length > 1 ? p.slides : null);

  /* A carousel slide carries its own media but borrows the post's counts,
   * caption and link, so the rest of the card needs no special casing. */
  function viewOf(p) {
    const slides = slidesOf(p);
    if (!slides) return p;
    const slide = slides[Math.min(slideIndex, slides.length - 1)];
    return {
      ...p,
      kind: slide.kind || p.kind,
      preview: slide.preview || p.preview,
      thumb: slide.thumb || p.thumb,
      videos: slide.videos || null,
      slideNumber: slide.n,
      slideCount: slides.length,
      url: `${p.url}${p.url.includes("?") ? "&" : "?"}img_index=${slide.n}`,
    };
  }

  function buildModal() {
    modal = el("div", "igr-modal");
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.innerHTML = `
      <div class="igr-scrim" data-role="scrim"></div>
      <div class="igr-card">
        <div class="igr-card-top">
          <span class="igr-card-title" data-role="cardtitle"></span>
          <button class="igr-icon" data-role="close" aria-label="Close preview">${ICON.close}</button>
        </div>
        <div class="igr-media" data-role="media"></div>
        <div class="igr-figures" data-role="figures"></div>
        <p class="igr-caption" data-role="caption"></p>
        <div class="igr-copyrow">
          <button class="igr-btn" data-copy="image" data-label="Copy image">Copy image</button>
          <button class="igr-btn" data-copy="caption" data-label="Copy caption">Copy caption</button>
          <button class="igr-btn" data-copy="both" data-label="Copy both">Copy both</button>
        </div>
        <div class="igr-copyrow igr-copyrow--send">
          <button class="igr-btn igr-btn--send" data-role="claude" data-label="Send to Claude">
            ${ICON.send}<span>Send to Claude</span>
          </button>
        </div>
        <div class="igr-card-foot">
          <button class="igr-icon" data-role="prev" aria-label="Previous post">${ICON.prev}</button>
          <span class="igr-pos" data-role="pos"></span>
          <button class="igr-icon" data-role="next" aria-label="Next post">${ICON.next}</button>
          <button class="igr-btn" data-role="save" data-label="Download">Download</button>
          <a class="igr-btn igr-btn--primary" data-role="open" target="_blank" rel="noopener">Open</a>
        </div>
      </div>`;
    document.body.appendChild(modal);

    const q = (r) => modal.querySelector(`[data-role="${r}"]`);
    q("scrim").onclick = closePreview;
    q("close").onclick = closePreview;
    q("prev").onclick = () => step(-1);
    q("next").onclick = () => step(1);
    modal.querySelectorAll("[data-copy]").forEach((b) => { b.onclick = () => runCopy(b, b.dataset.copy); });
    q("save").onclick = () => saveOne(q("save"), viewOf(previewList[viewIndex]));
    q("claude").onclick = (e) => sendToClaude(e.currentTarget, previewList[viewIndex]);

    document.addEventListener("keydown", (e) => {
      if (!modal || !modal.classList.contains("is-open")) return;
      if (e.key === "Escape") { e.preventDefault(); closePreview(); }
      else if (e.key === "ArrowLeft") { e.preventDefault(); step(-1); }
      else if (e.key === "ArrowRight") { e.preventDefault(); step(1); }
    });
  }

  function step(delta) {
    if (!previewList.length) return;

    // Inside a carousel the arrows move between slides, the way they do on
    // Instagram itself, and only move on to the next post at either end.
    const slides = slidesOf(previewList[viewIndex]);
    if (slides) {
      const next = slideIndex + delta;
      if (next >= 0 && next < slides.length) {
        slideIndex = next;
        return showShot();
      }
    }

    if (previewList.length === 1 && !slides) return;
    viewIndex = (viewIndex + delta + previewList.length) % previewList.length;

    // Coming backwards into a carousel should land on its last slide.
    const arriving = slidesOf(previewList[viewIndex]);
    slideIndex = delta < 0 && arriving ? arriving.length - 1 : 0;
    showShot();
  }

  // The list comes from the caller: the ranked table on a profile, or a single
  // captured post on the feed.
  function openPreview(index, list) {
    previewList = list || shownRows;
    if (!previewList.length) return;
    if (!modal) buildModal();
    viewIndex = Math.max(0, Math.min(index, previewList.length - 1));

    /* Opening a post at a particular slide — instagram.com/p/CODE/?img_index=2
     * — should start on that slide rather than snapping back to the first. */
    const wanted = Number(new URLSearchParams(location.search).get("img_index"));
    const slides = slidesOf(previewList[viewIndex]);
    const onThisPost = slides && location.pathname.includes(previewList[viewIndex].code);
    slideIndex = onThisPost && wanted >= 1 && wanted <= slides.length ? wanted - 1 : 0;
    applyTheme();
    showShot();
    modal.classList.add("is-open");
  }

  function closePreview() {
    if (!modal) return;
    modal.classList.remove("is-open");
    modal.querySelector('[data-role="media"]').innerHTML = ""; // stops any video
  }

  /* Direct video URLs are signed and expire, and the profile feed doesn't
   * always carry them at all. Rather than show a dead player, fall back to
   * Instagram's own embed, which always plays and needs no credentials. */
  function mountEmbed(box, p) {
    box.innerHTML = "";
    const frame = document.createElement("iframe");
    frame.className = "igr-embed";
    frame.src = `https://www.instagram.com/${p.kind === "reel" ? "reel" : "p"}/${p.code}/embed/`;
    frame.allow = "autoplay; clipboard-write; encrypted-media; picture-in-picture";
    frame.setAttribute("allowfullscreen", "");
    frame.setAttribute("scrolling", "no");
    frame.title = "Instagram player";
    box.appendChild(frame);
  }

  // box here is the media frame, a layer of its own so that swapping in the
  // embed fallback can't remove the slide dots sitting alongside it.
  function mountMedia(box, p) {
    box.innerHTML = "";
    const clip = previewUrl(p);

    if (clip) {
      const video = document.createElement("video");
      video.src = clip;
      video.poster = p.preview || p.thumb || "";
      video.autoplay = true;
      video.loop = true;
      video.muted = true;
      video.playsInline = true;
      video.controls = true;
      video.onerror = () => mountEmbed(box, p);
      box.appendChild(video);
      // A src that resolves but never decodes fails silently, so check on it.
      setTimeout(() => {
        if (video.isConnected && video.readyState === 0 && !video.error) mountEmbed(box, p);
      }, 3500);
      return;
    }

    if (p.kind === "reel") return mountEmbed(box, p); // something playable straight away

    const still = p.preview || p.thumb;
    if (still) {
      const img = el("img");
      img.src = still;
      img.alt = p.alt || "";
      img.onerror = () => {
        if (p.thumb && img.src !== p.thumb) img.src = p.thumb;
        else mountEmbed(box, p);
      };
      box.appendChild(img);
      return;
    }

    mountEmbed(box, p);
  }

  /* Slide controls sit on the image itself, the way Instagram does it: arrows
   * at the edges, dots underneath. With a dozen slides the dots are too small
   * to aim at, so the arrows are what you actually use. */
  function mountSlideControls(box, p) {
    const slides = slidesOf(p);
    if (!slides) return;

    const jump = (to) => {
      slideIndex = Math.max(0, Math.min(to, slides.length - 1));
      showShot();
    };

    for (const dir of ["prev", "next"]) {
      const at = dir === "prev" ? 0 : slides.length - 1;
      if (slideIndex === at) continue; // no arrow where there's nowhere to go
      const arrow = el("button", `igr-arrow igr-arrow--${dir}`);
      arrow.innerHTML = ICON[dir];
      arrow.title = dir === "prev" ? "Previous slide" : "Next slide";
      arrow.setAttribute("aria-label", arrow.title);
      arrow.onclick = (e) => { e.stopPropagation(); jump(slideIndex + (dir === "prev" ? -1 : 1)); };
      box.appendChild(arrow);
    }

    const strip = el("div", "igr-dots");
    // Past a dozen slides the dots stop being aimable, so show a count instead.
    if (slides.length > 10) {
      strip.classList.add("igr-dots--count");
      strip.appendChild(el("span", null, `${slideIndex + 1} / ${slides.length}`));
    } else {
      slides.forEach((slide, i) => {
        const dot = el("button", `igr-dot${i === slideIndex ? " is-on" : ""}`);
        dot.title = `Slide ${i + 1}`;
        dot.setAttribute("aria-label", `Slide ${i + 1} of ${slides.length}`);
        dot.onclick = (e) => { e.stopPropagation(); jump(i); };
        strip.appendChild(dot);
      });
    }
    box.appendChild(strip);
  }

  function showShot() {
    const p = previewList[viewIndex];
    if (!p) return closePreview();
    const q = (r) => modal.querySelector(`[data-role="${r}"]`);

    // Captions and dates are missing on a photo just as often as on a reel,
    // and without this the copy buttons sit disabled forever.
    if (needsLookup(p)) {
      lookupMedia(p)
        .then((gained) => {
          if (!gained) return;
          if (modal && modal.classList.contains("is-open") && previewList[viewIndex] === p) showShot();
          refreshCapture();
          if (panel) render();
        })
        .catch((err) => console.warn("[IG Ratio]", err));
    }

    const view = viewOf(p);
    const when = fullDate(p.time);
    const label = view.slideCount
      ? `${view.kind === "reel" ? "Video" : "Image"} ${view.slideNumber} of ${view.slideCount}`
      : view.kind === "reel" ? "Reel" : "Image";
    q("cardtitle").textContent =
      `${String(viewIndex + 1).padStart(2, "0")} · ${label}${when ? ` · ${when}` : ""}`;

    /* The wrapper shrinks to the image so the arrows land on its edges
     * rather than out in the letterbox beside it. */
    const stage = q("media");
    stage.innerHTML = "";
    const wrap = el("div", "igr-slidewrap");
    const frame = el("div", "igr-frame");
    wrap.appendChild(frame);
    mountMedia(frame, view);
    mountSlideControls(wrap, p);
    stage.appendChild(wrap);

    const figures = q("figures");
    figures.innerHTML = "";
    for (const [k, v] of [["Likes", fmt(p.likes)], ["Views", fmt(p.views)],
                          ["Comments", fmt(p.comments)], ["Ratio", pct(p.ratio)]]) {
      const cell = el("div", "igr-fig");
      cell.append(el("p", "igr-eyebrow", k), el("div", "igr-fig-v", v));
      figures.appendChild(cell);
    }

    const cap = q("caption");
    cap.textContent = p.caption || "";
    cap.hidden = !p.caption;

    q("pos").textContent = view.slideCount
      ? `${view.slideNumber} / ${view.slideCount}`
      : `${viewIndex + 1} / ${previewList.length}`;
    q("open").href = view.url;

    const save = q("save");
    clearTimeout(save.__resetTimer);
    save.textContent = save.dataset.label;
    save.disabled = !assetOf(view);

    const claude = q("claude");
    clearTimeout(claude.__resetTimer);
    claude.innerHTML = `${ICON.send}<span>${claude.dataset.label}</span>`;
    claude.disabled = !(view.preview || view.thumb) && !p.caption;

    modal.querySelectorAll("[data-copy]").forEach((btn) => {
      clearTimeout(btn.__resetTimer);
      btn.textContent = btn.dataset.label;
      const needsImage = btn.dataset.copy !== "caption";
      const needsCaption = btn.dataset.copy !== "image";
      btn.disabled = (needsImage && !(view.preview || view.thumb)) || (needsCaption && !p.caption);
    });
  }

  /* -------------------------------------------------------------- clipboard */

  async function fetchImage(url) {
    const res = await fetch(url, { mode: "cors", credentials: "omit" });
    if (!res.ok) throw new Error(`image fetch failed: ${res.status}`);
    return await res.blob();
  }

  // The image/png slot only takes PNG, so anything else gets repainted.
  async function toPng(blob) {
    if (blob.type === "image/png") return blob;
    const bitmap = await createImageBitmap(blob);
    const canvas = document.createElement("canvas");
    canvas.width = bitmap.width;
    canvas.height = bitmap.height;
    canvas.getContext("2d").drawImage(bitmap, 0, 0);
    return await new Promise((ok, no) =>
      canvas.toBlob((b) => (b ? ok(b) : no(new Error("could not encode PNG"))), "image/png")
    );
  }

  function blobToDataUri(blob) {
    return new Promise((ok, no) => {
      const reader = new FileReader();
      reader.onload = () => ok(reader.result);
      reader.onerror = () => no(new Error("could not read image"));
      reader.readAsDataURL(blob);
    });
  }

  const escapeHtml = (s) =>
    s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
    } catch (_) {
      // Older path, still handy when the clipboard API is blocked.
      const ta = el("textarea");
      ta.value = text;
      ta.style.cssText = "position:fixed;top:-1000px;opacity:0";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
    }
  }

  // Passing promises to ClipboardItem keeps the user gesture alive while the
  // image downloads, which a plain await would spend.
  async function copyImage(url) {
    await navigator.clipboard.write([new ClipboardItem({ "image/png": fetchImage(url).then(toPng) })]);
  }

  /* One clipboard entry carrying three versions of the same post.
   *
   * A clipboard entry is not a list of things to paste — it is one thing
   * described several ways, and the app you paste into picks the version it
   * understands. Handing it only an image and some text means a rich editor
   * takes the image and drops the text, which is exactly the complaint.
   *
   * The fix is the HTML version: it contains the picture and the caption in a
   * single fragment, so an editor that prefers HTML pastes both together.
   * The other two remain as fallbacks for plain text boxes and for targets
   * that accept nothing but a bitmap.
   */
  async function copyBundle(url, caption) {
    const source = fetchImage(url);

    const html = (async () => {
      const raw = await source;
      // Deliberately the original JPEG: a PNG data URI runs several times
      // larger and some editors choke on an oversized paste.
      const uri = await blobToDataUri(raw);
      const body = escapeHtml(caption).replace(/\r?\n/g, "<br>");
      return new Blob([`<div><img src="${uri}" alt=""><p>${body}</p></div>`], { type: "text/html" });
    })();

    await navigator.clipboard.write([
      new ClipboardItem({
        "text/html": html,
        "image/png": source.then(toPng),
        "text/plain": new Blob([caption], { type: "text/plain" }),
      }),
    ]);
  }

  /* Some of these buttons are an icon plus a label, some are label only, and
   * some are icon only. An icon-only button can't say "Sent", so it swaps to a
   * tick or a cross — otherwise the click would appear to do nothing at all.
   *
   * tone: "ok" | "bad" | "busy". Busy states hold until the next flash. */
  function flash(btn, message, tone = "ok") {
    clearTimeout(btn.__resetTimer);
    const label = btn.querySelector("span");
    const iconOnly = !label && !btn.dataset.label;

    if (iconOnly) {
      if (!btn.dataset.icon) btn.dataset.icon = btn.innerHTML;
      btn.innerHTML = tone === "busy" ? ICON.dots : tone === "bad" ? ICON.cross : ICON.tick;
      btn.classList.toggle("is-bad", tone === "bad");
      btn.classList.toggle("is-ok", tone === "ok");
    } else if (label) {
      label.textContent = message;
    } else {
      btn.textContent = message;
    }
    btn.title = message;

    if (tone === "busy") return; // the outcome replaces it

    btn.__resetTimer = setTimeout(() => {
      if (iconOnly) {
        btn.innerHTML = btn.dataset.icon;
        btn.classList.remove("is-bad", "is-ok");
      } else if (label) {
        label.textContent = btn.dataset.label || "";
      } else if (btn.dataset.label) {
        btn.textContent = btn.dataset.label;
      }
      btn.title = btn.dataset.title || "";
    }, 1800);
  }

  async function runCopy(btn, what) {
    const p = viewOf(previewList[viewIndex]);
    if (!p) return;
    const image = p.preview || p.thumb;
    const caption = p.caption || "";

    try {
      if (what === "caption") {
        if (!caption) return flash(btn, "No caption", "bad");
        await copyText(caption);
        return flash(btn, "Copied");
      }
      if (!image) return flash(btn, "No image", "bad");
      if (what === "both" && caption) await copyBundle(image, caption);
      else await copyImage(image);
      flash(btn, "Copied");
    } catch (err) {
      console.warn("[IG Ratio] copy failed", err);
      // Instagram's CDN sometimes refuses a cross-origin read. The link is
      // still worth something, so hand that over instead of nothing.
      if (what !== "caption" && image) {
        await copyText(what === "both" && caption ? `${image}\n\n${caption}` : image);
        return flash(btn, "Link copied");
      }
      flash(btn, "Couldn't copy", "bad");
    }
  }

  /* ------------------------------------------------------- filling the gaps

  The reels tab sends a stripped-down node: counts and a thumbnail, no video
  URL, no caption, no date. Falling back to the cover image would hand you a
  folder of JPEGs labelled with shortcodes, which is no use to anyone.

  Instagram's own media endpoint has all of it, so ask for it the same way the
  page would — same headers, same cookies, one call per post, only when a
  download actually needs it. */

  let lookupsBlocked = false;

  /* An Instagram shortcode is the media id written in base64 with a URL-safe
   * alphabet. Decoding it means a post can be looked up even when the feed
   * response told us nothing at all. */
  const SHORTCODE_ALPHABET =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";

  function pkFromShortcode(code) {
    if (!code || code.length > 24) return null;
    let value = 0n;
    for (const character of code) {
      const index = SHORTCODE_ALPHABET.indexOf(character);
      if (index < 0) return null;
      value = value * 64n + BigInt(index);
    }
    return value > 0n ? value.toString() : null;
  }

  function absorb(p, item) {
    if (!item) return false;
    let gained = false;

    const versions = Array.isArray(item.video_versions)
      ? item.video_versions
          .map((v) => ({ url: v.url, width: v.width || 0, height: v.height || 0 }))
          .filter((v) => v.url)
          .sort((a, b) => b.width - a.width)
      : null;
    if (versions && versions.length && !(p.videos && p.videos.length)) { p.videos = versions; gained = true; }

    const text = item.caption && typeof item.caption.text === "string" ? item.caption.text : null;
    if (text && !p.caption) { p.caption = text.slice(0, 2200); gained = true; }

    if (item.taken_at && !p.time) { p.time = item.taken_at; gained = true; }

    /* The page only ever renders rounded figures — "1.1K" reads back as 1,100.
     * These are the real numbers, so they replace what was scraped rather than
     * only filling blanks. */
    for (const [field, source] of [["likes", "like_count"], ["comments", "comment_count"]]) {
      const value = item[source];
      if (typeof value === "number" && isFinite(value) && p[field] !== value) { p[field] = value; gained = true; }
    }
    const plays = typeof item.play_count === "number" ? item.play_count
      : typeof item.ig_play_count === "number" ? item.ig_play_count
      : typeof item.view_count === "number" ? item.view_count : null;
    if (plays != null && p.views !== plays) { p.views = plays; gained = true; }

    const username = (item.user && item.user.username) || (item.owner && item.owner.username);
    if (username && !p.author) { p.author = username; gained = true; }

    if (!p.slides && Array.isArray(item.carousel_media) && item.carousel_media.length > 1) {
      p.slides = item.carousel_media.map((slide, i) => {
        const options = slide.image_versions2 && slide.image_versions2.candidates;
        const clips = Array.isArray(slide.video_versions)
          ? slide.video_versions
              .map((v) => ({ url: v.url, width: v.width || 0, height: v.height || 0 }))
              .filter((v) => v.url)
              .sort((a, b) => b.width - a.width)
          : null;
        return {
          n: i + 1,
          kind: slide.media_type === 2 || clips ? "reel" : "photo",
          preview: Array.isArray(options) && options.length ? options[0].url : null,
          thumb: Array.isArray(options) && options.length ? options[options.length - 1].url : null,
          videos: clips,
        };
      });
      gained = true;
    }

    const candidates = item.image_versions2 && item.image_versions2.candidates;
    if (Array.isArray(candidates) && candidates.length) {
      if (!p.preview) { p.preview = candidates[0].url; gained = true; }
      if (!p.thumb) { p.thumb = candidates[candidates.length - 1].url; gained = true; }
    }
    return gained;
  }

  async function lookupMedia(p) {
    if (!p || !p.pk || p.__lookedUp || lookupsBlocked) return false;
    // Rows are copies made during ranking, so mark and fill the stored post
    // too — otherwise the next render throws the answer away.
    const stored = state.posts.get(p.code);
    p.__tries = (p.__tries || 0) + 1;
    p.__lookedUp = true;
    if (stored) { stored.__tries = p.__tries; stored.__lookedUp = true; }

    const allowRetry = () => {
      // Two attempts, then leave it alone rather than hammering.
      if (p.__tries >= 2) return;
      p.__lookedUp = false;
      if (stored) stored.__lookedUp = false;
    };
    let res;
    try {
      res = await fetch(`https://www.instagram.com/api/v1/media/${p.pk}/info/`, {
        headers: igHeaders,
        credentials: "include",
      });
    } catch (err) {
      allowRetry();
      throw err;
    }
    if (res.status === 401 || res.status === 403 || res.status === 429) {
      lookupsBlocked = true; // stop asking once Instagram says no
      throw new Error(`lookup refused: ${res.status}`);
    }
    if (!res.ok) { allowRetry(); throw new Error(`lookup failed: ${res.status}`); }
    const data = await res.json();
    const item = data && data.items && data.items[0];
    if (stored && stored !== p) absorb(stored, item);
    return absorb(p, item);
  }

  const needsLookup = (p) =>
    !!p.pk && !p.__lookedUp && ((p.kind === "reel" && !videoUrl(p)) || (!p.caption && !p.time));

  /* -------------------------------------------------------- picking files */

  function assetOf(p) {
    if (p.kind === "reel") {
      const url = videoUrl(p);
      return url ? { url, ext: ".mp4" } : null; // never silently substitute the cover
    }
    const url = p.preview || p.thumb;
    return url ? { url, ext: ".jpg" } : null;
  }

  // A reel with an id can still be fetched, it just needs the lookup first.
  const canDownload = (p) => !!assetOf(p) || (p.kind === "reel" && !!p.pk && !lookupsBlocked);
  const downloadable = () => shownRows.filter(canDownload);

  function toggleAll(on) {
    for (const p of downloadable()) {
      if (on) state.selected.add(p.code);
      else state.selected.delete(p.code);
    }
    render();
  }

  function togglePost(code, on) {
    if (on) state.selected.add(code);
    else state.selected.delete(code);
    refreshPicker();
  }

  function refreshPicker() {
    if (!panel) return;
    const box = panel.querySelector('[data-role="picker"]');
    const all = downloadable();
    box.hidden = !all.length;
    if (!all.length) return;

    const picked = all.filter((p) => state.selected.has(p.code)).length;
    const master = panel.querySelector('[data-role="selall"]');
    master.checked = picked > 0 && picked === all.length;
    master.indeterminate = picked > 0 && picked < all.length;

    panel.querySelector('[data-role="sellabel"]').textContent =
      picked ? `${picked} of ${all.length} selected` : "Select all";

    const go = panel.querySelector('[data-role="zip"]');
    go.disabled = !picked || state.saving;
    go.textContent = picked ? `Download ZIP · ${picked} file${picked === 1 ? "" : "s"}` : "Download ZIP";
  }

  async function fetchAsset(url) {
    const res = await fetch(url, { mode: "cors", credentials: "omit" });
    if (!res.ok) throw new Error(`${res.status}`);
    return await res.blob();
  }

  function saveBlob(blob, name) {
    const url = URL.createObjectURL(blob);
    const a = el("a");
    a.href = url;
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }

  async function saveOne(btn, p) {
    if (!p) return;
    if (needsLookup(p)) {
      flash(btn, "Looking up…", "busy");
      try { await lookupMedia(p); } catch (err) { console.warn("[IG Ratio]", err); }
    }
    const asset = assetOf(p);
    if (!asset) return flash(btn, "Nothing to save", "bad");
    flash(btn, "Saving…", "busy");
    try {
      saveBlob(await fetchAsset(asset.url), fileName(p, asset.ext));
      flash(btn, "Saved");
    } catch (err) {
      console.warn("[IG Ratio] download failed", err);
      // Blocked cross-origin reads still open fine in a tab.
      window.open(asset.url, "_blank", "noopener");
      flash(btn, "Opened in tab");
    }
  }

  async function downloadZip() {
    if (state.saving) return;
    if (!unlocked()) return openLicence();
    const picks = [...state.posts.values()].filter((p) => state.selected.has(p.code) && canDownload(p));
    if (!picks.length) return;

    state.saving = true;
    state.cancel = false;
    refreshPicker();
    const entries = [];
    const failed = [];

    // Fill in video URLs, captions and dates before fetching anything, so the
    // files come out named properly rather than as bare shortcodes.
    const gaps = picks.filter(needsLookup);
    for (let i = 0; i < gaps.length; i++) {
      if (state.cancel || lookupsBlocked) break;
      setStatus(`Looking up ${i + 1} of ${gaps.length}`);
      setProgress(((i + 1) / gaps.length) * 100);
      try { await lookupMedia(gaps[i]); } catch (err) { console.warn("[IG Ratio]", err); }
      await sleep(140); // don't hammer
    }

    for (let i = 0; i < picks.length; i++) {
      if (state.cancel) break;
      const p = picks[i];
      setStatus(`Fetching ${i + 1} of ${picks.length}`);
      setProgress(((i + 1) / picks.length) * 100);
      // A carousel is several files, not one.
      const slides = slidesOf(p);
      const parts = slides
        ? slides.map((slide) => ({
            ...p, kind: slide.kind || p.kind, preview: slide.preview, thumb: slide.thumb,
            videos: slide.videos || null, slideNumber: slide.n, slideCount: slides.length,
          }))
        : [p];

      let saved = false;
      for (const part of parts) {
        const partAsset = assetOf(part);
        if (!partAsset) continue;
        try {
          entries.push({
            name: fileName(part, partAsset.ext),
            blob: await fetchAsset(partAsset.url),
            date: p.time ? new Date(p.time * 1000) : undefined,
          });
          saved = true;
        } catch (err) { /* counted below */ }
      }
      if (!saved) failed.push(p.code);
    }

    if (entries.length) {
      setStatus("Building archive");
      const stamp = new Date().toISOString().slice(0, 10);
      saveBlob(await window.__igRatioZip.build(entries), `${handle().replace("@", "")} ${stamp}.zip`);
    }

    setProgress(0);
    state.saving = false;
    refreshPicker();
    render(); // captions and dates picked up along the way
    sound(entries.length ? "done" : "fail");
    setStatus(
      failed.length
        ? `Saved ${entries.length}, ${failed.length} unavailable`
        : `Saved ${entries.length} file${entries.length === 1 ? "" : "s"}`
    );
  }

  /* --------------------------------------------------------- send to Claude

  The image can't travel between tabs as a Blob, so it goes as a data URI and
  is rebuilt on the other side. Downscaled first: a full-size Instagram photo
  is several megabytes, which is slow through the messaging channel and more
  resolution than a chat needs. */

  const SEND_MAX_EDGE = 1600;

  async function toDataUri(url) {
    const blob = await fetchAsset(url);
    if (blob.size <= 900 * 1024) return await readAsDataUri(blob);

    try {
      const bitmap = await createImageBitmap(blob);
      const scale = Math.min(1, SEND_MAX_EDGE / Math.max(bitmap.width, bitmap.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(bitmap.width * scale);
      canvas.height = Math.round(bitmap.height * scale);
      canvas.getContext("2d").drawImage(bitmap, 0, 0, canvas.width, canvas.height);
      return canvas.toDataURL("image/jpeg", 0.86);
    } catch (_) {
      return await readAsDataUri(blob); // not decodable, send as-is
    }
  }

  function readAsDataUri(blob) {
    return new Promise((ok, no) => {
      const reader = new FileReader();
      reader.onload = () => ok(reader.result);
      reader.onerror = () => no(new Error("could not read image"));
      reader.readAsDataURL(blob);
    });
  }

  /* ---------------------------------------------------------- choosing a chat

  With several Claude tabs open, guessing wrong means the post lands in the
  middle of an unrelated conversation. So when there's more than one, ask —
  showing the chat names, not tab numbers. The choice can be remembered, and
  it's remembered by name rather than tab id because ids don't survive a
  browser restart. */

  const CHAT_PREF = "igratio:claudechat";

  const rememberedChat = () => {
    try { return localStorage.getItem(CHAT_PREF) || ""; } catch (_) { return ""; }
  };
  const rememberChat = (name) => {
    try {
      if (name) localStorage.setItem(CHAT_PREF, name);
      else localStorage.removeItem(CHAT_PREF);
    } catch (_) {}
  };

  async function claudeTabs() {
    try {
      const reply = await chrome.runtime.sendMessage({ type: "igr-list-claude-tabs" });
      return (reply && reply.tabs) || [];
    } catch (_) {
      return [];
    }
  }

  function askWhichChat(tabs) {
    return new Promise((resolve) => {
      if (!chatPicker) {
        chatPicker = el("div", "igr-modal igr-chatmodal");
        chatPicker.setAttribute("role", "dialog");
        chatPicker.setAttribute("aria-modal", "true");
        chatPicker.innerHTML = `
          <div class="igr-scrim" data-role="chatscrim"></div>
          <div class="igr-card igr-chatcard">
            <div class="igr-chathead">
              <div>
                <p class="igr-eyebrow">Send to Claude</p>
                <h3 class="igr-chattitle">Which chat?</h3>
              </div>
              <button class="igr-icon" data-role="chatclose" aria-label="Cancel">${ICON.close}</button>
            </div>
            <div class="igr-chatlist" data-role="chatlist"></div>
            <label class="igr-check igr-chatremember">
              <input type="checkbox" data-role="chatremember">
              <span>Remember this chat</span>
            </label>
          </div>`;
        document.body.appendChild(chatPicker);
      }

      applyTheme();
      const q = (r) => chatPicker.querySelector(`[data-role="${r}"]`);
      const list = q("chatlist");
      list.innerHTML = "";

      let settled = false;
      const finish = (value) => {
        if (settled) return;
        settled = true;
        chatPicker.classList.remove("is-open");
        resolve(value);
      };

      q("chatscrim").onclick = () => finish(null);
      q("chatclose").onclick = () => finish(null);

      const remember = q("chatremember");
      remember.checked = false;

      tabs.forEach((tab, i) => {
        const row = el("button", "igr-chatrow");
        row.style.setProperty("--i", Math.min(i, 10));

        const dot = el("span", "igr-chatdot");
        const body = el("span", "igr-chatbody");
        body.append(el("span", "igr-chatname", tab.name));
        if (tab.active) body.append(el("span", "igr-chattag", "In view"));

        const go = el("span", "igr-chatgo");
        go.innerHTML = ICON.next;

        row.append(dot, body, go);
        row.onclick = () => {
          if (remember.checked) rememberChat(tab.name);
          sound("current");
          finish(tab);
        };
        list.appendChild(row);
      });

      const fresh = el("button", "igr-chatrow igr-chatrow--new");
      fresh.innerHTML = `<span class="igr-chatdot igr-chatdot--new">${ICON.plus}</span>`;
      fresh.append(el("span", "igr-chatname", "Start a new chat"));
      fresh.onclick = () => finish({ id: null, name: "" });
      list.appendChild(fresh);

      chatPicker.classList.add("is-open");
    });
  }

  async function chooseClaudeTab() {
    const tabs = await claudeTabs();
    if (tabs.length <= 1) return { tabId: tabs.length ? tabs[0].id : null };

    const saved = rememberedChat();
    if (saved) {
      const matches = tabs.filter((t) => t.name === saved);
      if (matches.length === 1) return { tabId: matches[0].id };
    }

    const picked = await askWhichChat(tabs);
    if (!picked) return { cancelled: true };
    return { tabId: picked.id };
  }

  async function sendToClaude(btn, post) {
    if (!post) return;
    if (!unlocked()) return showLicence();

    const view = slidesOf(post) ? viewOf(post) : post;

    if (needsLookup(post)) {
      flash(btn, "Looking up…", "busy");
      try { await lookupMedia(post); } catch (err) { console.warn("[IG Ratio]", err); }
    }

    const still = view.preview || view.thumb;
    const caption = post.caption || "";
    if (!still && !caption) return flash(btn, "Nothing to send", "bad");

    const target = await chooseClaudeTab();
    if (target.cancelled) return flash(btn, "Cancelled", "bad");

    flash(btn, "Sending…", "busy");

    let image = null;
    if (still) {
      try {
        image = await toDataUri(still);
      } catch (err) {
        console.warn("[IG Ratio] image for Claude failed", err);
      }
    }

    try {
      const reply = await chrome.runtime.sendMessage({
        type: "igr-send-to-claude",
        payload: {
          tabId: target.tabId,
          image,
          mime: "image/jpeg",
          filename: fileName(view, ".jpg"),
          text: caption,
          url: view.url,
          author: post.author || "",
        },
      });

      if (reply && reply.ok) {
        sound("done");
        flash(btn, reply.partial ? "Sent, partly" : "Sent");
        if (reply.partial) setStatus(`Sent to Claude — ${reply.partial}`);
        return;
      }
      flash(btn, "Couldn't send", "bad");
      setStatus((reply && reply.reason) || "Couldn't reach Claude");
    } catch (err) {
      console.warn("[IG Ratio] send failed", err);
      flash(btn, "Couldn't send", "bad");
      setStatus("Couldn't reach Claude — is the extension still loaded?");
    }
  }

  /* -------------------------------------------------------------------- CSV */

  function exportCsv() {
    const { rows } = ranked();
    if (!rows.length) return;
    const lines = ["rank,shortcode,type,posted,likes,views,comments,likes_per_view,url"];
    rows.forEach((p, i) => {
      lines.push([
        i + 1, p.code, p.kind,
        p.time ? new Date(p.time * 1000).toISOString().slice(0, 10) : "",
        p.likes ?? "", p.views ?? "", p.comments ?? "",
        p.ratio == null ? "" : p.ratio.toFixed(6), p.url,
      ].join(","));
    });
    const blob = new Blob([lines.join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = el("a");
    a.href = url;
    a.download = `ig-ratio-${location.pathname.replace(/\//g, "") || "profile"}-${state.filter}.csv`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }

  /* ------------------------------------------------------------ feed capture

  On a profile you want the whole grid ranked. On the feed you want the one
  post in front of you. So on feed and permalink pages the launcher is
  replaced by a bar that follows the scroll: whatever post is sitting in the
  middle of the window is the one it's holding, updated once scrolling stops.

  The feed's own responses carry more than the profile grid does — caption,
  video renditions, author, date all arrive with the post — so a capture
  usually needs no extra lookup at all. */

  let tally = null;        // the "N kept" counter
  let watcher = null;      // Instagram re-renders posts constantly
  let mountTimer = null;

  function postFromArticle(art) {
    const link = art.querySelector('a[href*="/p/"], a[href*="/reel/"], a[href*="/tv/"]');
    const found = link && (link.getAttribute("href") || "").match(/\/(p|reel|tv)\/([^/?#]+)/);
    if (!found) return null;

    const [, seg, code] = found;
    const known = state.posts.get(code);
    const image = postImage(art);

    const post = known || {
      code,
      order: state.posts.size,
      fromFeed: true,
      kind: seg === "p" ? "photo" : "reel",
      url: `https://www.instagram.com/${seg}/${code}/`,
      thumb: image ? image.src : null,
      alt: image ? (image.alt || "").slice(0, 120) : "",
    };

    // A /p/ post can still be a video, and the feed renders one when it is.
    if (art.querySelector("video")) post.kind = "reel";

    merge(post, readIcons(art)); // the feed shows likes and comments outright
    const fromNetwork = netData.get(code);
    if (fromNetwork) {
      for (const k of ["likes", "views", "comments"]) {
        if (post[k] == null && fromNetwork[k] != null) post[k] = fromNetwork[k];
      }
      for (const k of ["thumb", "preview", "videos", "slides", "caption", "time", "pk", "author"]) {
        if (!post[k] && fromNetwork[k]) post[k] = fromNetwork[k];
      }
      if (fromNetwork.kind) post.kind = fromNetwork.kind;
    }
    if (!post.pk) post.pk = pkFromShortcode(code);
    if (!post.author) {
      const handleLink = [...art.querySelectorAll('a[href^="/"]')]
        .map((a) => (a.getAttribute("href") || "").match(/^\/([^/?#]+)\/?$/))
        .find(Boolean);
      if (handleLink) post.author = handleLink[1];
    }
    return post;
  }

  /* One object per post, reused across preview, download and keep, so that
   * anything a lookup fills in is visible everywhere at once. */
  function postFor(art) {
    const fresh = postFromArticle(art);
    if (!fresh) return null;
    const stored = state.posts.get(fresh.code);
    if (stored) return stored;
    if (art.__igrPost && art.__igrPost.code === fresh.code) return merge(art.__igrPost, fresh);
    art.__igrPost = fresh;
    return fresh;
  }

  function keepPost(post) {
    if (!post) return;
    if (!unlocked()) return showLicence();
    if (!state.posts.has(post.code)) {
      post.order = state.posts.size;
      state.posts.set(post.code, post);
    }
    state.selected.add(post.code);
    refreshCapture();
    if (panel) render();

    // The feed sometimes hands over almost nothing, so fill the gaps now
    // rather than at download time when the name and caption are needed.
    if (needsLookup(post)) {
      lookupMedia(post)
        .then((gained) => { if (gained) { refreshCapture(); if (panel) render(); } })
        .catch((err) => console.warn("[IG Ratio]", err));
    }
  }

  function showLicence() {
    if (!panel) buildPanel();
    openLicence();
  }

  /* --------------------------------------------------------- inline controls

  The controls belong on the post, not in the corner of the window: you decide
  about a post while you are looking at it. They sit in the top-right of the
  post's own header and stay out of the way until you hover it. */

  /* Where the controls go.
   *
   * A post's header is the row carrying the author's name. In the feed that
   * row sits at the top of the article; in the post dialog the article spans
   * the whole overlay and the header sits in the side column — so anchoring
   * to the article's own corner throws the controls across the screen, next
   * to Instagram's close button.
   *
   * Anchoring to the header row instead puts them beside the author's name in
   * both layouts, which is also where they read best. */
  function headerOf(art) {
    const name = art.querySelector('header a[href^="/"]') ||
      [...art.querySelectorAll('a[href^="/"]')]
        .find((a) => /^\/[^/?#]+\/?$/.test(a.getAttribute("href") || "") && a.textContent.trim());
    if (!name) return null;

    const header = name.closest("header");
    if (header) return header;

    // No <header>: climb until the row is wide enough to be the header strip
    // but still short enough not to be the whole post.
    let node = name.parentElement;
    for (let i = 0; i < 6 && node && node !== art; i++) {
      const box = node.getBoundingClientRect();
      if (box.width > 180 && box.height > 24 && box.height < 110) return node;
      node = node.parentElement;
    }
    return name.parentElement;
  }

  function hostFor(art) {
    return art.querySelector(".igr-inline");
  }

  /* Instagram's own "..." menu sits at the end of the header row. Slotting in
   * just before it puts the controls in the gap after the username, which is
   * where they belong and where there is actually room. */
  function placeInHeader(header, host) {
    const flexible = /flex|grid/.test(getComputedStyle(header).display);
    host.classList.toggle("igr-inline--flow", flexible);

    if (!flexible) {
      // Fixed positions can collide on a narrow row, so only used as a last
      // resort when the header isn't a flex row at all.
      header.appendChild(host);
      return;
    }

    const menu = [...header.children].reverse().find((child) => child !== host);
    if (menu) header.insertBefore(host, menu);
    else header.appendChild(host);
  }

  function syncInline(art) {
    const host = hostFor(art);
    if (!host) return;
    const link = art.querySelector('a[href*="/p/"], a[href*="/reel/"], a[href*="/tv/"]');
    const found = link && (link.getAttribute("href") || "").match(/\/(p|reel|tv)\/([^/?#]+)/);
    const keep = host.querySelector('[data-act="keep"]');
    const kept = found ? state.posts.has(found[2]) : false;
    keep.textContent = kept ? "Kept" : "Keep";
    keep.disabled = kept;
  }

  function mountInline(art) {
    const existing = hostFor(art);
    const header = headerOf(art);
    if (existing) {
      // Instagram re-renders headers; re-home the controls if ours drifted.
      if (header && existing.parentElement !== header) placeInHeader(header, existing);
      return;
    }
    if (!art.querySelector('a[href*="/p/"], a[href*="/reel/"], a[href*="/tv/"]')) return;

    const anchor = header || art;
    if (!header && getComputedStyle(anchor).position === "static") anchor.style.position = "relative";
    art.classList.add("igr-host");

    const host = el("div", "igr-inline");
    host.innerHTML = `
      <button class="igr-chiplet" data-act="preview" aria-label="Preview this post" title="Preview">${ICON.eye}</button>
      <button class="igr-chiplet" data-act="save" data-title="Download" aria-label="Download this post" title="Download">${ICON.down}</button>
      <button class="igr-chiplet" data-act="claude" data-title="Send to Claude" aria-label="Send this post to Claude" title="Send to Claude">${ICON.send}</button>
      <button class="igr-keep" data-act="keep">Keep</button>
    `;

    host.querySelector('[data-act="preview"]').onclick = (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (!unlocked()) return showLicence();
      const post = postFor(art);
      if (!post) return;
      // Decorate in place rather than on a copy, so a lookup fired from the
      // preview reaches the kept list as well.
      Object.assign(post, decorate(withRatio(post), "ratio"));
      openPreview(0, [post]);
    };

    host.querySelector('[data-act="save"]').onclick = (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (!unlocked()) return showLicence();
      saveOne(e.currentTarget, postFor(art));
    };

    host.querySelector('[data-act="claude"]').onclick = (e) => {
      e.preventDefault();
      e.stopPropagation();
      sendToClaude(e.currentTarget, postFor(art));
    };

    host.querySelector('[data-act="keep"]').onclick = (e) => {
      e.preventDefault();
      e.stopPropagation();
      keepPost(postFor(art));
      syncInline(art);
    };

    art.addEventListener("mouseenter", () => syncInline(art));
    if (header) placeInHeader(header, host);
    else anchor.appendChild(host);
    paint(host, resolvedTheme());
    syncInline(art);
  }

  function mountAll() {
    if (pageKind() !== "feed") return;
    for (const art of document.querySelectorAll("article")) mountInline(art);
  }

  function scheduleMount() {
    clearTimeout(mountTimer);
    mountTimer = setTimeout(mountAll, 180);
  }

  function buildTally() {
    tally = el("button", "igr-tally");
    tally.hidden = true;
    tally.onclick = () => { if (!panel) buildPanel(); };
    document.body.appendChild(tally);
    applyTheme();
  }

  // Kept for the call sites that already refresh feed state after a change.
  function refreshCapture() {
    if (tally) {
      const count = state.posts.size;
      tally.hidden = !count || pageKind() !== "feed";
      tally.textContent = `${count} kept`;
    }
    for (const art of document.querySelectorAll("article.igr-host")) syncInline(art);
  }

  /* --------------------------------------------------------------- launcher */  /* --------------------------------------------------------------- launcher */

  function makeLauncher() {
    const b = el("button", "igr-launch");
    b.innerHTML = `${ICON.chart}<span>Post performance</span>`;
    b.onclick = () => {
      b.classList.add("is-hidden");
      if (!panel) buildPanel();
    };
    return b;
  }

  function isProfilePage() {
    const parts = location.pathname.split("/").filter(Boolean);
    if (!parts.length) return false;
    const reserved = ["explore", "direct", "accounts", "stories", "p", "reel", "reels", "tv", "about", "legal", "challenge"];
    if (reserved.includes(parts[0])) return false;
    return parts.length === 1 || ["reels", "tagged", "saved", "feed"].includes(parts[1]);
  }

  function isFeedPage() {
    const path = location.pathname;
    if (path === "/" || path === "") return true;                 // home feed
    if (/^\/(p|reel|tv)\/[^/]+\/?$/.test(path)) return true;      // a single post
    return /^\/(reels|explore)(\/|$)/.test(path);                  // reels feed, explore
  }

  const pageKind = () => (isProfilePage() ? "profile" : isFeedPage() ? "feed" : null);

  function sync() {
    const kind = pageKind();

    if (kind === "profile") {
      if (!launcher) { launcher = makeLauncher(); applyTheme(); }
      if (!launcher.isConnected) document.body.appendChild(launcher);
      if (!panel) launcher.classList.remove("is-hidden");
    } else if (launcher) {
      launcher.remove();
    }

    if (kind === "feed") {
      if (!tally) buildTally();
      if (!tally.isConnected) document.body.appendChild(tally);
      if (!watcher) {
        // Instagram swaps posts in and out as you scroll, so re-mount on change.
        watcher = new MutationObserver(scheduleMount);
        watcher.observe(document.body, { childList: true, subtree: true });
      }
      mountAll();
      refreshCapture();
    } else {
      if (watcher) { watcher.disconnect(); watcher = null; }
      if (tally) tally.hidden = true;
      for (const art of document.querySelectorAll("article.igr-host")) {
        art.classList.remove("igr-host");
        const host = hostFor(art);
        if (host) host.remove();
      }
    }

    if (!kind && panel) closePanel();
  }

  loadPrefs();
  checkLicence().then(() => { if (panel) { refreshLicenceUI(); render(); } });

  let lastPath = location.pathname;
  let lastKind = pageKind();

  setInterval(() => {
    if (location.pathname !== lastPath) {
      lastPath = location.pathname;
      const kind = pageKind();
      // Moving between feed pages keeps what you've kept; switching to a
      // profile grid is a different dataset, so that starts clean.
      if (kind !== lastKind || kind === "profile") {
        state.posts.clear();
        state.selected.clear();
      }
      lastKind = kind;
      if (panel) render();
      refreshCapture();
    }
    if (state.theme === "auto") applyTheme();
    sync();
  }, 1000);

  sync();
})();
