/* IG Ratio — reads likes and views off an Instagram profile grid and ranks
 * posts by likes ÷ views, highest first.
 *
 * Notes on why it's built this way:
 *  - Instagram recycles grid tiles while you scroll, so each tile is read the
 *    moment it appears rather than after a full scroll to the bottom.
 *  - View counts sit on the tile. Like counts only appear on hover, so each
 *    tile gets a synthetic mouseover.
 *  - Icons are matched by aria-label, not class name. Class names are
 *    obfuscated and change constantly; the labels survive much longer.
 */

(() => {
  "use strict";

  if (window.__igRatioLoaded) return;
  window.__igRatioLoaded = true;

  const HOVER_MS = 420;   // wait for the hover overlay to paint
  const SCROLL_MS = 1100; // wait for the next batch of tiles
  const STALL_LIMIT = 4;  // scrolls with no new posts before stopping
  const HOVER_FALLBACK_MAX = 24; // tiles worth hovering when the network gave nothing
  const EASE_OUT = "cubic-bezier(0.16, 1, 0.3, 1)"; // matches --igr-ease-out in ui.css
  const PREF_KEY = "igratio:prefs";

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const reduceMotion = () => window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  const state = {
    posts: new Map(),
    running: false,
    cancel: false,
    filter: "all",   // all | photo | reel
    sort: "ratio",   // ratio | likes | views
    theme: "auto",   // auto | light | dark
    quality: "high", // high | medium | low — which video rendition to download
    selected: new Set(),
    saving: false,
  };

  /* ================================================================= updates

  An unpacked extension can't replace itself — Chrome only auto-updates things
  installed from a store. So this checks GitHub, tells you whether your copy is
  behind, and takes you to the download. The install is still two steps you do
  by hand, and saying otherwise would be a lie dressed up as a button. */

  const REPO_URL = "https://github.com/Kimchour/IG-ratio";
  const UPDATE_CACHE = "igratio:update";
  const CHECK_EVERY = 12 * 60 * 60 * 1000; // twice a day is plenty

  const update = {
    state: "idle", latest: "", url: REPO_URL, notes: "", date: "", reason: "",
    missingFile: false, added: [], fixed: [], history: [], checkedAt: 0,
  };

  const sound = (name) => { try { window.__igRatioSound?.play(name); } catch (_) {} };

  const thisVersion = () => {
    try { return chrome.runtime.getManifest().version; } catch (_) { return "0.0.0"; }
  };

  // "v4.3.0" and "4.3" both mean the same thing here.
  function compareVersions(a, b) {
    const parts = (v) => String(v).replace(/^v/i, "").split(/[.\-+]/).map((n) => parseInt(n, 10) || 0);
    const left = parts(a);
    const right = parts(b);
    for (let i = 0; i < Math.max(left.length, right.length); i++) {
      const diff = (left[i] || 0) - (right[i] || 0);
      if (diff) return diff > 0 ? 1 : -1;
    }
    return 0;
  }

  function readUpdateCache() {
    try { return JSON.parse(localStorage.getItem(UPDATE_CACHE) || "null"); } catch (_) { return null; }
  }

  function writeUpdateCache(entry) {
    try { localStorage.setItem(UPDATE_CACHE, JSON.stringify(entry)); } catch (_) {}
  }

  function applyUpdateResult(result) {
    if (!result || !result.ok) {
      Object.assign(update, {
        state: result && result.missing ? "unpublished" : "failed",
        url: (result && result.repo) || REPO_URL,
        reason: (result && result.reason) || "Couldn't check",
      });
      return update;
    }

    const mine = thisVersion();

    const behind = compareVersions(result.version, mine) > 0;
    Object.assign(update, {
      state: behind ? "behind" : "current",
      latest: result.version,
      url: result.url || REPO_URL,
      notes: result.notes || "",
      date: result.date || "",
      missingFile: !!result.missingFile,
      added: result.added || [],
      fixed: result.fixed || [],
      history: result.history || [],
      reason: "",
    });
    return update;
  }

  async function checkUpdate({ quiet = false, announce = false } = {}) {
    const cached = readUpdateCache();
    if (quiet && cached && Date.now() - (cached.at || 0) < CHECK_EVERY) {
      applyUpdateResult(cached.result);
      update.checkedAt = cached.at || 0;
      // Without this a cached "update ready" never reached the panel, so the
      // notice vanished for the twelve hours between checks.
      refreshUpdateUI();
      return update;
    }

    update.state = "checking";
    if (!quiet) { updateDismissed = false; refreshUpdateUI(); }
    if (updateModal && updateModal.classList.contains("is-open")) renderUpdateModal();

    let result;
    try {
      result = await chrome.runtime.sendMessage({ type: "igr-check-update" });
    } catch (err) {
      result = { ok: false, reason: "Couldn't reach GitHub" };
    }

    if (result && result.ok) writeUpdateCache({ at: Date.now(), result });
    update.checkedAt = (readUpdateCache() || {}).at || Date.now();
    applyUpdateResult(result);
    refreshUpdateUI();
    if (updateModal && updateModal.classList.contains("is-open")) renderUpdateModal();
    if (announce) {
      sound(update.state === "behind" ? "update" : update.state === "current" ? "current" : "fail");
    }
    return update;
  }

  /* ================================================================ licence */

  const LICENCE_KEY = "igratio:licence";
  const TRIAL_KEY = "igratio:trial";
  const TRIAL_DAYS = 7;

  const licence = { state: "checking", holder: "", plan: "", expires: null, reason: "", trialLeft: 0 };

  function trialDaysLeft() {
    let started;
    try {
      started = Number(localStorage.getItem(TRIAL_KEY));
      if (!started) {
        started = Date.now();
        localStorage.setItem(TRIAL_KEY, String(started));
      }
    } catch (_) {
      return TRIAL_DAYS; // private mode — don't lock someone out over storage
    }
    const used = (Date.now() - started) / 86400000;
    return Math.max(0, Math.ceil(TRIAL_DAYS - used));
  }

  async function checkLicence() {
    let saved = "";
    try { saved = localStorage.getItem(LICENCE_KEY) || ""; } catch (_) {}

    if (saved && window.__igRatioLicence) {
      const result = await window.__igRatioLicence.verify(saved);
      if (result.ok) {
        Object.assign(licence, {
          state: "licensed", holder: result.holder, plan: result.plan,
          expires: result.expires, reason: "",
        });
        return;
      }
      licence.reason = result.reason || "";
      if (result.expired) {
        Object.assign(licence, { state: "expired", holder: result.holder, plan: result.plan });
        return;
      }
    }

    const left = trialDaysLeft();
    Object.assign(licence, { state: left > 0 ? "trial" : "locked", trialLeft: left });
  }

  async function activate(key) {
    if (!window.__igRatioLicence) return { ok: false, reason: "Licence check unavailable" };
    const result = await window.__igRatioLicence.verify(key);
    if (result.ok) {
      try { localStorage.setItem(LICENCE_KEY, String(key).trim()); } catch (_) {}
      Object.assign(licence, {
        state: "licensed", holder: result.holder, plan: result.plan,
        expires: result.expires, reason: "",
      });
    }
    return result;
  }

  const unlocked = () => licence.state === "licensed" || licence.state === "trial";

  function licenceLine() {
    if (licence.state === "licensed") return licence.plan || "Licensed";
    if (licence.state === "trial") return `Trial · ${licence.trialLeft}d`;
    if (licence.state === "expired") return "Ended";
    return "Not activated";
  }

  // The full wording, for the tooltip and the status bar.
  function licenceDetail() {
    if (licence.state === "licensed") {
      return licence.expires ? `${licence.plan} licence, to ${licence.expires}` : `${licence.plan} licence`;
    }
    if (licence.state === "trial") {
      return `Trial · ${licence.trialLeft} day${licence.trialLeft === 1 ? "" : "s"} left`;
    }
    if (licence.state === "expired") return "Subscription ended";
    return "Not activated";
  }

  /* ============================================================ preferences */

  function loadPrefs() {
    try {
      const saved = JSON.parse(localStorage.getItem(PREF_KEY) || "{}");
      for (const k of ["filter", "sort", "theme", "quality"]) {
        if (saved[k]) state[k] = saved[k];
      }
    } catch (_) { /* private mode, or nothing saved yet */ }
  }

  function savePrefs() {
    try {
      localStorage.setItem(PREF_KEY, JSON.stringify({
        filter: state.filter, sort: state.sort, theme: state.theme, quality: state.quality,
      }));
    } catch (_) { /* not worth bothering the user about */ }
  }

  /* ====================================================== counts from the page

  The grid markup doesn't carry like counts any more, so the real source is
  net.js in the page world, which forwards whatever Instagram itself fetches. */

  const netData = new Map();
  let netTimer = null;

  // Headers Instagram signs its own API calls with, forwarded by net.js.
  // The fallback app id is the long-standing public web one.
  let igHeaders = { "x-ig-app-id": "936619743392459" };

  window.addEventListener("message", (e) => {
    if (e.source !== window) return;
    const d = e.data;
    if (d && d.source === "ig-ratio-headers" && d.headers) {
      igHeaders = { ...igHeaders, ...d.headers };
      return;
    }
    if (!d || d.source !== "ig-ratio-net" || !Array.isArray(d.items)) return;

    for (const item of d.items) {
      if (!item || !item.code) continue;
      const prev = netData.get(item.code) || {};
      netData.set(item.code, {
        likes: item.likes ?? prev.likes ?? null,
        views: item.views ?? prev.views ?? null,
        comments: item.comments ?? prev.comments ?? null,
        kind: item.kind || prev.kind || null,
        pk: item.pk || prev.pk || null,
        author: item.author || prev.author || null,
        time: item.time ?? prev.time ?? null,
        thumb: prev.thumb || item.thumb || null,
        preview: prev.preview || item.preview || null,
        videos: prev.videos || item.videos || null,
        slides: prev.slides || item.slides || null,
        caption: prev.caption || item.caption || null,
      });
    }

    // Late arrivals are normal, so refresh the list once things settle.
    if (panel && !state.running && state.posts.size) {
      clearTimeout(netTimer);
      netTimer = setTimeout(() => { if (applyNet()) render(); }, 400);
    }
  });

  // net.js starts earlier than this script does, so ask it for the backlog.
  window.postMessage({ source: "ig-ratio-ready" }, "*");

  function applyNet() {
    let changed = false;
    for (const p of state.posts.values()) {
      const d = netData.get(p.code);
      if (!d) continue;
      for (const k of ["likes", "views", "comments"]) {
        if (p[k] == null && d[k] != null) { p[k] = d[k]; changed = true; }
      }
      if (d.kind && d.kind !== p.kind) { p.kind = d.kind; changed = true; }
      for (const k of ["thumb", "preview", "videos", "slides", "caption", "time", "pk", "author"]) {
        if (!p[k] && d[k]) { p[k] = d[k]; changed = true; }
      }
    }
    return changed;
  }

  /* ================================================================ parsing */

  // "1,234" -> 1234   "12.3K" -> 12300   "1.2M" -> 1200000
  function parseCount(text) {
    if (!text) return null;
    const t = text.replace(/\u00a0/g, " ").trim();
    const m = t.match(/^([\d.,]+)\s*([KMB])?$/i);
    if (!m) return null;
    const suffix = (m[2] || "").toUpperCase();
    let raw = m[1];
    if (suffix) raw = raw.replace(/,/g, ".");
    else raw = raw.replace(/[.,]/g, ""); // no suffix: separators are thousands
    const n = parseFloat(raw);
    if (!isFinite(n)) return null;
    const mult = suffix === "K" ? 1e3 : suffix === "M" ? 1e6 : suffix === "B" ? 1e9 : 1;
    return Math.round(n * mult);
  }

  const fmt = (n) => (n == null ? "—" : n.toLocaleString("en-US"));

  // Row lines are narrow, so they get rounded figures. Exact numbers live in
  // the preview card and the CSV.
  function compact(n) {
    if (n == null) return "—";
    if (n >= 1e6) return `${(n / 1e6).toFixed(n >= 1e7 ? 0 : 1)}M`;
    if (n >= 1e4) return `${Math.round(n / 1e3)}K`;
    if (n >= 1e3) return `${(n / 1e3).toFixed(1)}K`;
    return String(n);
  }

  function pct(r) {
    if (r == null) return "—";
    if (r >= 1) return `${(r * 100).toFixed(0)}%`;
    if (r >= 0.1) return `${(r * 100).toFixed(1)}%`;
    return `${(r * 100).toFixed(2)}%`;
  }

  // Instagram sends seconds, not milliseconds.
  function shortDate(t) {
    if (!t) return null;
    return new Date(t * 1000).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "2-digit" });
  }

  function fullDate(t) {
    if (!t) return null;
    return new Date(t * 1000).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
  }

  // Renditions arrive widest-first.
  function videoUrl(p, want = state.quality) {
    const v = p.videos;
    if (!v || !v.length) return null;
    if (want === "high") return v[0].url;
    if (want === "low") return v[v.length - 1].url;
    return v[Math.floor((v.length - 1) / 2)].url;
  }

  // Smallest rendition for playback: a preview should start, not buffer.
  const previewUrl = (p) => videoUrl(p, "low");

  // Files are named from the post's own caption so they stay recognisable
  // once they're sitting in a folder.
  function fileName(p, ext) {
    const date = p.time ? new Date(p.time * 1000).toISOString().slice(0, 10) : "";
    const title = (p.caption || "")
      .split("\n")[0]
      .replace(/[\\/:*?"<>|\u0000-\u001f]+/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 70)
      .replace(/[\s.]+$/, "");
    const who = p.fromFeed && p.author ? `@${p.author}` : "";
    const slide = p.slideCount ? `(${p.slideNumber} of ${p.slideCount})` : "";
    return `${[date, who, title, p.code, slide].filter(Boolean).join(" - ")}${ext}`;
  }

  /* =========================================================== tile reading */

  function gridAnchors() {
    const root = document.querySelector("main") || document.body;
    return [...root.querySelectorAll('a[href*="/p/"], a[href*="/reel/"]')];
  }

  function idOf(anchor) {
    const m = (anchor.getAttribute("href") || "").match(/\/(p|reel|tv)\/([^/?#]+)/);
    return m ? { seg: m[1], code: m[2] } : null;
  }

  // Reels and videos on one side, photos and carousels on the other.
  function classify(anchor, seg) {
    if (seg === "reel" || seg === "tv") return "reel";
    const labels = [...anchor.querySelectorAll("svg[aria-label]")]
      .map((s) => (s.getAttribute("aria-label") || "").toLowerCase())
      .join(" ");
    if (/clip|reel|video/.test(labels)) return "reel";
    return "photo"; // covers single images and carousels
  }

  // Find the number belonging to an icon by walking up a few parents.
  function countNearIcon(svg) {
    let node = svg;
    for (let i = 0; i < 4 && node; i++) {
      node = node.parentElement;
      if (!node) break;
      for (const span of node.querySelectorAll("span")) {
        if (span.querySelector("svg")) continue;
        const v = parseCount(span.textContent);
        if (v != null) return v;
      }
    }
    return null;
  }

  const LABELLED = /^\s*([\d.,]+\s*[KMB]?)\s+(likes?|comments?|views?|plays?)\s*$/i;

  /* Counts are read in two passes.
   *
   * First anything self-describing — "1,148 likes" — because that needs no
   * guessing at all.
   *
   * Then by icon adjacency, walking the subtree in document order and giving
   * each number to the icon that most recently preceded it. That matches how
   * the row actually reads on screen: heart, count, bubble, count. The old
   * approach climbed the tree from each icon and grabbed the first number it
   * found, which on the feed handed the like count to the comment icon. */
  function readIcons(scope) {
    const out = { likes: null, comments: null, views: null };
    const bucket = (label) => {
      const l = label.toLowerCase();
      if (l.includes("comment")) return "comments";
      if (l.includes("like")) return "likes";        // covers "Unlike"
      if (l.includes("view") || l.includes("play")) return "views";
      return null;
    };

    const walker = document.createTreeWalker(scope, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT);
    let pending = null;

    while (walker.nextNode()) {
      const node = walker.currentNode;

      if (node.nodeType === Node.ELEMENT_NODE) {
        if (node.tagName.toLowerCase() === "svg") pending = bucket(node.getAttribute("aria-label") || "");
        continue;
      }

      const text = node.nodeValue;
      if (!text || !text.trim()) continue;

      const described = text.match(LABELLED);
      if (described) {
        const key = bucket(described[2]);
        const value = parseCount(described[1]);
        if (key && value != null) out[key] = value; // self-describing wins
        pending = null;
        continue;
      }

      if (!pending || out[pending] != null) continue;
      const value = parseCount(text);
      if (value != null) { out[pending] = value; pending = null; }
    }
    return out;
  }

  // The first image in a feed post is the author's avatar, not the post.
  function postImage(scope) {
    let best = null;
    let biggest = 0;
    for (const img of scope.querySelectorAll("img")) {
      if ((img.getAttribute("alt") || "").toLowerCase().includes("profile picture")) continue;
      const box = img.getBoundingClientRect();
      const area = box.width * box.height;
      if (area > biggest) { biggest = area; best = img; }
    }
    return biggest >= 5000 ? best : null;
  }

  function merge(base, extra) {
    for (const k of ["likes", "comments", "views"]) {
      if (base[k] == null && extra[k] != null) base[k] = extra[k];
    }
    return base;
  }

  function clearHover(anchor) {
    const o = { bubbles: true, cancelable: true, view: window };
    anchor.dispatchEvent(new MouseEvent("mouseout", o));
    anchor.dispatchEvent(new MouseEvent("mouseleave", { ...o, bubbles: false }));
  }

  async function readTile(anchor) {
    const stats = readIcons(anchor); // views usually show without hovering

    const o = { bubbles: true, cancelable: true, view: window };
    anchor.dispatchEvent(new MouseEvent("mouseover", o));
    anchor.dispatchEvent(new MouseEvent("mouseenter", { ...o, bubbles: false }));
    anchor.dispatchEvent(new MouseEvent("mousemove", o));
    await sleep(HOVER_MS);
    merge(stats, readIcons(anchor));
    clearHover(anchor);

    const img = anchor.querySelector("img");
    return { ...stats, thumb: img ? img.src : null, alt: img ? (img.alt || "").slice(0, 120) : "" };
  }

  /* ============================================================== scanning */

  async function scan(limit, onTick) {
    state.cancel = false;
    let stalls = 0;

    // Pass one: walk the grid for post links and whatever the tiles show
    // outright, scrolling to make Instagram fetch the next batch.
    while (!state.cancel) {
      let foundNew = false;

      for (const anchor of gridAnchors()) {
        if (state.cancel) break;
        if (limit && state.posts.size >= limit) break;
        const id = idOf(anchor);
        if (!id || state.posts.has(id.code)) continue;

        const img = anchor.querySelector("img");
        state.posts.set(id.code, {
          code: id.code,
          order: state.posts.size, // the grid runs newest-first; used if no timestamp arrives
          kind: classify(anchor, id.seg),
          url: `https://www.instagram.com/${id.seg}/${id.code}/`,
          thumb: img ? img.src : null,
          alt: img ? (img.alt || "").slice(0, 120) : "",
          ...readIcons(anchor),
        });
        foundNew = true;
        onTick(state.posts.size);
      }

      applyNet();
      for (const p of state.posts.values()) if (!p.pk) p.pk = pkFromShortcode(p.code);
      if (limit && state.posts.size >= limit) break;
      stalls = foundNew ? 0 : stalls + 1;
      if (stalls >= STALL_LIMIT) break;

      window.scrollTo(0, document.body.scrollHeight);
      await sleep(SCROLL_MS);
    }

    // Responses for the last batch are often still in the air, so give them
    // a moment rather than reporting gaps that fill in a second later.
    if (!state.cancel) {
      onTick(state.posts.size, "Waiting for the last counts");
      await sleep(1400);
      applyNet();
    }

    // Pass two: anything the network didn't cover gets one hover attempt.
    const gaps = [...state.posts.values()].filter((p) => p.likes == null).slice(0, HOVER_FALLBACK_MAX);
    if (gaps.length && !state.cancel) {
      const byCode = new Map();
      for (const a of gridAnchors()) {
        const id = idOf(a);
        if (id) byCode.set(id.code, a);
      }
      let done = 0;
      for (const p of gaps) {
        if (state.cancel) break;
        const anchor = byCode.get(p.code);
        if (!anchor) continue;
        merge(p, await readTile(anchor));
        onTick(state.posts.size, `Filling gaps, ${++done} of ${gaps.length}`);
      }
    }

    applyNet();

    // A synthetic hover can outlive the scan if the page scrolled mid-read.
    // Sweep the grid so no overlay is left stuck open.
    gridAnchors().forEach(clearHover);
    return state.posts.size;
  }

  /* =============================================================== ranking */

  function visible() {
    const all = [...state.posts.values()];
    return state.filter === "all" ? all : all.filter((p) => p.kind === state.filter);
  }

  const withRatio = (p) => ({ ...p, ratio: p.likes != null && p.views ? p.likes / p.views : null });

  // Attach the number this row is being judged on, plus how to show it.
  function decorate(p, mode) {
    const chosen = {
      likes: [p.likes, fmt(p.likes), "likes"],
      views: [p.views, fmt(p.views), "views"],
      ratio: [p.ratio, pct(p.ratio), "likes / views"],
    }[mode];
    if (chosen[0] != null) return { ...p, metric: chosen[0], display: chosen[1], unit: chosen[2] };

    // This post doesn't carry the chosen number, so show whatever it does have.
    if (p.likes != null) return { ...p, metric: null, display: fmt(p.likes), unit: "likes" };
    if (p.views != null) return { ...p, metric: null, display: fmt(p.views), unit: "views" };
    return { ...p, metric: null, display: "—", unit: "" };
  }

  const BY_DATE = { newest: -1, oldest: 1 };

  function ranked() {
    const base = visible().map(withRatio);
    const wanted = state.sort;
    const byDate = wanted in BY_DATE;

    // Sorting by date shouldn't hide the numbers, so the rows still display
    // the performance figure — only the running order changes.
    const shown = byDate ? "ratio" : wanted;
    const usable =
      shown === "ratio" ? base.some((p) => p.ratio != null)
      : shown === "views" ? base.some((p) => p.views != null)
      : base.some((p) => p.likes != null);
    const mode = usable ? shown : "likes";

    const rows = base.map((p) => decorate(p, mode));
    const top = rows.reduce((best, p) => (p.metric != null && p.metric > best ? p.metric : best), 0) || null;
    const missing = rows.filter((p) => p.metric == null).length;

    if (byDate) {
      // Real timestamps when every post has one, otherwise grid position —
      // the profile grid is already newest-first.
      const dated = rows.every((p) => p.time != null);
      const key = dated ? (p) => p.time : (p) => -p.order;
      const dir = BY_DATE[wanted];
      rows.sort((a, b) => (key(a) - key(b)) * dir);
      return { rows, mode, wanted, top, missing, dated };
    }

    const have = rows.filter((p) => p.metric != null).sort((a, b) => b.metric - a.metric);
    const rest = rows.filter((p) => p.metric == null).sort((a, b) => (b.likes ?? -1) - (a.likes ?? -1));
    return { rows: [...have, ...rest], mode, wanted, top, missing };
  }

  function noteFor({ mode, wanted, missing, dated }) {
    if (wanted in BY_DATE) {
      const figures = `Figures show ${mode === "ratio" ? "likes ÷ views" : mode}`;
      return dated ? figures : `${figures} · ordered by grid position, no dates`;
    }
    if (mode !== wanted) {
      return wanted === "ratio"
        ? "No view counts on these posts — sorted by likes"
        : "No view counts on these posts — sorted by likes instead";
    }
    if (mode === "likes") return "Most likes first";
    if (mode === "views") return `Most views first${missing ? ` · ${missing} without views` : ""}`;
    return `Highest likes ÷ views first${missing ? ` · ${missing} without views` : ""}`;
  }

  /* ==================================================================== UI */

  let panel = null;
  let launcher = null;
  let updateModal = null;
  let chatPicker = null;
  let shownRows = []; // what the list is showing right now, in order

  const el = (tag, cls, text) => {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  };

  const ICON = {
    chart: '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M2 13.2h12M4.4 13V8.2M8 13V3.4M11.6 13V6.1"/></svg>',
    close: '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M3.6 3.6l8.8 8.8M12.4 3.6l-8.8 8.8"/></svg>',
    eye: '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M1.4 8S3.8 3.9 8 3.9 14.6 8 14.6 8 12.2 12.1 8 12.1 1.4 8 1.4 8z"/><circle cx="8" cy="8" r="1.9"/></svg>',
    refresh: '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M13.4 8a5.4 5.4 0 1 1-1.6-3.8"/><path d="M13.6 2.2v3.4h-3.4"/></svg>',
    tickBig: '<svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.6l4.6 4.6L19 6.4"/></svg>',
    plus: '<svg viewBox="0 0 16 16" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M8 3.4v9.2M3.4 8h9.2"/></svg>',
    warn: '<svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M12 7.4v6.2"/><circle cx="12" cy="17.2" r="1.2" fill="currentColor" stroke="none"/></svg>',
    sound: '<svg viewBox="0 0 16 16" width="12" height="12" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M7.2 3.2L4.4 5.6H2.4v4.8h2l2.8 2.4V3.2z"/><path d="M10.4 6.2a2.6 2.6 0 010 3.6"/><path d="M12.4 4.4a5.2 5.2 0 010 7.2"/></svg>',
    mute: '<svg viewBox="0 0 16 16" width="12" height="12" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M7.2 3.2L4.4 5.6H2.4v4.8h2l2.8 2.4V3.2z"/><path d="M10.6 6.4l3.2 3.2M13.8 6.4l-3.2 3.2"/></svg>',
    tick: '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3.2 8.6l3.1 3.1 6.5-7.4"/></svg>',
    cross: '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M4 4l8 8M12 4l-8 8"/></svg>',
    dots: '<svg class="igr-spinner" viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="8" cy="8" r="5.6" opacity=".22"/><path d="M13.6 8A5.6 5.6 0 0 0 8 2.4"/></svg>',
    send: '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2L7.3 8.7"/><path d="M14 2l-4.3 12-2.4-5.3L2 6.3 14 2z"/></svg>',
    lock: '<svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3.2" y="7" width="9.6" height="6.6" rx="1.6"/><path d="M5.6 7V5.2a2.4 2.4 0 014.8 0V7"/></svg>',
    down: '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M8 2.4v8M5 7.6l3 3 3-3M2.6 13.4h10.8"/></svg>',
    prev: '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M9.8 3.2L5 8l4.8 4.8"/></svg>',
    next: '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M6.2 3.2L11 8l-4.8 4.8"/></svg>',
    auto: '<svg viewBox="0 0 16 16" width="13" height="13"><circle cx="8" cy="8" r="5.6" fill="none" stroke="currentColor" stroke-width="1.5"/><path d="M8 2.4a5.6 5.6 0 000 11.2z" fill="currentColor"/></svg>',
    light: '<svg viewBox="0 0 16 16" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><circle cx="8" cy="8" r="2.9"/><path d="M8 1.6v1.5M8 12.9v1.5M1.6 8h1.5M12.9 8h1.5M3.5 3.5l1.1 1.1M11.4 11.4l1.1 1.1M12.5 3.5l-1.1 1.1M4.6 11.4l-1.1 1.1"/></svg>',
    dark: '<svg viewBox="0 0 16 16" width="13" height="13"><path d="M12.8 9.8A5.4 5.4 0 016.2 3.2a5.6 5.6 0 106.6 6.6z" fill="currentColor"/></svg>',
    mark: '<svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M3.5 12.5V9.5M8 12.5V3.5M12.5 12.5V6.5"/></svg>',
    play: '<svg viewBox="0 0 10 10" width="9" height="9"><path d="M2.6 1.6v6.8L8.4 5z" fill="currentColor"/></svg>',
    stack: '<svg viewBox="0 0 10 10" width="9" height="9" fill="none" stroke="currentColor" stroke-width="1.3"><rect x="1" y="3" width="6" height="6" rx="1.2"/><path d="M3.4 1h4.4A1.2 1.2 0 0 1 9 2.2v4.4"/></svg>',
    copy: '<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"><rect x="5.4" y="5.4" width="8.2" height="8.2" rx="1.8"/><path d="M10.6 5.4V3.9a1.5 1.5 0 0 0-1.5-1.5H3.9a1.5 1.5 0 0 0-1.5 1.5v5.2a1.5 1.5 0 0 0 1.5 1.5h1.5"/></svg>',
    caret: '<svg class="igr-caret" viewBox="0 0 10 10" width="10" height="10" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M2.6 4l2.4 2.4L7.4 4"/></svg>',
    image: '<svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"><rect x="2.2" y="2.8" width="11.6" height="10.4" rx="2"/><circle cx="6" cy="6.6" r="1.2"/><path d="M2.6 11.6l3.4-3.2 2.6 2.4 2-1.8 2.9 2.6"/></svg>',
    text: '<svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M3 4h10M3 7.3h10M3 10.6h6.4"/></svg>',
    both: '<svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2.2" y="2.4" width="6.2" height="6.2" rx="1.4"/><path d="M10.6 3.6h3.2M10.6 6.6h3.2M2.6 11.4h11.2M2.6 13.8h7.4"/></svg>',
    external: '<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M9.2 2.6h4.2v4.2M13.2 2.8L7.6 8.4"/><path d="M11.6 9.6v2.6a1.4 1.4 0 0 1-1.4 1.4H3.8a1.4 1.4 0 0 1-1.4-1.4V5.8a1.4 1.4 0 0 1 1.4-1.4h2.6"/></svg>',
    plusSm: '<svg viewBox="0 0 12 12" width="12" height="12" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M6 2.3v7.4M2.3 6h7.4"/></svg>',
    tickSm: '<svg viewBox="0 0 12 12" width="12" height="12" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M2.4 6.3l2.4 2.4 4.8-5.4"/></svg>',
    keep: '<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"><path d="M4.4 2.4h7.2v11.2L8 11 4.4 13.6z"/></svg>',
    crop: '<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4.4 1.6v8.6a1.4 1.4 0 0 0 1.4 1.4h8.6"/><path d="M1.6 4.4h8.6a1.4 1.4 0 0 1 1.4 1.4v8.6"/></svg>',
  };

  const THEME_ORDER = ["auto", "light", "dark"];

  /* Instagram has its own dark mode, set in its settings and independent of
   * the operating system. Following prefers-color-scheme therefore gets it
   * wrong for anyone whose two settings disagree — a white panel on a black
   * page. Reading the page's own background is the only thing that always
   * matches what the user is actually looking at. */
  function pageIsDark() {
    for (const node of [document.body, document.documentElement]) {
      if (!node) continue;
      const parsed = (getComputedStyle(node).backgroundColor || "")
        .match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/);
      if (!parsed) continue;
      if (parsed[4] !== undefined && parseFloat(parsed[4]) < 0.5) continue; // see-through, keep looking
      const [r, g, b] = [1, 2, 3].map((i) => Number(parsed[i]));
      return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255 < 0.5;
    }
    return window.matchMedia("(prefers-color-scheme: dark)").matches;
  }

  function resolvedTheme() {
    return state.theme === "auto" ? (pageIsDark() ? "dark" : "light") : state.theme;
  }

  function paint(node, resolved) {
    if (!node) return;
    node.classList.toggle("igr-light", resolved === "light");
    node.classList.toggle("igr-dark", resolved === "dark");
  }

  let paintedInline = null;

  function applyTheme() {
    const resolved = resolvedTheme();
    for (const node of [panel, launcher, modal, tally, updateModal, chatPicker]) paint(node, resolved);
    // The per-post controls are scattered through Instagram's own markup, so
    // they're only walked when the theme changes; new ones are painted as
    // they're mounted. This runs every second in auto mode.
    if (paintedInline !== resolved) {
      paintedInline = resolved;
      for (const node of document.querySelectorAll(".igr-inline")) paint(node, resolved);
    }
    const btn = panel && panel.querySelector('[data-role="theme"]');
    if (btn) {
      // This runs every second in auto mode, so only touch the glyph when the
      // choice actually changed — that's also what lets it animate once.
      if (btn.dataset.shows !== state.theme) {
        btn.innerHTML = ICON[state.theme];
        btn.dataset.shows = state.theme;
      }
      const suffix = state.theme === "auto" ? ` (matching this page: ${resolved})` : "";
      const name = { auto: "Auto", light: "Light", dark: "Dark" }[state.theme];
      btn.dataset.tip = state.theme === "auto" ? `Theme: Auto · ${resolved}` : `Theme: ${name}`;
      btn.setAttribute("aria-label", `Appearance: ${state.theme}${suffix}. Click to change.`);
    }
  }

  function handle() {
    const first = location.pathname.split("/").filter(Boolean)[0];
    return first ? `@${first}` : "Profile";
  }

  // The profile's own picture, from the page's profile header.
  function profilePicture() {
    const img = [...document.querySelectorAll("main header img, header img")]
      .find((i) => i.src && !i.closest(".igr") && i.getBoundingClientRect().width >= 40);
    return img ? img.src : null;
  }

  /* What the panel is about. Refreshed on every render: the panel used to set
   * this once, so moving to another profile left the first one's name up. */
  function refreshScope() {
    if (!panel) return;
    const q = (r) => panel.querySelector(`[data-role="${r}"]`);
    const feed = pageKind() === "feed";
    panel.classList.toggle("is-feed", feed);
    q("eyebrow").textContent = feed ? "Kept from feed" : "Post performance";
    q("handle").textContent = feed ? "Kept posts" : handle();

    const avatar = q("avatar");
    const src = feed ? "" : profilePicture() || "";
    const key = feed ? "feed" : `${handle()}|${src}`;
    if (avatar.dataset.key === key) return;
    avatar.dataset.key = key;
    avatar.innerHTML = "";
    if (feed) {
      avatar.innerHTML = ICON.keep;
    } else if (src) {
      const img = el("img");
      img.alt = "";
      img.src = src;
      img.onerror = () => { img.remove(); avatar.append(el("span", null, handle().slice(1, 2).toUpperCase())); };
      avatar.appendChild(img);
    } else {
      avatar.append(el("span", null, handle().slice(1, 2).toUpperCase() || "?"));
    }
  }

  /* ---------------------------------------------------------------- panel */

  function buildPanel() {
    panel = el("aside", "igr");
    panel.setAttribute("role", "complementary");
    panel.setAttribute("aria-label", "Post performance");
    panel.innerHTML = `
      <header class="igr-top">
        <div class="igr-ident">
          <span class="igr-mark" aria-hidden="true">${ICON.mark}</span>
          <div class="igr-ident-text">
            <h2 class="igr-brand">IG Ratio</h2>
            <p class="igr-by">Created by Oeng Kimchour</p>
          </div>
        </div>
        <div class="igr-top-actions">
          <button class="igr-icon" data-role="theme" data-tip-pos="end"></button>
          <button class="igr-icon" data-role="close" aria-label="Close" data-tip="Close" data-tip-pos="end">${ICON.close}</button>
        </div>
      </header>

      <div class="igr-scope">
        <span class="igr-avatar" data-role="avatar" aria-hidden="true"></span>
        <div class="igr-scope-text">
          <span class="igr-scope-label" data-role="eyebrow">Post performance</span>
          <span class="igr-scope-handle" data-role="handle"></span>
        </div>
      </div>

      <div class="igr-toolbar">
        <button class="igr-btn igr-btn--primary" data-role="run">Read grid</button>
        <button class="igr-icon" data-role="refresh" aria-label="Read again, keeping your sort and selection" data-tip="Read again">${ICON.refresh}</button>
        <label class="igr-field">
          <span>Limit</span>
          <input type="number" min="1" step="12" value="60" data-role="limit" aria-label="Maximum posts to read">
        </label>
        <button class="igr-icon" data-role="shot" aria-label="Crop a photo out of a screenshot" data-tip="Crop a screenshot\nor paste one: Ctrl+V" data-tip-pos="end">${ICON.crop}</button>
        <button class="igr-icon" data-role="csv" aria-label="Export CSV" data-tip="Export CSV" data-tip-pos="end">${ICON.down}</button>
        <button class="igr-btn igr-feed-only" data-role="clear">Clear kept</button>
      </div>

      <nav class="igr-tabs" data-role="tabs" role="tablist">
        <button class="igr-tab" data-filter="all" role="tab">All<span class="igr-tab-n" data-count="all"></span></button>
        <button class="igr-tab" data-filter="photo" role="tab">Photos<span class="igr-tab-n" data-count="photo"></span></button>
        <button class="igr-tab" data-filter="reel" role="tab">Reels<span class="igr-tab-n" data-count="reel"></span></button>
        <span class="igr-underline" data-role="underline"></span>
      </nav>

      <div class="igr-sortbar">
        <span class="igr-select">
          <select data-role="sort" aria-label="Sort by">
            <optgroup label="Performance">
              <option value="ratio">Likes / views</option>
              <option value="likes">Likes</option>
              <option value="views">Views</option>
            </optgroup>
            <optgroup label="Date posted">
              <option value="newest">Newest first</option>
              <option value="oldest">Oldest first</option>
            </optgroup>
          </select>
        </span>
        <span class="igr-note" data-role="note"></span>
      </div>

      <div class="igr-updatebar" data-role="updatebar" hidden></div>

      <div class="igr-summary" data-role="summary" hidden><div class="igr-stats"></div></div>

      <div class="igr-picker" data-role="picker" hidden>
        <div class="igr-picker-row">
          <label class="igr-check">
            <input type="checkbox" data-role="selall">
            <span data-role="sellabel">Select all</span>
          </label>
          <span class="igr-select igr-select--sm">
            <select data-role="quality" aria-label="Reel download quality">
              <option value="high">Best quality</option>
              <option value="medium">Medium</option>
              <option value="low">Smallest</option>
            </select>
          </span>
        </div>
        <button class="igr-btn igr-picker-go" data-role="zip" disabled>${ICON.down}<span>Download ZIP</span></button>
      </div>
      <div class="igr-list" data-role="list"></div>

      <footer class="igr-foot">
        <div class="igr-status">
          <span class="igr-status-dot" aria-hidden="true"></span>
          <span data-role="status">Ready</span>
          <span class="igr-progress"><span data-role="progress"></span></span>
        </div>
        <div class="igr-credit">
          <button class="igr-update-btn" data-role="update"></button>
          <button class="igr-licence-btn" data-role="licence"></button>
        </div>
      </footer>
    `;
    document.body.appendChild(panel);

    const q = (r) => panel.querySelector(`[data-role="${r}"]`);
    refreshScope();
    q("close").onclick = closePanel;
    q("run").onclick = () => run();
    q("csv").onclick = exportCsv;
    q("shot").onclick = pickScreenshot;
    q("theme").onclick = cycleTheme;
    q("refresh").onclick = () => run({ keepSelection: true });
    // The window is where everything about updates lives, so the footer button
    // opens it rather than doing one of several half-jobs itself.
    q("update").onclick = () => openUpdateModal({ recheck: update.state !== "behind" });
    q("clear").onclick = () => {
      state.posts.clear();
      state.selected.clear();
      render();
    };
    q("licence").onclick = () => openLicence();

    const sortSelect = q("sort");
    sortSelect.value = state.sort;
    sortSelect.onchange = () => {
      state.sort = sortSelect.value;
      savePrefs();
      renderWithFlip();
    };

    panel.querySelectorAll("[data-filter]").forEach((b) => {
      b.classList.toggle("is-on", b.dataset.filter === state.filter);
      b.onclick = () => setFilter(b);
    });

    const quality = q("quality");
    quality.value = state.quality;
    quality.onchange = () => { state.quality = quality.value; savePrefs(); };

    q("selall").onchange = (e) => toggleAll(e.target.checked);
    q("zip").onclick = downloadZip;

    applyTheme();
    refreshLicenceUI();
    refreshUpdateUI();
    checkUpdate({ quiet: true });
    const opening = panel;
    requestAnimationFrame(() => {
      moveUnderline(opening.querySelector(".igr-tab.is-on"), false);
      opening.classList.add("is-open", "is-entering");
      setTimeout(() => opening.classList.remove("is-entering"), 1100);
    });
    render();
  }

  function closePanel() {
    state.cancel = true;
    closePreview();
    if (!panel) return;
    const node = panel;
    panel = null;
    node.classList.remove("is-open");
    setTimeout(() => node.remove(), reduceMotion() ? 0 : 240);
    if (launcher) launcher.classList.remove("is-hidden");
  }

  function cycleTheme() {
    state.theme = THEME_ORDER[(THEME_ORDER.indexOf(state.theme) + 1) % THEME_ORDER.length];
    applyTheme();
    savePrefs();
  }

  // The thumb sits inside the track's 3px padding, so its travel is measured
  // from the track rather than the panel.
  function moveUnderline(tab, animate = true) {
    const thumb = panel && panel.querySelector('[data-role="underline"]');
    const track = panel && panel.querySelector('[data-role="tabs"]');
    if (!thumb || !tab || !track) return;

    const t = tab.getBoundingClientRect();
    const r = track.getBoundingClientRect();
    const place = () => {
      thumb.style.width = `${t.width}px`;
      thumb.style.transform = `translateX(${t.left - r.left - 3}px)`;
    };

    if (!animate || reduceMotion()) {
      const keep = thumb.style.transition;
      thumb.style.transition = "none";
      place();
      void thumb.offsetWidth;
      thumb.style.transition = keep;
      return;
    }
    place();
  }

  function setFilter(tab) {
    if (tab.classList.contains("is-on")) return;
    panel.querySelectorAll("[data-filter]").forEach((b) => b.classList.toggle("is-on", b === tab));
    state.filter = tab.dataset.filter;
    savePrefs();
    moveUnderline(tab);
    renderWithFlip();
  }

  /* -------------------------------------------------------------- scanning */

  // Sentence case, as written. The full line goes in the tooltip too, since
  // a long one is cut short to fit the footer.
  function setStatus(t) {
    const n = panel && panel.querySelector('[data-role="status"]');
    if (!n) return;
    n.textContent = t;
    n.title = t;
  }

  function setProgress(pctDone) {
    const n = panel && panel.querySelector('[data-role="progress"]');
    if (n) n.style.width = `${pctDone}%`;
  }

  // Drives the status dot and shows the progress track only while working.
  // Without a known total the track runs indeterminate rather than sitting empty.
  function setBusy(on, { measured = true } = {}) {
    if (!panel) return;
    panel.classList.toggle("is-busy", on);
    const track = panel.querySelector(".igr-progress");
    if (track) track.classList.toggle("is-indeterminate", on && !measured);
  }

  async function run(opts = {}) {
    if (state.running || !panel) return;
    if (!unlocked()) return openLicence();
    state.running = true;
    state.posts.clear();
    if (!opts.keepSelection) state.selected.clear();

    const runBtn = panel.querySelector('[data-role="run"]');
    const refreshBtn = panel.querySelector('[data-role="refresh"]');
    refreshBtn.disabled = true;
    const limit = parseInt(panel.querySelector('[data-role="limit"]').value, 10) || 0;
    const startY = window.scrollY;

    runBtn.textContent = "Stop";
    runBtn.classList.remove("igr-btn--primary");
    runBtn.onclick = () => { state.cancel = true; };
    setBusy(true, { measured: !!limit });
    showReading();

    try {
      await scan(limit, (n, note) => {
        setStatus(note || `Reading ${n}${limit ? ` of ${limit}` : ""}`);
        tickReading(n);
        if (limit) setProgress(Math.min(100, (n / limit) * 100));
      });
    } catch (err) {
      setStatus("Stopped early");
      console.error("[IG Ratio]", err);
    }

    window.scrollTo(0, startY);
    setBusy(false);
    setProgress(0);
    runBtn.textContent = "Read grid";
    runBtn.classList.add("igr-btn--primary");
    runBtn.onclick = () => run();
    refreshBtn.disabled = false;
    state.running = false;
    renderWithFlip();
  }

  /* While the grid is read the list has nothing to show, and it used to keep
   * saying "Press Read grid" the whole time — as if nothing were happening.
   * A placeholder table with a live count says otherwise. */
  function showReading() {
    if (!panel) return;
    const list = panel.querySelector('[data-role="list"]');
    list.innerHTML = "";
    panel.querySelector('[data-role="summary"]').hidden = true;
    panel.querySelector('[data-role="picker"]').hidden = true;
    lastStats = null;
    renderTabCounts();

    const head = el("div", "igr-reading");
    head.append(el("span", "igr-reading-label", "Reading the grid"), el("span", "igr-reading-count", "Starting…"));
    list.appendChild(head);
    for (let i = 0; i < 8; i++) {
      const row = el("div", "igr-skel");
      row.style.setProperty("--i", i);
      row.innerHTML = '<span class="igr-skel-box"></span><span class="igr-skel-thumb"></span>' +
        '<span class="igr-skel-body"><span></span><span></span><span></span></span>';
      list.appendChild(row);
    }
  }

  function tickReading(n) {
    const count = panel && panel.querySelector(".igr-reading-count");
    if (!count) return;
    const text = `${n} post${n === 1 ? "" : "s"} found`;
    if (count.textContent === text) return;
    count.textContent = text;
    swapIn(count);
  }

  /* ------------------------------------------------------------- rendering */

  function median(values) {
    if (!values.length) return null;
    const s = [...values].sort((a, b) => a - b);
    const mid = Math.floor(s.length / 2);
    return s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
  }

  let lastStats = null; // what the summary last showed, so figures can run to new values

  function renderSummary(result) {
    const box = panel.querySelector('[data-role="summary"]');
    const scored = result.rows.filter((p) => p.metric != null);
    if (!scored.length) { box.hidden = true; lastStats = null; return; }
    const appearing = box.hidden || !lastStats;
    box.hidden = false;

    const asText = (v) => (result.mode === "ratio" ? pct(v) : fmt(Math.round(v)));
    const stats = [
      ["Posts", result.rows.length, (v) => String(Math.round(v))],
      ["Median", median(scored.map((p) => p.metric)), asText],
      ["Best", Math.max(...scored.map((p) => p.metric)), asText],
    ];
    // Figures count up when they first appear and run between values after;
    // a change of unit (likes to views) has nothing to run between, so it fades.
    const before = !appearing && lastStats.mode === result.mode ? lastStats.values : null;

    const grid = box.querySelector(".igr-stats");
    grid.innerHTML = "";
    stats.forEach(([label, value, format], i) => {
      const cell = el("div", "igr-stat");
      const out = el("div", "igr-stat-v", format(value));
      cell.append(el("p", "igr-eyebrow", label), out);
      grid.appendChild(cell);
      const from = appearing ? 0 : before ? before[i] : null;
      if (from != null && from !== value) countTo(out, from, value, format);
      else if (!appearing && !before) swapIn(out);
    });
    lastStats = { mode: result.mode, values: stats.map((st) => st[1]) };
    renderTrend(box, result, appearing);
  }

  // A figure that changes runs to its new value rather than snapping to it.
  function countTo(node, from, to, format, ms = 680) {
    if (reduceMotion()) return;
    // Timed from the first frame's own clock: a frame's timestamp can be
    // earlier than "now" was when this was called, and a negative start
    // would briefly run the figure below zero.
    let start = null;
    node.textContent = format(from);
    const step = (now) => {
      if (!node.isConnected) return;
      if (start == null) start = now;
      const t = Math.min(1, Math.max(0, (now - start) / ms));
      node.textContent = format(from + (to - from) * (1 - Math.pow(1 - t, 3)));
      if (t < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }

  /* Every post's figure in the order it went up, oldest on the left. The
   * ranking says which posts did best; this says when. The bars are kept
   * between renders while the posts are the same, so switching between likes
   * and views reshapes them in place instead of redrawing. */
  function renderTrend(box, result, appearing) {
    const dated = result.rows.every((p) => p.time != null);
    const series = [...result.rows]
      .sort(dated ? (a, b) => a.time - b.time : (a, b) => b.order - a.order)
      .slice(-90);
    const sig = series.map((p) => p.code).join();

    let trend = box.querySelector(".igr-trend");
    if (!trend || trend.dataset.sig !== sig) {
      if (trend) trend.remove();
      trend = el("div", "igr-trend is-fresh");
      trend.dataset.sig = sig;
      const head = el("div", "igr-trend-head");
      head.append(el("span", "igr-eyebrow", "Over time"), el("span", "igr-trend-read"));
      const bars = el("div", "igr-trend-bars");
      bars.style.gap = series.length > 48 ? "1px" : "2px";
      series.forEach((p, i) => {
        const bar = el("span", "igr-trend-bar");
        bar.style.setProperty("--i", Math.min(i, 60));
        bars.appendChild(bar);
      });
      trend.append(head, bars);
      box.appendChild(trend);

      // Pointing at a bar reads it out in the header.
      const read = head.querySelector(".igr-trend-read");
      bars.addEventListener("mouseover", (e) => {
        const bar = e.target.closest(".igr-trend-bar");
        if (!bar) return;
        trend.classList.add("is-reading");
        read.textContent = bar.dataset.info || "";
      });
      bars.addEventListener("mouseleave", () => {
        trend.classList.remove("is-reading");
        read.textContent = trend.dataset.range || "";
      });

      void bars.offsetWidth; // so the bars grow from nothing
      setTimeout(() => trend.classList.remove("is-fresh"), 1400);
    }

    const first = series[0];
    const last = series[series.length - 1];
    trend.dataset.range = dated && first && last
      ? `${shortDate(first.time)} – ${shortDate(last.time)}`
      : `${series.length} posts, oldest first`;
    if (!trend.classList.contains("is-reading")) trend.querySelector(".igr-trend-read").textContent = trend.dataset.range;

    const top = result.top;
    trend.querySelectorAll(".igr-trend-bar").forEach((bar, i) => {
      const p = series[i];
      const share = p.metric != null && top ? Math.max(0.06, p.metric / top) : 0;
      bar.style.setProperty("--h", share.toFixed(4));
      bar.classList.toggle("is-best", p.metric != null && p.metric === top);
      bar.classList.toggle("is-empty", p.metric == null);
      const when = shortDate(p.time) || `Post ${series.length - i} from newest`;
      bar.dataset.info = `${when} · ${p.display}${p.unit ? ` ${p.unit}` : ""}`;
    });
  }

  function renderTabCounts() {
    const all = [...state.posts.values()];
    const counts = {
      all: all.length,
      photo: all.filter((p) => p.kind === "photo").length,
      reel: all.filter((p) => p.kind === "reel").length,
    };
    panel.querySelectorAll("[data-count]").forEach((n) => {
      n.textContent = state.posts.size ? counts[n.dataset.count] : "";
    });
  }

  function render() {
    if (!panel) return;
    const list = panel.querySelector('[data-role="list"]');
    const note = panel.querySelector('[data-role="note"]');
    refreshScope();

    refreshLicenceUI();
    if (!unlocked()) {
      list.innerHTML = "";
      list.appendChild(licenceView());
      note.textContent = "";
      panel.querySelector('[data-role="summary"]').hidden = true;
      panel.querySelector('[data-role="picker"]').hidden = true;
      setStatus(licenceDetail());
      return;
    }

    const result = ranked();
    shownRows = result.rows;

    /* What was on screen a moment ago, and how full its meter was. Those rows
     * are redrawn without their entrance, and their meters ease from the old
     * value to the new one — so a re-render reads as the data changing, not
     * as the list being thrown away and rebuilt. */
    const before = new Map();
    list.querySelectorAll(".igr-row").forEach((r) => {
      const bar = r.querySelector(".igr-bar");
      before.set(r.dataset.code, bar ? bar.style.getPropertyValue("--w") || "0" : "0");
    });

    list.innerHTML = "";
    note.textContent = state.posts.size ? noteFor(result) : "";
    renderTabCounts();

    if (!state.posts.size) {
      list.appendChild(emptyEl(pageKind() === "feed"
        ? "Nothing kept yet. Scroll the feed and press Keep on the bar to collect posts here."
        : "Press Read grid. The page scrolls itself and picks up each post's counts as they load.",
        pageKind() === "feed" ? ICON.keep : ICON.chart));
      panel.querySelector('[data-role="summary"]').hidden = true;
      panel.querySelector('[data-role="picker"]').hidden = true;
      return;
    }
    if (!result.rows.length) {
      list.appendChild(emptyEl("No posts of this type in what was read."));
      panel.querySelector('[data-role="summary"]').hidden = true;
      panel.querySelector('[data-role="picker"]').hidden = true;
      return;
    }

    renderSummary(result);
    if (!state.running) setStatus(`${result.rows.length} of ${state.posts.size} post${state.posts.size === 1 ? "" : "s"} shown`);

    if (!result.rows.some((p) => p.likes != null || p.views != null)) {
      list.appendChild(el("p", "igr-hint",
        "No counts came through. Refresh the page, then read again — the numbers are picked up as Instagram loads them."));
    }

    result.rows.forEach((p, i) => list.appendChild(rowEl(p, i + 1, result.top, before)));

    // Commit the starting widths, then let every meter travel to its value.
    void list.offsetWidth;
    list.querySelectorAll(".igr-bar").forEach((bar) => bar.style.setProperty("--w", bar.dataset.w));

    refreshPicker();
    refreshCapture();

    if (modal && modal.classList.contains("is-open") && previewList === shownRows) {
      viewIndex = Math.min(viewIndex, shownRows.length - 1);
      showShot();
    }
  }

  // Re-sorting reads better if rows travel to their new place.
  function renderWithFlip() {
    if (!panel) return;
    const list = panel.querySelector('[data-role="list"]');
    const before = new Map();
    list.querySelectorAll(".igr-row").forEach((r) => before.set(r.dataset.code, r.getBoundingClientRect().top));

    render();
    if (reduceMotion()) return;

    /* Rows the reader could see travel from where they were. Rows that were
     * scrolled out of view have no origin anyone saw, so they fade in where
     * they land rather than sweeping up from the edge; rows that are out of
     * view both before and after aren't animated at all. */
    const view = list.getBoundingClientRect();
    const onScreen = (top, height) => top + height > view.top && top < view.bottom;
    let arriving = 0;
    list.querySelectorAll(".igr-row").forEach((r) => {
      const wasAt = before.get(r.dataset.code);
      if (wasAt == null) return;
      const nowAt = r.getBoundingClientRect().top;
      const dy = wasAt - nowAt;
      if (Math.abs(dy) < 1) return;
      const seen = onScreen(wasAt, r.offsetHeight);
      if (!seen && !onScreen(nowAt, r.offsetHeight)) return;
      r.style.animation = "none";
      if (seen) {
        r.animate([{ transform: `translateY(${dy}px)` }, { transform: "none" }],
          { duration: 420, easing: EASE_OUT });
      } else {
        r.animate([{ opacity: 0, transform: "translateY(6px)" }, { opacity: 1, transform: "none" }],
          { duration: 340, easing: EASE_OUT, delay: Math.min(arriving++, 10) * 22, fill: "backwards" });
      }
    });
  }

  function emptyEl(text, icon = ICON.chart) {
    const box = el("div", "igr-empty");
    const mark = el("span", "igr-empty-mark");
    mark.innerHTML = icon;
    box.append(mark, el("p", "igr-empty-copy", text));
    return box;
  }

  function rowEl(p, rank, top, before) {
    const row = el("div", "igr-row");
    row.dataset.code = p.code;
    row.style.setProperty("--i", Math.min(rank, 20));
    if (rank === 1 && p.metric != null) row.classList.add("igr-row--lead");
    const known = !!before && before.has(p.code);
    if (known) row.classList.add("is-known");

    const box = el("label", "igr-check igr-check--row");
    const tick = el("input");
    tick.type = "checkbox";
    tick.checked = state.selected.has(p.code);
    tick.disabled = !canDownload(p);
    tick.title = canDownload(p) ? "Select for download" : "Nothing downloadable for this post yet";
    tick.setAttribute("aria-label", `Select post ${rank}`);
    tick.onchange = () => togglePost(p.code, tick.checked);
    box.appendChild(tick);


    const link = el("a", "igr-row-main");
    link.href = p.url;
    link.target = "_blank";
    link.rel = "noopener";

    const rankNum = el("span", "igr-rank", String(rank).padStart(2, "0"));

    const thumb = el("span", "igr-thumb");
    if (p.thumb) {
      const img = el("img");
      img.src = p.thumb;
      img.alt = p.alt || "";
      thumb.appendChild(img);
    }
    // A glyph for the media type; plain photos are the default and carry none.
    const slides = slidesOf(p);
    const kind = el("span", "igr-kind");
    if (slides) {
      kind.innerHTML = `${ICON.stack}<span>${slides.length}</span>`;
      kind.title = `Carousel, ${slides.length} slides`;
    } else if (p.kind === "reel") {
      kind.innerHTML = ICON.play;
      kind.title = "Reel";
    }
    thumb.appendChild(kind);

    const body = el("span", "igr-body");

    // The meter starts where this row's was (or empty, for a new row);
    // render() then eases it to data-w.
    const meter = el("span", "igr-meter");
    const bar = el("span", "igr-bar");
    const share = p.metric != null && top ? Math.max(0.02, p.metric / top) : 0;
    bar.dataset.w = share.toFixed(4);
    bar.style.setProperty("--w", known ? before.get(p.code) : "0");
    meter.appendChild(bar);

    const value = el("span", "igr-value", p.display);
    value.appendChild(el("span", "igr-unit", p.unit));

    const byDate = state.sort in BY_DATE;
    const bits = [];
    const stamp = byDate && shortDate(p.time);
    if (stamp) bits.push(stamp);
    if (p.likes != null && p.unit !== "likes") bits.push(`${compact(p.likes)} likes`);
    if (p.views != null && p.unit !== "views") bits.push(`${compact(p.views)} views`);
    // Two figures is what the row width holds. Comments fill the third slot
    // only when it's free; they're always in the preview card anyway.
    if (p.comments != null && bits.length < 2) bits.push(`${compact(p.comments)} comments`);
    body.append(value, el("span", "igr-counts", bits.join(" · ") || "No counts for this post"), meter);

    link.append(rankNum, thumb, body);

    const eye = el("button", "igr-icon igr-eye");
    eye.innerHTML = ICON.eye;
    eye.dataset.tip = "Preview";
    eye.dataset.tipPos = "left";
    eye.setAttribute("aria-label", `Preview post ${rank}`);
    eye.onclick = (e) => { e.preventDefault(); openPreview(rank - 1, undefined, (post) => rowThumb(post.code)); };

    row.append(box, link, eye);
    return row;
  }

  /* --------------------------------------------------------------- licence */

  let updateDismissed = false;

  /* ------------------------------------------------------- changelog window

  Two states share one layout. When there is nothing to install it reports the
  version you have and lists what that version brought; when something is
  waiting it shows old -> new and lists what is coming. Labelling both "what's
  new" would be a small lie in the first case, which is the trap worth
  avoiding: the reader can't tell whether they already have those changes. */

  // The changelog entry for a given version: the top of the file if it matches,
  // otherwise whichever past release does.
  function entryFor(version) {
    if (!version) return null;
    if (update.latest && compareVersions(update.latest, version) === 0) {
      return { version: update.latest, date: update.date, added: update.added,
               fixed: update.fixed, notes: update.notes };
    }
    return (update.history || []).find((h) => compareVersions(h.version, version) === 0) || null;
  }

  function changeList(title, items, kind) {
    if (!items || !items.length) return null;
    const block = el("section", "igr-change");

    const head = el("div", `igr-change-head igr-change-head--${kind}`);
    const badge = el("span", "igr-change-badge");
    badge.innerHTML = kind === "added" ? ICON.plus : ICON.tick;
    head.append(badge, el("span", "igr-change-title", title));
    block.appendChild(head);

    const list = el("ul", "igr-change-list");
    items.forEach((text, i) => {
      const item = el("li", "igr-change-item", text);
      item.style.setProperty("--i", Math.min(i, 10));
      list.appendChild(item);
    });
    block.appendChild(list);
    return block;
  }

  function lastCheckedLine() {
    if (!update.checkedAt) return "Not checked yet";
    const when = new Date(update.checkedAt);
    return `Last checked: ${when.toLocaleDateString()}, ${when.toLocaleTimeString()}`;
  }

  function buildUpdateModal() {
    updateModal = el("div", "igr-modal igr-upmodal");
    updateModal.setAttribute("role", "dialog");
    updateModal.setAttribute("aria-modal", "true");
    updateModal.setAttribute("aria-label", "Updates");
    updateModal.innerHTML = `
      <div class="igr-scrim" data-role="upscrim"></div>
      <div class="igr-card igr-upcard" tabindex="-1">
        <button class="igr-icon igr-upclose" data-role="upclose" aria-label="Close" data-tip="Close" data-tip-pos="end">${ICON.close}</button>
        <div class="igr-upbody" data-role="upbody"></div>
      </div>`;
    document.body.appendChild(updateModal);

    updateModal.querySelector('[data-role="upscrim"]').onclick = closeUpdateModal;
    updateModal.querySelector('[data-role="upclose"]').onclick = closeUpdateModal;

    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && updateModal && updateModal.classList.contains("is-open")) {
        e.preventDefault();
        closeUpdateModal();
      }
    });
  }

  let updateReturnFocus = null;

  function openUpdateModal({ recheck = false } = {}) {
    if (!updateModal) buildUpdateModal();
    applyTheme();
    renderUpdateModal();
    if (!updateModal.classList.contains("is-open")) updateReturnFocus = document.activeElement;
    updateModal.classList.add("is-open");
    updateModal.querySelector(".igr-card").focus({ preventScroll: true });
    if (recheck) checkUpdate({ announce: true });
  }

  function closeUpdateModal() {
    if (!updateModal || !updateModal.classList.contains("is-open")) return;
    updateModal.classList.remove("is-open");
    if (updateReturnFocus && updateReturnFocus.isConnected) updateReturnFocus.focus({ preventScroll: true });
    updateReturnFocus = null;
  }

  function renderUpdateModal() {
    if (!updateModal) return;
    const body = updateModal.querySelector('[data-role="upbody"]');
    const mine = thisVersion();
    const busy = update.state === "checking";
    const behind = update.state === "behind";
    const failed = update.state === "failed" || update.state === "unpublished";

    body.innerHTML = "";

    // --- crest -------------------------------------------------------------
    const crest = el("div", `igr-crest igr-crest--${behind ? "new" : failed ? "warn" : "ok"}`);
    crest.innerHTML = busy ? ICON.dots : behind ? ICON.down : failed ? ICON.warn : ICON.tickBig;
    body.appendChild(crest);

    body.appendChild(el("h2", "igr-uptitle",
      busy ? "Checking for updates"
      : behind ? "An update is ready"
      : failed ? "Couldn't check for updates"
      : "You're on the latest version"));

    // --- version pills -----------------------------------------------------
    const pills = el("div", "igr-pills");
    if (behind) {
      pills.append(
        el("span", "igr-pilllabel", "Installed"),
        el("span", "igr-pill igr-pill--old", `v${mine}`),
        (() => { const a = el("span", "igr-pillarrow"); a.innerHTML = ICON.next; return a; })(),
        el("span", "igr-pill igr-pill--new", `v${update.latest.replace(/^v/i, "")}`)
      );
    } else {
      pills.append(el("span", "igr-pilllabel", "Installed"), el("span", "igr-pill", `v${mine}`));
    }
    body.appendChild(pills);

    body.appendChild(el("p", "igr-upnote",
      busy ? "Asking GitHub…"
      : behind && update.missingFile
        ? "version.json names a download that isn't in the repo. Upload the release zip under the exact name version.json gives, then check again."
      : behind ? "Download it, unzip over your existing folder, then press reload on chrome://extensions. Your licence key and settings stay as they are."
      : failed ? update.reason
      : "Nothing to install right now."));

    // --- what changed ------------------------------------------------------
    const subject = behind ? entryFor(update.latest) : entryFor(mine);
    const heading = behind ? "What's new" : "In this version";

    if (subject) {
      const added = changeList(heading, subject.added, "added");
      const fixed = changeList(behind ? "Fixed" : "Fixed in this version", subject.fixed, "fixed");
      if (added) body.appendChild(added);
      if (fixed) body.appendChild(fixed);
      if (!added && !fixed && subject.notes) {
        body.appendChild(el("p", "igr-upnotes", subject.notes));
      }
    } else if (!busy && !failed) {
      body.appendChild(el("p", "igr-upnotes",
        "No changelog published for this version."));
    }

    // --- earlier releases --------------------------------------------------
    const earlier = (update.history || []).filter(
      (h) => h.version && compareVersions(h.version, behind ? update.latest : mine) < 0
    );
    if (earlier.length) {
      const fold = el("details", "igr-earlier");
      const sum = el("summary", "igr-earlier-sum", "Earlier versions");
      fold.appendChild(sum);
      earlier.forEach((h) => {
        const row = el("div", "igr-earlier-row");
        row.append(el("span", "igr-earlier-v", `v${h.version.replace(/^v/i, "")}`));
        if (h.date) row.append(el("span", "igr-earlier-d", h.date));
        fold.appendChild(row);
        [...(h.added || []), ...(h.fixed || [])].forEach((text) =>
          fold.appendChild(el("p", "igr-earlier-item", text)));
      });
      body.appendChild(fold);
    }

    // --- actions -----------------------------------------------------------
    const actions = el("div", "igr-upactions");
    if (behind) {
      const get = el("a", `igr-btn igr-upget${update.missingFile ? "" : " igr-btn--primary"}`,
        update.missingFile ? "Open the repo" : `Download v${update.latest.replace(/^v/i, "")}`);
      get.href = update.missingFile ? REPO_URL : update.url;
      get.target = "_blank";
      get.rel = "noopener";
      get.onclick = () => sound("done");
      actions.appendChild(get);
    }
    const again = el("button", `igr-btn${behind ? "" : " igr-btn--primary"}`, busy ? "Checking…" : "Check now");
    again.disabled = busy;
    again.onclick = () => checkUpdate({ announce: true });
    actions.appendChild(again);
    body.appendChild(actions);

    // --- footer ------------------------------------------------------------
    const foot = el("div", "igr-upfoot");
    foot.appendChild(el("span", "igr-upchecked", lastCheckedLine()));

    // Remembering a chat is easy to do and, without this, impossible to undo.
    const saved = rememberedTarget();
    if (saved) {
      const chip = el("button", "igr-chatchip");
      const label = `${APP_LABEL[saved.app] || saved.app}: ${saved.name}`;
      chip.innerHTML = `<span>${label.replace(/</g, "&lt;")}</span>${ICON.close}`;
      chip.title = "Always sending here — click to be asked again";
      chip.onclick = () => { rememberTarget(null); renderUpdateModal(); };
      foot.appendChild(chip);
    }

    const audible = !!(window.__igRatioSound && window.__igRatioSound.enabled);
    const toggle = el("button", `igr-soundtoggle${audible ? " is-on" : ""}`);
    toggle.innerHTML = `${audible ? ICON.sound : ICON.mute}<span>Sound</span>`;
    toggle.title = audible ? "Sounds are on" : "Sounds are off";
    toggle.onclick = () => {
      if (!window.__igRatioSound) return;
      window.__igRatioSound.set(!window.__igRatioSound.enabled);
      renderUpdateModal();
    };
    foot.appendChild(toggle);
    body.appendChild(foot);
  }

  function renderUpdateBar() {
    if (!panel) return;
    const bar = panel.querySelector('[data-role="updatebar"]');
    if (!bar) return;

    if (update.state !== "behind" || updateDismissed) {
      bar.hidden = true;
      bar.innerHTML = "";
      return;
    }

    bar.hidden = false;
    bar.innerHTML = "";

    const text = el("span", "igr-updatebar-title",
      `Version ${update.latest.replace(/^v/i, "")} is ready`);

    const view = el("button", "igr-updatebar-view", "See what's new");
    view.onclick = () => openUpdateModal();

    const close = el("button", "igr-icon igr-updatebar-x");
    close.innerHTML = ICON.close;
    close.dataset.tip = "Hide until next check";
    close.dataset.tipPos = "end";
    close.setAttribute("aria-label", "Hide this notice");
    close.onclick = () => { updateDismissed = true; renderUpdateBar(); };

    bar.append(text, view, close);
  }

  function refreshUpdateUI() {
    if (!panel) return;
    renderUpdateBar();

    const btn = panel.querySelector('[data-role="update"]');
    if (!btn) return;

    const mine = thisVersion();
    btn.textContent = {
      idle: `v${mine}`,
      checking: "Checking…",
      current: `v${mine} · latest`,
      behind: "Update now",
      unpublished: `v${mine} · no version file`,
      failed: `v${mine} · check failed`,
    }[update.state] || `v${mine}`;

    btn.className = `igr-update-btn${update.state === "behind" ? " is-behind" : ""}`;
    btn.title =
      update.state === "behind" ? `Version ${update.latest} is ready — see what changed`
      : update.state === "current" ? `You're on the latest version (${mine})`
      : update.state === "unpublished" ? "No version.json in the repo yet"
      : update.state === "failed" ? update.reason
      : "Check GitHub for a newer version";
  }

  function refreshLicenceUI() {
    if (!panel) return;
    const btn = panel.querySelector('[data-role="licence"]');
    if (btn) {
      btn.textContent = licenceLine();
      btn.className = `igr-licence-btn${licence.state === "licensed" ? " is-ok" : ""}`;
      btn.title = licenceDetail();
    }
    panel.classList.toggle("is-locked", !unlocked());
  }

  function openLicence() {
    if (!panel) return;
    const list = panel.querySelector('[data-role="list"]');
    list.innerHTML = "";
    list.appendChild(licenceView());
    list.scrollTop = 0;
  }

  function licenceView() {
    const box = el("div", "igr-gate");

    const mark = el("div", "igr-gate-mark");
    mark.innerHTML = ICON.lock;
    box.appendChild(mark);

    const headings = {
      licensed: "Licence active",
      trial: `Trial · ${licence.trialLeft} day${licence.trialLeft === 1 ? "" : "s"} left`,
      expired: "Subscription ended",
      locked: "Trial finished",
    };
    box.append(el("h3", "igr-gate-title", headings[licence.state] || "Activate"));

    if (licence.state === "licensed") {
      box.append(el("p", "igr-gate-copy",
        `Licensed to ${licence.holder}. ${licence.expires ? `Runs until ${licence.expires}.` : "No expiry."}`));
    } else if (licence.state === "trial") {
      box.append(el("p", "igr-gate-copy",
        "Everything is unlocked during the trial. Enter a key any time to keep going after it ends."));
    } else {
      box.append(el("p", "igr-gate-copy",
        licence.reason || "Enter your subscription key to carry on reading and downloading."));
    }

    const field = el("textarea", "igr-gate-field");
    field.rows = 3;
    field.placeholder = "Paste your subscription key";
    field.spellcheck = false;
    box.appendChild(field);

    const note = el("p", "igr-gate-note");
    const go = el("button", "igr-btn igr-btn--primary igr-gate-go", "Activate");
    go.onclick = async () => {
      go.disabled = true;
      const result = await activate(field.value);
      go.disabled = false;
      if (result.ok) {
        note.textContent = "";
        refreshLicenceUI();
        render();
        return;
      }
      note.textContent = result.reason || "That key isn't valid";
      note.classList.add("is-bad");
    };
    box.append(go, note);

    if (licence.state === "licensed") {
      const drop = el("button", "igr-gate-drop", "Remove this licence");
      drop.onclick = () => {
        try { localStorage.removeItem(LICENCE_KEY); } catch (_) {}
        checkLicence().then(() => { refreshLicenceUI(); render(); });
      };
      box.appendChild(drop);
    }

    box.append(el("p", "igr-gate-by", "IG Ratio · by Oeng Kimchour"));
    return box;
  }

  /* --------------------------------------------------------------- preview

  A viewer in two columns, the way Instagram shows a single post: the picture
  on the left over a soft, blurred wash of itself, everything about it on the
  right. The single tall column it replaces ran out of height on an ordinary
  laptop screen and squeezed the caption down to one clipped line.

  Fewer controls than before, and each one where you'd look for it: Send as
  the main action, Copy as one menu instead of three buttons, Download and
  Open beside it, and arrows for the next post outside the card — only when
  there is a next post. */

  let modal = null;
  let viewIndex = 0;
  let previewList = [];
  let slideIndex = 0;     // which slide of a carousel is showing
  let travel = 0;         // direction of the last step, so new media enters from that side
  let returnFocus = null; // where focus goes back to when the preview closes
  let originOf = null;    // finds the thumbnail a post was opened from, for the fly-in and back
  let pausedMedia = [];   // the page's own videos paused while the viewer is up

  const slidesOf = (p) => (p && Array.isArray(p.slides) && p.slides.length > 1 ? p.slides : null);
  const PAGE_KEYS = new Set([" ", "PageUp", "PageDown", "ArrowUp", "ArrowDown", "Home", "End"]);

  /* A carousel slide carries its own media but borrows the post's counts,
   * caption and link, so the rest of the card needs no special casing. */
  function viewOf(p) {
    const slides = slidesOf(p);
    if (!slides) return p;
    const slide = slides[Math.min(slideIndex, slides.length - 1)];
    return {
      ...p,
      kind: slide.kind || p.kind,
      preview: slide.preview || p.preview,
      thumb: slide.thumb || p.thumb,
      videos: slide.videos || null,
      slideNumber: slide.n,
      slideCount: slides.length,
      url: `${p.url}${p.url.includes("?") ? "&" : "?"}img_index=${slide.n}`,
    };
  }

  function buildModal() {
    modal = el("div", "igr-modal igr-viewer");
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.setAttribute("aria-label", "Post preview");
    modal.innerHTML = `
      <div class="igr-scrim" data-role="scrim"></div>
      <button class="igr-vnav igr-vnav--prev" data-role="prev" aria-label="Previous post" data-tip="Previous  ←" data-tip-pos="start">${ICON.prev}</button>
      <button class="igr-vnav igr-vnav--next" data-role="next" aria-label="Next post" data-tip="Next  →" data-tip-pos="end">${ICON.next}</button>
      <div class="igr-card igr-vcard" tabindex="-1">
        <div class="igr-media" data-role="media"></div>
        <section class="igr-vside">
          <header class="igr-vhead">
            <div class="igr-vid">
              <span class="igr-card-title" data-role="cardtitle"></span>
              <span class="igr-card-meta" data-role="cardmeta"></span>
            </div>
            <span class="igr-pos" data-role="pos"></span>
            <button class="igr-icon" data-role="close" aria-label="Close preview" data-tip="Close" data-tip-pos="end">${ICON.close}</button>
          </header>
          <div class="igr-figures" data-role="figures"></div>
          <p class="igr-caption" data-role="caption" tabindex="0"></p>
          <div class="igr-vactions">
            <button class="igr-btn igr-btn--primary igr-btn--send" data-role="claude" data-label="Send to chat">${ICON.send}<span>Send to chat</span></button>
            <div class="igr-vrow">
              <div class="igr-menuwrap">
                <button class="igr-btn" data-role="copy" data-label="Copy" aria-haspopup="menu" aria-expanded="false">${ICON.copy}<span>Copy</span>${ICON.caret}</button>
                <div class="igr-menu" data-role="copymenu" role="menu" aria-label="Copy">
                  <button class="igr-menu-item" role="menuitem" data-copy="image">${ICON.image}<span>Image</span></button>
                  <button class="igr-menu-item" role="menuitem" data-copy="caption">${ICON.text}<span>Caption</span></button>
                  <button class="igr-menu-item" role="menuitem" data-copy="both">${ICON.both}<span>Image and caption</span></button>
                </div>
              </div>
              <button class="igr-btn" data-role="save" data-label="Download">${ICON.down}<span>Download</span></button>
              <a class="igr-btn" data-role="open" target="_blank" rel="noopener">${ICON.external}<span>Open</span></a>
            </div>
          </div>
        </section>
      </div>`;
    modal.querySelector(".igr-vcard").appendChild(buildCropSide());
    document.body.appendChild(modal);

    const q = (r) => modal.querySelector(`[data-role="${r}"]`);
    wireDrop(modal.querySelector(".igr-vcard"));
    q("scrim").onclick = closePreview;
    q("close").onclick = closePreview;
    q("prev").onclick = () => step(-1);
    q("next").onclick = () => step(1);
    q("save").onclick = () => saveOne(q("save"), viewOf(previewList[viewIndex]));
    q("claude").onclick = (e) => sendToClaude(e.currentTarget, previewList[viewIndex]);

    const copy = q("copy");
    copy.onclick = (e) => { e.stopPropagation(); toggleCopyMenu(); };
    modal.querySelectorAll("[data-copy]").forEach((b) => {
      b.onclick = (e) => {
        e.stopPropagation();
        toggleCopyMenu(false);
        runCopy(copy, b.dataset.copy); // the outcome shows on the Copy button itself
      };
    });
    modal.addEventListener("click", (e) => { if (!e.target.closest(".igr-menuwrap")) toggleCopyMenu(false); });

    // The page behind shouldn't scroll while you're looking at a post. Stopping
    // the wheel here, rather than locking the page's overflow, avoids making
    // Instagram reflow its whole feed on the way in and again on the way out.
    // A caption that fits isn't a scroller at all, so its wheel would chain
    // straight to the page; only one that can actually scroll keeps it.
    modal.addEventListener("wheel", (e) => {
      // The crop column scrolls too, when a short window can't fit it.
      const scroller = e.target.closest(".igr-caption, .igr-cropside, .igr-cropprompt textarea");
      if (scroller && scroller.scrollHeight > scroller.clientHeight + 1) return;
      e.preventDefault();
    }, { passive: false });

    document.addEventListener("keydown", (e) => {
      if (!modal || !modal.classList.contains("is-open")) return;
      if (chatPicker && chatPicker.classList.contains("is-open")) return;
      if (cropKey(e)) return;
      if ((e.key === "c" || e.key === "C") && e.isTrusted && !e.metaKey && !e.ctrlKey && !e.altKey && !typing(e)) {
        e.preventDefault();
        enterCrop();
        return;
      }
      if (e.key === "Escape") {
        e.preventDefault();
        if (copyMenuOpen()) { toggleCopyMenu(false); copy.focus({ preventScroll: true }); return; }
        closePreview();
      } else if (e.key === "ArrowLeft") { e.preventDefault(); step(-1); }
      else if (e.key === "ArrowRight") { e.preventDefault(); step(1); }
      else if (PAGE_KEYS.has(e.key) && !e.target.closest(".igr-caption, .igr-cropside, button, a, input, textarea, select")) e.preventDefault();
    });
  }

  const copyMenuOpen = () => !!modal && modal.querySelector('[data-role="copymenu"]').classList.contains("is-open");

  function toggleCopyMenu(open) {
    if (!modal) return;
    const menu = modal.querySelector('[data-role="copymenu"]');
    const trigger = modal.querySelector('[data-role="copy"]');
    const next = open === undefined ? !menu.classList.contains("is-open") : !!open;
    if (next === menu.classList.contains("is-open")) return;
    menu.classList.toggle("is-open", next);
    trigger.setAttribute("aria-expanded", String(next));
    if (next) {
      const first = menu.querySelector("[data-copy]:not(:disabled)");
      if (first) first.focus({ preventScroll: true });
    }
  }

  function step(delta) {
    if (!previewList.length || cropOpen()) return;
    toggleCopyMenu(false);

    // Inside a carousel the arrows move between slides, the way they do on
    // Instagram itself, and only move on to the next post at either end.
    const slides = slidesOf(previewList[viewIndex]);
    if (slides) {
      const next = slideIndex + delta;
      if (next >= 0 && next < slides.length) {
        slideIndex = next;
        travel = delta;
        return showShot();
      }
    }

    if (previewList.length === 1 && !slides) return;
    travel = delta;
    viewIndex = (viewIndex + delta + previewList.length) % previewList.length;

    // Coming backwards into a carousel should land on its last slide.
    const arriving = slidesOf(previewList[viewIndex]);
    slideIndex = delta < 0 && arriving ? arriving.length - 1 : 0;
    showShot();
  }

  // The list comes from the caller: the ranked table on a profile, or a single
  // captured post on the feed. origin(post) finds the thumbnail it came from.
  function openPreview(index, list, origin) {
    previewList = list || shownRows;
    if (!previewList.length) return;
    if (!modal) buildModal();
    viewIndex = Math.max(0, Math.min(index, previewList.length - 1));

    /* Opening a post at a particular slide — instagram.com/p/CODE/?img_index=2
     * — should start on that slide rather than snapping back to the first. */
    const wanted = Number(new URLSearchParams(location.search).get("img_index"));
    const slides = slidesOf(previewList[viewIndex]);
    const onThisPost = slides && location.pathname.includes(previewList[viewIndex].code);
    slideIndex = onThisPost && wanted >= 1 && wanted <= slides.length ? wanted - 1 : 0;
    travel = 0;
    originOf = origin || null;

    const opening = !modal.classList.contains("is-open");
    applyTheme();
    showShot();
    if (opening) {
      returnFocus = document.activeElement;
      pausePageMedia();
    }
    modal.classList.add("is-open");
    modal.querySelector(".igr-card").focus({ preventScroll: true });
    // Reopened before the last close finished tidying up: the picture that
    // flew back was hidden for the trip, so bring it back.
    const media = currentMedia();
    if (media) media.style.visibility = "";
    if (opening) flyIn();
  }

  function closePreview() {
    if (!modal) return;
    const wasOpen = modal.classList.contains("is-open");
    toggleCopyMenu(false);
    exitCrop({ silent: true });
    clearTimeout(lookTimer);
    // Decoded pictures are megabytes each; a pasted one isn't kept at all.
    looks.clear();
    if (previewList.some((x) => x.local)) forgetLocal();
    const stage = modal.querySelector('[data-role="media"]');
    if (wasOpen) flyBack();
    modal.classList.remove("is-open");
    stage.querySelectorAll("video").forEach((v) => v.pause());

    // Emptied once the card has faded, so the picture doesn't blink out first.
    clearTimeout(stage.__clear);
    stage.__clear = setTimeout(() => {
      if (modal.classList.contains("is-open")) return;
      stage.innerHTML = "";
      delete stage.dataset.key;
    }, 260);

    if (wasOpen) resumePageMedia();
    if (wasOpen && returnFocus && returnFocus.isConnected) returnFocus.focus({ preventScroll: true });
    returnFocus = null;
  }

  // Instagram's own videos would otherwise keep playing — and talking — under
  // the viewer, and the page would keep repainting behind the blur for nothing.
  function pausePageMedia() {
    pausedMedia = [...document.querySelectorAll("video")].filter((v) => !v.paused && !v.closest(".igr-modal"));
    for (const v of pausedMedia) { try { v.pause(); } catch (_) { /* not ours to insist on */ } }
  }

  function resumePageMedia() {
    for (const v of pausedMedia) if (v.isConnected && v.paused) v.play().catch(() => {});
    pausedMedia = [];
  }

  /* ---------------------------------------------------------- fly in, fly back

  Opening from a thumbnail, the picture travels from where it was into the
  viewer, and on closing it travels back — so the eye follows one object
  instead of losing it to a cut. The traveller is the thumbnail itself, which
  is already loaded and so moves on the very first frame; it hands over to the
  full-size image with a crossfade as it lands. */

  function visibleRect(node) {
    if (!node || !node.isConnected) return null;
    const r = node.getBoundingClientRect();
    if (r.width < 4 || r.height < 4) return null;
    const scroller = node.closest(".igr-list");
    const box = scroller ? scroller.getBoundingClientRect() : { top: 0, left: 0, bottom: innerHeight, right: innerWidth };
    if (r.bottom <= box.top || r.top >= box.bottom || r.right <= box.left || r.left >= box.right) return null;
    return r;
  }

  // Rounded corners usually belong to a wrapper that clips the image, not
  // to the image itself, so look a couple of levels up.
  function radiusOf(node) {
    for (let n = node, i = 0; n && i < 3; n = n.parentElement, i++) {
      const r = getComputedStyle(n).borderTopLeftRadius;
      if (r && r !== "0px") return r;
    }
    return "0px";
  }

  const ghostSource = (node) =>
    node.tagName === "VIDEO" ? node.poster || "" : node.currentSrc || node.src || "";

  function naturalAspect(...nodes) {
    for (const n of nodes) {
      if (!n) continue;
      const w = n.naturalWidth || n.videoWidth;
      const h = n.naturalHeight || n.videoHeight;
      if (w && h) return w / h;
    }
    return 4 / 5;
  }

  function currentMedia() {
    if (!modal) return null;
    const wraps = modal.querySelectorAll('[data-role="media"] .igr-slidewrap:not(.is-leaving)');
    const wrap = wraps[wraps.length - 1];
    return wrap ? wrap.querySelector(".igr-frame > img, .igr-frame > video") : null;
  }

  // Where the stage will be once the card has settled. Offsets ignore
  // transforms, so this is the resting place, not where the card is on the
  // first frame of its own entrance.
  function stageRest() {
    const card = modal.querySelector(".igr-card");
    const stage = modal.querySelector('[data-role="media"]');
    return {
      left: card.offsetLeft + card.clientLeft + stage.offsetLeft,
      top: card.offsetTop + card.clientTop + stage.offsetTop,
      width: stage.offsetWidth,
      height: stage.offsetHeight,
    };
  }

  function fly(src, from, to, { radius = ["8px", "0px"], ms = 520, easing = EASE_OUT, parent = modal } = {}) {
    const ghost = el("img", "igr-ghost");
    ghost.alt = "";
    ghost.src = src;
    Object.assign(ghost.style, { left: `${to.left}px`, top: `${to.top}px`, width: `${to.width}px`, height: `${to.height}px` });
    parent.appendChild(ghost);
    const flight = ghost.animate([
      { left: `${from.left}px`, top: `${from.top}px`, width: `${from.width}px`, height: `${from.height}px`, borderRadius: radius[0] },
      { left: `${to.left}px`, top: `${to.top}px`, width: `${to.width}px`, height: `${to.height}px`, borderRadius: radius[1] },
    ], { duration: ms, easing, fill: "forwards" });
    return { ghost, flight };
  }

  function flyIn() {
    if (reduceMotion() || !originOf) return;
    const source = originOf(previewList[viewIndex]);
    const from = visibleRect(source);
    const media = currentMedia();
    if (!from || !media || !ghostSource(source)) return;

    const rest = stageRest();
    const aspect = naturalAspect(media, source);
    const width = Math.min(rest.width, rest.height * aspect);
    const height = width / aspect;
    const to = { left: rest.left + (rest.width - width) / 2, top: rest.top + (rest.height - height) / 2, width, height };

    media.classList.add("is-awaiting");
    const { ghost, flight } = fly(ghostSource(source), from, to, { radius: [radiusOf(source), "0px"] });
    const land = () => {
      media.classList.remove("is-awaiting");
      ghost.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 240, easing: "ease-out", fill: "forwards" })
        .onfinish = () => ghost.remove();
    };
    flight.onfinish = land;
    flight.oncancel = land;
  }

  function flyBack() {
    if (reduceMotion() || !originOf) return;
    const target = originOf(previewList[viewIndex]);
    const to = visibleRect(target);
    const media = currentMedia();
    if (!to || !media) return;
    const from = media.getBoundingClientRect();
    const src = ghostSource(media) || ghostSource(target);
    if (!from.width || !src) return;
    media.style.visibility = "hidden";
    const { ghost, flight } = fly(src, from, to, {
      radius: ["0px", radiusOf(target)],
      ms: 420,
      easing: "cubic-bezier(0.32, 0.72, 0, 1)",
      parent: document.body,
    });
    flight.onfinish = () => ghost.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 140, fill: "forwards" }).onfinish = () => ghost.remove();
    flight.oncancel = () => ghost.remove();
  }

  // The panel row a post is listed in, for opening and closing from it.
  function rowThumb(code) {
    if (!panel) return null;
    const row = [...panel.querySelectorAll(".igr-row")].find((r) => r.dataset.code === code);
    return row ? row.querySelector(".igr-thumb img") : null;
  }

  /* Direct video URLs are signed and expire, and the profile feed doesn't
   * always carry them at all. Rather than show a dead player, fall back to
   * Instagram's own embed, which always plays and needs no credentials. */
  function mountEmbed(box, p) {
    box.innerHTML = "";
    const frame = document.createElement("iframe");
    frame.className = "igr-embed";
    frame.src = `https://www.instagram.com/${p.kind === "reel" ? "reel" : "p"}/${p.code}/embed/`;
    frame.allow = "autoplay; clipboard-write; encrypted-media; picture-in-picture";
    frame.setAttribute("allowfullscreen", "");
    frame.setAttribute("scrolling", "no");
    frame.title = "Instagram player";
    box.appendChild(frame);
  }

  // box here is the media frame, a layer of its own so that swapping in the
  // embed fallback can't remove the slide dots sitting alongside it.
  function mountMedia(box, p) {
    box.innerHTML = "";
    const clip = previewUrl(p);

    if (clip) {
      const video = document.createElement("video");
      video.src = clip;
      video.poster = p.preview || p.thumb || "";
      video.autoplay = true;
      video.loop = true;
      video.muted = true;
      video.playsInline = true;
      video.controls = true;
      video.onerror = () => mountEmbed(box, p);
      box.appendChild(video);
      // A src that resolves but never decodes fails silently, so check on it.
      setTimeout(() => {
        if (video.isConnected && video.readyState === 0 && !video.error) mountEmbed(box, p);
      }, 3500);
      return;
    }

    if (p.kind === "reel") return mountEmbed(box, p); // something playable straight away

    // A picture from outside Instagram goes in sealed (see smart crop below),
    // and there's no Instagram embed to fall back on.
    if (p.local) {
      const host = sealed("img");
      const img = insideOf(host);
      img.src = p.preview;
      img.alt = p.name || "Screenshot";
      img.decoding = "async";
      box.appendChild(host);
      return;
    }

    const still = p.preview || p.thumb;
    if (still) {
      const img = el("img");
      img.src = still;
      img.alt = p.alt || "";
      img.decoding = "async";
      img.onerror = () => {
        if (p.thumb && img.src !== p.thumb) img.src = p.thumb;
        else mountEmbed(box, p);
      };
      box.appendChild(img);
      return;
    }

    mountEmbed(box, p);
  }

  /* Slide controls sit on the image itself, the way Instagram does it: arrows
   * at the edges, dots underneath. With a dozen slides the dots are too small
   * to aim at, so the arrows are what you actually use. */
  function mountSlideControls(box, p) {
    const slides = slidesOf(p);
    if (!slides) return;

    const jump = (to) => {
      const target = Math.max(0, Math.min(to, slides.length - 1));
      travel = Math.sign(target - slideIndex);
      slideIndex = target;
      showShot();
    };

    for (const dir of ["prev", "next"]) {
      const at = dir === "prev" ? 0 : slides.length - 1;
      if (slideIndex === at) continue; // no arrow where there's nowhere to go
      const arrow = el("button", `igr-arrow igr-arrow--${dir}`);
      arrow.innerHTML = ICON[dir];
      arrow.title = dir === "prev" ? "Previous slide" : "Next slide";
      arrow.setAttribute("aria-label", arrow.title);
      arrow.onclick = (e) => { e.stopPropagation(); jump(slideIndex + (dir === "prev" ? -1 : 1)); };
      box.appendChild(arrow);
    }

    const strip = el("div", "igr-dots");
    // Past a dozen slides the dots stop being aimable, so show a count instead.
    if (slides.length > 10) {
      strip.classList.add("igr-dots--count");
      strip.appendChild(el("span", null, `${slideIndex + 1} / ${slides.length}`));
    } else {
      slides.forEach((slide, i) => {
        const dot = el("button", `igr-dot${i === slideIndex ? " is-on" : ""}`);
        dot.title = `Slide ${i + 1}`;
        dot.setAttribute("aria-label", `Slide ${i + 1} of ${slides.length}`);
        dot.onclick = (e) => { e.stopPropagation(); jump(i); };
        strip.appendChild(dot);
      });
    }
    box.appendChild(strip);
  }

  // What was showing steps aside rather than vanishing: it slides out the way
  // the new one came in from, fading, and is removed once it's gone.
  function retire(nodes, dir) {
    for (const node of nodes) {
      node.querySelectorAll("video").forEach((v) => v.pause());
      if (reduceMotion()) { node.remove(); continue; }
      node.classList.add("is-leaving");
      if (dir) node.dataset.dir = dir > 0 ? "next" : "prev";
      setTimeout(() => node.remove(), 380);
    }
  }

  // A button that's been flashing goes back to its icon and word.
  function resetAction(btn, icon) {
    clearTimeout(btn.__resetTimer);
    delete btn.dataset.icon;
    btn.classList.remove("is-telling");
    btn.innerHTML = `${icon}<span>${btn.dataset.label}</span>${btn.dataset.role === "copy" ? ICON.caret : ""}`;
  }

  function showShot() {
    const p = previewList[viewIndex];
    if (!p) return closePreview();
    const q = (r) => modal.querySelector(`[data-role="${r}"]`);

    // Captions and dates are missing on a photo just as often as on a reel,
    // and without this the copy actions sit disabled forever.
    if (needsLookup(p)) {
      lookupMedia(p)
        .then((gained) => {
          if (!gained) return;
          if (modal && modal.classList.contains("is-open") && previewList[viewIndex] === p) showShot();
          refreshCapture();
          if (panel) render();
        })
        .catch((err) => console.warn("[IG Ratio]", err));
    }

    const view = viewOf(p);
    const many = previewList.length > 1;
    const label = view.slideCount
      ? `${view.kind === "reel" ? "Video" : "Image"} ${view.slideNumber} of ${view.slideCount}`
      : view.kind === "reel" ? "Reel" : "Image";
    // A rank only means something when there's a ranking to be in.
    q("cardtitle").textContent = many ? `${String(viewIndex + 1).padStart(2, "0")} · ${label}` : label;
    q("cardmeta").textContent = [p.author ? `@${p.author}` : null, fullDate(p.time)].filter(Boolean).join(" · ");
    q("pos").textContent = many ? `${viewIndex + 1} / ${previewList.length}` : "";
    modal.classList.toggle("has-nav", many);

    /* The wrapper shrinks to the image so the slide arrows land on its edges
     * rather than out in the letterbox beside it.
     *
     * Only rebuilt when what it shows changes. Counts arriving late re-render
     * the card, and remounting then would restart the video and flash the
     * image for nothing. When it does change, the old picture and its wash
     * step aside while the new ones come in, rather than cutting. */
    const stage = q("media");
    const slides = slidesOf(p);
    const key = [p.code, slideIndex, slides ? slides.length : 0, view.kind,
                 previewUrl(view) || "", view.preview || view.thumb || ""].join("|");
    if (stage.dataset.key !== key) {
      if (cropping) exitCrop({ silent: true });
      stage.dataset.key = key;
      clearTimeout(stage.__clear);
      const leaving = [...stage.children];

      const wash = el("div", "igr-wash");
      const still = view.preview || view.thumb;
      if (still && !p.local) wash.style.backgroundImage = `url("${String(still).replace(/["\\]/g, "\\$&")}")`;

      const wrap = el("div", `igr-slidewrap${travel > 0 ? " is-next" : travel < 0 ? " is-prev" : ""}`);
      const frame = el("div", "igr-frame");
      wrap.appendChild(frame);
      mountMedia(frame, view);
      mountSlideControls(wrap, p);
      stage.append(wash, wrap);
      retire(leaving, travel);
      offerCrop(wrap, view);
    }
    travel = 0;

    // Figures run up from nothing when a new post arrives; a re-render of the
    // same post just shows them.
    const figures = q("figures");
    const fresh = figures.dataset.code !== p.code;
    figures.dataset.code = p.code;
    figures.innerHTML = "";
    const whole = (v) => fmt(Math.round(v));
    for (const [name, value, format] of [["Likes", p.likes, whole], ["Comments", p.comments, whole],
                                         ["Views", p.views, whole], ["Ratio", p.ratio, pct]]) {
      const cell = el("div", `igr-fig${value == null ? " is-empty" : ""}${name === "Ratio" ? " igr-fig--ratio" : ""}`);
      const out = el("div", "igr-fig-v", value == null ? "—" : format(value));
      cell.append(el("p", "igr-eyebrow", name), out);
      figures.appendChild(cell);
      if (fresh && value != null && value > 0) countTo(out, 0, value, format, 620);
    }

    const cap = q("caption");
    cap.textContent = p.caption || "";
    cap.hidden = !p.caption;
    if (fresh) cap.scrollTop = 0;

    q("open").href = view.url;

    const save = q("save");
    resetAction(save, ICON.down);
    save.disabled = !assetOf(view);

    const claude = q("claude");
    resetAction(claude, ICON.send);
    claude.disabled = !(view.preview || view.thumb) && !p.caption;

    const image = !!(view.preview || view.thumb);
    let anyCopy = false;
    modal.querySelectorAll("[data-copy]").forEach((btn) => {
      const needsImage = btn.dataset.copy !== "caption";
      const needsCaption = btn.dataset.copy !== "image";
      btn.disabled = (needsImage && !image) || (needsCaption && !p.caption);
      anyCopy = anyCopy || !btn.disabled;
    });
    const copy = q("copy");
    resetAction(copy, ICON.copy);
    copy.disabled = !anyCopy;
  }

  /* ------------------------------------------------------------ smart crop

  A post that is a screenshot — a tweet, a Reddit thread, a news card —
  carries the photo you actually want inside a frame of headline, avatar and
  buttons. The viewer finds those photos (smartcrop.js does the looking) and
  cuts one out on its true edges: a collage kept whole unless you ask for its
  pieces, nothing padded, nothing resampled, nothing invented.

  A rough red loop says which photo, never where its edges are. One drawn
  here lives on an overlay and never touches the pixels; one already baked
  into a screenshot is painted out of the crop from the pixels beside it —
  or avoided altogether by pasting the unmarked original as well.

  Everything that acts — paste, drop, keys, the send button — answers only to
  real input (isTrusted), so Instagram's own scripts can't drive a crop into
  a chat. And a picture from outside Instagram, or any crop, is only ever
  shown inside a closed shadow root, so those scripts can't read it either. */

  const finder = () => window.__igRatioCrop || null;
  const looks = new Map();  // picture url -> promise of { url, image, small, quick, full }
  let lookTimer = 0;
  let cropping = null;      // the crop being made, while the viewer is in crop mode
  let screenshotCount = 0;  // pasted and dropped pictures, for their names
  let lastLocal = null;     // the pasted picture on screen, freed once it's done with
  let cropPrompt = "";      // kept for this page only, never written to the page's storage
  const QUICK_EDGE = 720;   // the chip's look is at this size; crop mode looks at full size

  /* --- sealed pictures ----------------------------------------------------

  The viewer lives in Instagram's page, so anything in its DOM can be read by
  the page's scripts. Instagram's own photos were always theirs to read; a
  screenshot pasted from elsewhere, or a crop, is not. Those are drawn inside
  closed shadow roots, which page scripts can't open, and the element that
  holds the picture is known only to this script. */

  const sealedParts = new WeakMap(); // host element -> the img or canvas inside it

  function sealed(kind, cls) {
    const host = el("span", `igr-sealed ${cls || ""}`.trim());
    const root = host.attachShadow({ mode: "closed" });
    const style = document.createElement("style");
    style.textContent = kind === "img"
      ? ":host{display:block;max-width:100%}img{display:block;width:auto;height:auto;max-width:100%;max-height:var(--igr-media-max,80vh)}" +
        ":host(.igr-sealed--cover){width:100%;height:100%}:host(.igr-sealed--cover) img{width:100%;height:100%;max-width:none;max-height:none;object-fit:cover}"
      : ":host{display:grid;place-items:center}canvas{display:block;max-width:calc(100% - 24px);max-height:calc(100% - 24px);border-radius:2px;box-shadow:0 12px 32px -12px rgba(0,0,0,.7),0 0 0 1px rgba(255,255,255,.06)}";
    const inner = document.createElement(kind);
    if (kind === "img") inner.alt = "";
    root.append(style, inner);
    sealedParts.set(host, inner);
    return host;
  }
  const insideOf = (host) => sealedParts.get(host) || null;

  /* --- reading the picture ------------------------------------------------

  The pixels come from the file itself, not the <img> on screen: a canvas
  that has drawn a cross-origin <img> can't be read back, while a fetched
  blob can. The same request also gets the full-size picture. Kept for the
  last few pictures, and dropped when the viewer closes — a decoded photo is
  several megabytes. */

  function decode(url) {
    let job = looks.get(url);
    if (job) {
      looks.delete(url);
      looks.set(url, job); // most recently used goes last
      return job;
    }
    job = (async () => {
      const blob = await fetchAsset(url);
      const bitmap = await createImageBitmap(blob);
      const read = (w, h) => {
        const canvas = document.createElement("canvas");
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext("2d", { willReadFrequently: true });
        ctx.drawImage(bitmap, 0, 0, w, h);
        return ctx.getImageData(0, 0, w, h);
      };
      const image = read(bitmap.width, bitmap.height);
      const scale = Math.min(1, QUICK_EDGE / Math.max(bitmap.width, bitmap.height));
      const small = scale < 1 ? read(Math.max(1, Math.round(bitmap.width * scale)), Math.max(1, Math.round(bitmap.height * scale))) : image;
      if (bitmap.close) bitmap.close();
      return { url, image, small, quick: null, full: null };
    })();
    looks.set(url, job);
    job.catch(() => { if (looks.get(url) === job) looks.delete(url); });
    while (looks.size > 3) looks.delete(looks.keys().next().value);
    return job;
  }

  // One frame for whatever is animating to paint before the finder takes the
  // thread; it's synchronous.
  const breathe = () => new Promise((ok) => requestAnimationFrame(() => setTimeout(ok, 0)));

  // The chip only needs to know what's there, so it looks at a reduced copy.
  async function quickLook(url) {
    const look = await decode(url);
    if (!look.quick) {
      await breathe();
      look.quick = look.full || finder().detect(look.small, {});
    }
    return look;
  }

  // Crop mode needs every edge exact, so it looks at the full picture.
  async function fullLook(url) {
    const look = await decode(url);
    if (!look.full) {
      await breathe();
      look.full = finder().detect(look.image, {});
    }
    return look;
  }

  const stageKey = () => (modal ? modal.querySelector('[data-role="media"]').dataset.key || "" : "");
  const cropOpen = () => !!cropping && !!modal && modal.classList.contains("is-cropping");

  function currentWrap() {
    if (!modal) return null;
    const wraps = modal.querySelectorAll('[data-role="media"] .igr-slidewrap:not(.is-leaving)');
    return wraps[wraps.length - 1] || null;
  }

  // Pictures only: a video has no single frame worth cropping.
  function croppable(view) {
    return !!finder() && !!view && view.kind !== "reel" && !previewUrl(view) && !!(view.preview || view.thumb);
  }

  /* The chip on the picture. It looks once the picture has settled — stepping
   * quickly through posts shouldn't decode and scan each one on the way past —
   * and then says what it found. */
  function offerCrop(wrap, view) {
    if (!croppable(view)) return;
    const url = view.preview || view.thumb;
    const chip = el("button", "igr-cropchip is-looking");
    chip.type = "button";
    chip.dataset.role = "cropchip";
    chip.dataset.tip = "Crop  C";
    chip.dataset.tipPos = "start";
    chip.setAttribute("aria-label", "Crop a photo out of this post");
    chip.innerHTML = `${ICON.crop}<span>Crop</span>`;
    chip.onclick = (e) => {
      e.stopPropagation();
      if (e.isTrusted) enterCrop();
    };
    wrap.appendChild(chip);

    const key = stageKey();
    clearTimeout(lookTimer);
    lookTimer = setTimeout(() => {
      if (stageKey() !== key || !modal.classList.contains("is-open")) return;
      quickLook(url).then(({ quick }) => {
        if (chip.isConnected) tellChip(chip, quick);
      }, (err) => {
        console.warn("[IG Ratio] couldn't read the picture for cropping", err);
        if (chip.isConnected) chip.remove(); // nothing it could do
      });
    }, reduceMotion() ? 150 : 560);
  }

  function tellChip(chip, result) {
    chip.classList.remove("is-looking");
    // A post that is just a photo has nothing to cut out of it.
    if (result.wholeImage) { chip.hidden = true; return; }
    const n = result.candidates.length;
    if (!n) return; // still offered: circling something is up to you
    const first = result.candidates[result.primary] || result.candidates[0];
    const label = n > 1 ? `Crop · ${n} found` : first.kind === "collage" ? "Crop collage" : "Crop photo";
    chip.classList.add("is-found");
    chip.querySelector("span").textContent = label;
    chip.setAttribute("aria-label", n > 1 ? `${n} photos found — crop one` : `${label} out of this post`);
    swapIn(chip.querySelector("span"));
  }

  /* ------------------------------------------------------------ crop mode */

  // What's on the picture besides the crop — the chip, slide arrows and dots,
  // the post arrows — is out of reach while cropping, for the pointer and Tab.
  function setAsideStage(on) {
    if (!modal) return;
    const wrap = cropping ? cropping.wrap : currentWrap();
    const nodes = [...modal.querySelectorAll(".igr-vnav"), ...(wrap ? wrap.querySelectorAll(".igr-cropchip, .igr-arrow, .igr-dots") : [])];
    for (const n of nodes) n.inert = on;
  }

  function enterCrop() {
    if (!modal || cropOpen()) return;
    const p = previewList[viewIndex];
    const view = p && viewOf(p);
    const wrap = currentWrap();
    const frame = wrap && wrap.querySelector(".igr-frame");
    if (!croppable(view) || !frame || !frame.querySelector(":scope > img, :scope > .igr-sealed")) return;
    toggleCopyMenu(false);

    const url = view.preview || view.thumb;
    cropping = {
      url, post: p, view, wrap,
      look: null,      // the decoded picture, once read
      auto: null,      // what the finder saw unprompted, for Reset
      result: null,    // what's in use: the auto result, or one guided by a loop
      pick: -1,        // which candidate
      part: -1,        // which piece of a collage, -1 for the whole
      split: false,    // collage pieces offered one by one
      box: null,       // the crop, in image pixels
      own: false,      // the box was moved by hand
      keepMarks: false,
      note: "",
      said: "",        // last thing told to screen readers
      token: {},
    };
    const token = cropping.token;

    modal.classList.add("is-cropping");
    setAsideStage(true);
    buildCropLayer(wrap);
    showCropSide();
    sound("current");

    fullLook(url).then((look) => {
      if (!cropping || cropping.token !== token) return;
      cropping.look = look;
      cropping.auto = look.full;
      useResult(look.full, { first: true });
    }, (err) => {
      if (!cropping || cropping.token !== token) return;
      console.warn("[IG Ratio] crop read failed", err);
      cropping.layer.classList.remove("is-looking");
      cropping.failed = true;
      renderCropSide();
    });
  }

  function exitCrop({ silent = false } = {}) {
    if (!cropping) return;
    const { layer, chip } = cropping;
    const wasLocal = cropping.post && cropping.post.local;
    setAsideStage(false);
    cropping = null;
    if (!modal) return;
    modal.classList.remove("is-cropping");
    const side = modal.querySelector('[data-role="cropside"]');
    side.classList.remove("is-in");
    side.setAttribute("aria-hidden", "true");
    side.inert = true;
    modal.querySelector(".igr-vside").inert = false;
    if (layer && layer.isConnected) {
      if (silent || reduceMotion()) layer.remove();
      else {
        layer.classList.add("is-leaving");
        setTimeout(() => layer.remove(), 260);
      }
    }
    if (silent) return;
    // A pasted screenshot has no post to go back to.
    if (wasLocal) return closePreview();
    const back = chip && chip.isConnected && !chip.hidden ? chip : modal.querySelector(".igr-card");
    back.focus({ preventScroll: true });
  }

  /* --- the layer over the picture ---------------------------------------

  The dimming and the outline are separate pieces: the dim sits under the
  numbered alternatives so they stay visible and clickable, the outline and
  its corner handles sit over them so the handles can always be grabbed. */

  const CORNERS = { nw: "top-left", ne: "top-right", sw: "bottom-left", se: "bottom-right" };

  function buildCropLayer(wrap) {
    const layer = el("div", "igr-crop is-looking");
    layer.dataset.role = "croplayer";
    layer.innerHTML = `
      <div class="igr-crop-scan" aria-hidden="true"><i></i></div>
      <div class="igr-crop-dim" aria-hidden="true"></div>
      <div class="igr-crop-alts"></div>
      <div class="igr-crop-sel">
        <i class="igr-crop-run" aria-hidden="true"></i>
        ${Object.entries(CORNERS).map(([h, name]) => `<button type="button" class="igr-crop-h" data-h="${h}" aria-label="${name} corner of the crop — arrow keys move it, Shift for bigger steps"></button>`).join("")}
        <span class="igr-crop-tag" aria-hidden="true"></span>
      </div>
      <svg class="igr-crop-ink" aria-hidden="true" preserveAspectRatio="none"><path/></svg>`;
    wrap.appendChild(layer);
    cropping.layer = layer;
    cropping.chip = wrap.querySelector(".igr-cropchip");
    layer.addEventListener("pointerdown", onCropPointer);
    return layer;
  }

  const percentOf = (v, of) => `${(v / of) * 100}%`;

  function placeBox(node, b, W, H) {
    node.style.left = percentOf(b.x, W);
    node.style.top = percentOf(b.y, H);
    node.style.width = percentOf(b.w, W);
    node.style.height = percentOf(b.h, H);
  }

  const kindName = (c) => (c.kind === "collage" ? `Collage of ${c.parts.length}` : "Photo");

  // The candidates you could switch to: other photos, or the pieces of the
  // collage when it's being cut one by one.
  function choices() {
    if (!cropping || !cropping.result) return [];
    const r = cropping.result;
    const c = r.candidates[cropping.pick];
    if (cropping.split && c && c.parts.length > 1) {
      return c.parts.map((b, i) => ({ box: b, label: `${i + 1}`, title: `Photo ${i + 1} of ${c.parts.length}`, part: i }));
    }
    return r.candidates.map((cand, i) => ({ box: cand, label: `${i + 1}`, title: kindName(cand), pick: i }));
  }

  const chosen = (ch) => (cropping.split ? ch.part === cropping.part : ch.pick === cropping.pick && cropping.part < 0) && !cropping.own;

  function drawLayer({ snap = false } = {}) {
    if (!cropping || !cropping.look) return;
    const { layer, box } = cropping;
    const { width: W, height: H } = cropping.look.image;
    const sel = layer.querySelector(".igr-crop-sel");
    const dim = layer.querySelector(".igr-crop-dim");
    layer.classList.toggle("has-box", !!box);
    if (box) {
      for (const node of [sel, dim]) {
        // Hand-dragging follows the pointer exactly; snaps get the transition.
        if (!snap) node.classList.add("is-dragging");
        placeBox(node, box, W, H);
      }
      if (!snap) {
        void sel.offsetWidth;
        sel.classList.remove("is-dragging");
        dim.classList.remove("is-dragging");
      }
      // Handles at the picture's own edges turn inward, so they stay on it.
      sel.classList.toggle("at-l", box.x <= 0);
      sel.classList.toggle("at-t", box.y <= 0);
      sel.classList.toggle("at-r", box.x + box.w >= W);
      sel.classList.toggle("at-b", box.y + box.h >= H);
      const tag = sel.querySelector(".igr-crop-tag");
      tag.textContent = `${box.w} × ${box.h}`;
      const rect = layer.getBoundingClientRect();
      tag.hidden = !!rect.width && ((box.w / W) * rect.width < 96 || (box.h / H) * rect.height < 44);
    }

    // The numbered alternatives are rebuilt only when the set changes; a new
    // pick just moves the highlight, so focus and the entrance stay put.
    const alts = layer.querySelector(".igr-crop-alts");
    const list = choices();
    const sig = list.length > 1 ? `${cropping.split}|${list.map((ch) => `${ch.box.x},${ch.box.y},${ch.box.w},${ch.box.h}`).join(";")}` : "";
    if (alts.dataset.sig !== sig) {
      const had = alts.contains(document.activeElement) ? [...alts.children].indexOf(document.activeElement) : -1;
      alts.dataset.sig = sig;
      alts.innerHTML = "";
      if (sig) {
        list.forEach((ch, i) => {
          const b = el("button", "igr-crop-alt");
          b.type = "button";
          b.setAttribute("aria-label", `Crop ${ch.title.toLowerCase()}`);
          b.style.setProperty("--i", i);
          placeBox(b, ch.box, W, H);
          b.appendChild(el("span", "igr-crop-num", ch.label));
          b.onclick = (e) => {
            e.stopPropagation();
            if (!e.isTrusted || !cropping) return;
            if (cropping.split) choosePart(ch.part);
            else chooseCandidate(ch.pick);
          };
          alts.appendChild(b);
        });
        if (had >= 0 && alts.children[had]) alts.children[had].focus({ preventScroll: true });
      }
    }
    [...alts.children].forEach((b, i) => {
      const on = !!list[i] && chosen(list[i]);
      b.classList.toggle("is-on", on);
      b.setAttribute("aria-pressed", String(on));
    });
  }

  /* --- choosing --------------------------------------------------------- */

  function useResult(result, { first = false, guided = false } = {}) {
    if (!cropping) return;
    const { layer } = cropping;
    const { width: W, height: H } = cropping.look.image;
    const local = cropping.post.local;
    cropping.result = result;
    cropping.own = false;
    cropping.part = -1;
    cropping.split = false;
    layer.classList.remove("is-looking");

    const ink = layer.querySelector(".igr-crop-ink");
    ink.setAttribute("viewBox", `0 0 ${W} ${H}`);

    if (result.wholeImage || !result.candidates.length) {
      cropping.pick = -1;
      cropping.box = { x: 0, y: 0, w: W, h: H };
      // A loop around nothing photo-like: its own outline is the best guess.
      if (guided && result.hint && result.hint.box) {
        cropping.box = clampBox(result.hint.box, W, H);
        cropping.own = true;
        cropping.note = "No photo edges inside your loop, so the crop follows the loop. Drag the corners to adjust.";
      } else if (result.wholeImage) {
        cropping.note = local ? "This picture is already just a photo." : "This post is already just a photo.";
      } else {
        cropping.note = "No photo found here. Circle one with the pointer, or drag the corners.";
      }
    } else {
      cropping.pick = result.primary >= 0 ? result.primary : 0;
      cropping.box = { ...result.candidates[cropping.pick] };
      cropping.note = "";
    }

    // The first time, the outline starts at the picture's edges and closes in
    // on the photo, so you see where it went rather than it simply appearing.
    if (first && !reduceMotion()) {
      for (const node of layer.querySelectorAll(".igr-crop-sel, .igr-crop-dim")) {
        node.classList.add("is-dragging");
        placeBox(node, { x: 0, y: 0, w: W, h: H }, W, H);
        void node.offsetWidth;
        node.classList.remove("is-dragging");
      }
      layer.classList.add("is-arriving");
      setTimeout(() => layer.classList.remove("is-arriving"), 900);
    }
    drawLayer({ snap: true });
    pulseBox();
    renderCropSide();
  }

  function chooseCandidate(i) {
    if (!cropping || !cropping.result) return;
    const c = cropping.result.candidates[i];
    if (!c) return;
    cropping.pick = i;
    cropping.part = -1;
    cropping.split = false;
    cropping.own = false;
    cropping.box = { ...c };
    drawLayer({ snap: true });
    pulseBox();
    renderCropSide();
  }

  function choosePart(i) {
    if (!cropping || !cropping.result) return;
    const c = cropping.result.candidates[cropping.pick];
    if (!c || !c.parts[i]) return;
    cropping.part = i;
    cropping.own = false;
    cropping.box = { ...c.parts[i] };
    drawLayer({ snap: true });
    pulseBox();
    renderCropSide();
  }

  function setSplit(on) {
    if (!cropping || !cropping.result) return;
    const c = cropping.result.candidates[cropping.pick];
    if (!c || c.parts.length < 2) return;
    cropping.split = !!on;
    if (on) return choosePart(Math.max(0, cropping.part));
    cropping.part = -1;
    chooseCandidate(cropping.pick);
  }

  function cycleChoice(delta) {
    const list = choices();
    if (list.length < 2) return;
    const at = cropping.split ? cropping.part : cropping.pick;
    const next = (Math.max(0, at) + delta + list.length) % list.length;
    if (cropping.split) choosePart(next);
    else chooseCandidate(next);
  }

  function resetCrop() {
    if (!cropping || !cropping.auto) return;
    useResult(cropping.auto);
    // Reset hides itself; focus goes somewhere that is still there.
    modal.querySelector('[data-role="cropside"]').focus({ preventScroll: true });
  }

  // The outline settles with a small glint, the cue that it has landed.
  function pulseBox() {
    if (!cropping || reduceMotion()) return;
    const sel = cropping.layer.querySelector(".igr-crop-sel");
    sel.classList.remove("is-landing");
    void sel.offsetWidth;
    sel.classList.add("is-landing");
  }

  function clampBox(b, W, H) {
    const x = Math.max(0, Math.min(W - 1, Math.round(b.x)));
    const y = Math.max(0, Math.min(H - 1, Math.round(b.y)));
    return {
      x, y,
      w: Math.max(1, Math.min(W - x, Math.round(b.w))),
      h: Math.max(1, Math.min(H - y, Math.round(b.h))),
    };
  }

  /* --- pointer: corners, clicks and loops --------------------------------

  Dragging a corner moves those two edges, and they pull towards the edges
  the finder saw, so a nudge lands on a photo's border rather than a pixel
  off it. A click picks whichever photo is under it. Anything else drawn on
  the picture is a loop: a hint at which photo, after which the crop snaps to
  that photo's own edges. */

  function onCropPointer(e) {
    if (!e.isTrusted || !cropping || !cropping.look || e.button !== 0) return;
    if (e.target.closest(".igr-crop-alt, .igr-cropchip")) return;
    const { layer } = cropping;
    const { width: W, height: H } = cropping.look.image;
    const rect = layer.getBoundingClientRect();
    const sx = W / rect.width, sy = H / rect.height;
    const toImage = (ev) => ({
      x: Math.max(0, Math.min(W, (ev.clientX - rect.left) * sx)),
      y: Math.max(0, Math.min(H, (ev.clientY - rect.top) * sy)),
    });
    e.preventDefault();
    layer.setPointerCapture(e.pointerId);

    const handle = e.target.closest(".igr-crop-h");
    if (handle && cropping.box) return dragCorner(handle.dataset.h, toImage, sx);

    const token = cropping.token;
    const start = toImage(e);
    const points = [[start.x, start.y]];
    const path = layer.querySelector(".igr-crop-ink path");
    let drawing = false;

    const move = (ev) => {
      if (!cropping || cropping.token !== token) return;
      const at = toImage(ev);
      const last = points[points.length - 1];
      if (!drawing && Math.hypot((at.x - start.x) / sx, (at.y - start.y) / sy) < 6) return;
      if (!drawing) {
        drawing = true;
        layer.classList.add("is-inking");
        layer.querySelector(".igr-crop-ink").classList.remove("is-fading");
      }
      if (Math.hypot(at.x - last[0], at.y - last[1]) * Math.min(1 / sx, 1 / sy) < 2) return;
      points.push([at.x, at.y]);
      path.setAttribute("d", `M${points.map((pt) => `${pt[0].toFixed(1)} ${pt[1].toFixed(1)}`).join("L")}`);
    };
    const up = () => {
      layer.removeEventListener("pointermove", move);
      layer.removeEventListener("pointerup", up);
      layer.removeEventListener("pointercancel", up);
      layer.classList.remove("is-inking");
      if (!cropping || cropping.token !== token) return;
      if (!drawing) return pickAt(start);
      // Too short to mean anything: don't leave a stray mark behind.
      if (points.length < 3) return path.setAttribute("d", "");
      followLoop(points);
    };
    layer.addEventListener("pointermove", move);
    layer.addEventListener("pointerup", up);
    layer.addEventListener("pointercancel", up);
  }

  function pickAt(pt) {
    const list = choices();
    // The smallest one under the pointer: a photo inside a collage beats the collage.
    const hits = list.filter((ch) => pt.x >= ch.box.x && pt.x < ch.box.x + ch.box.w && pt.y >= ch.box.y && pt.y < ch.box.y + ch.box.h)
      .sort((a, b) => a.box.w * a.box.h - b.box.w * b.box.h);
    if (!hits.length) return;
    if (cropping.split) choosePart(hits[0].part);
    else chooseCandidate(hits[0].pick);
  }

  function followLoop(points) {
    if (!cropping) return;
    const { layer, look } = cropping;
    const token = cropping.token;
    const ink = layer.querySelector(".igr-crop-ink");
    layer.classList.add("is-looking", "is-guided");
    // The finder is synchronous; one frame lets the finished loop paint first.
    breathe().then(() => {
      if (!cropping || cropping.token !== token) return;
      let result;
      try {
        result = finder().detect(look.image, { hint: points });
      } catch (err) {
        console.warn("[IG Ratio] guided crop failed", err);
        layer.classList.remove("is-looking", "is-guided");
        ink.querySelector("path").setAttribute("d", "");
        return;
      }
      layer.classList.remove("is-guided");
      useResult(result, { guided: true });
      // The loop has done its job; it fades as the outline lands (or simply
      // goes, with reduced motion).
      if (reduceMotion()) return ink.querySelector("path").setAttribute("d", "");
      ink.classList.add("is-fading");
      setTimeout(() => {
        if (ink.classList.contains("is-fading")) ink.querySelector("path").setAttribute("d", "");
      }, 700);
    });
  }

  // Edges worth sticking to: every candidate's and every piece's.
  function snapLines() {
    const { width: W, height: H } = cropping.look.image;
    const xs = new Set([0, W]), ys = new Set([0, H]);
    for (const c of (cropping.result && cropping.result.candidates) || []) {
      for (const r of [c, ...c.parts]) { xs.add(r.x); xs.add(r.x + r.w); ys.add(r.y); ys.add(r.y + r.h); }
    }
    return { xs, ys };
  }

  // Moves one corner to (x, y) in image pixels; the opposite corner stays.
  function moveCorner(which, x, y) {
    const { width: W, height: H } = cropping.look.image;
    const b = cropping.box;
    const fixed = { x: which.includes("w") ? b.x + b.w : b.x, y: which.includes("n") ? b.y + b.h : b.y };
    const x0 = Math.min(x, fixed.x), x1 = Math.max(x, fixed.x);
    const y0 = Math.min(y, fixed.y), y1 = Math.max(y, fixed.y);
    if (x1 - x0 < 8 || y1 - y0 < 8) return false;
    cropping.box = clampBox({ x: x0, y: y0, w: x1 - x0, h: y1 - y0 }, W, H);
    cropping.own = true;
    drawLayer();
    queuePreview();
    return true;
  }

  function dragCorner(which, toImage, sx) {
    const { layer } = cropping;
    const token = cropping.token;
    const { xs, ys } = snapLines();
    const reach = 8 * sx; // eight screen pixels, in image pixels
    const stick = (v, set) => {
      let best = v, gap = reach;
      for (const s of set) if (Math.abs(s - v) < gap) { gap = Math.abs(s - v); best = s; }
      return best;
    };
    layer.classList.add("is-adjusting");
    const move = (ev) => {
      if (!cropping || cropping.token !== token) return;
      const at = toImage(ev);
      moveCorner(which, stick(Math.round(at.x), xs), stick(Math.round(at.y), ys));
    };
    const up = () => {
      layer.removeEventListener("pointermove", move);
      layer.removeEventListener("pointerup", up);
      layer.removeEventListener("pointercancel", up);
      layer.classList.remove("is-adjusting");
      if (cropping && cropping.token === token) renderCropSide({ fresh: false });
    };
    layer.addEventListener("pointermove", move);
    layer.addEventListener("pointerup", up);
    layer.addEventListener("pointercancel", up);
  }

  // The keyboard way to adjust: a focused corner moves with the arrow keys.
  function nudgeCorner(which, key, big) {
    const step = big ? 10 : 1;
    const b = cropping.box;
    let x = which.includes("w") ? b.x : b.x + b.w;
    let y = which.includes("n") ? b.y : b.y + b.h;
    if (key === "ArrowLeft") x -= step;
    else if (key === "ArrowRight") x += step;
    else if (key === "ArrowUp") y -= step;
    else if (key === "ArrowDown") y += step;
    const { width: W, height: H } = cropping.look.image;
    if (moveCorner(which, Math.max(0, Math.min(W, x)), Math.max(0, Math.min(H, y)))) renderCropSide({ fresh: false });
  }

  /* --- the crop itself ---------------------------------------------------- */

  const marksIn = () => {
    const r = cropping && cropping.result;
    const m = r && r.marks;
    const b = cropping && cropping.box;
    if (!m || !m.baked || !m.box || !b) return false;
    return m.box.x < b.x + b.w && m.box.x + m.box.w > b.x && m.box.y < b.y + b.h && m.box.y + m.box.h > b.y;
  };

  // The exact pixels of the box; baked-in marks painted out unless kept.
  function cropPixels() {
    const { look, box, result } = cropping;
    const src = look.image;
    if (marksIn() && !cropping.keepMarks && typeof finder().retouch === "function") {
      try {
        const fixed = finder().retouch(src, box, result);
        const data = fixed.data instanceof Uint8ClampedArray ? fixed.data : new Uint8ClampedArray(fixed.data);
        return new ImageData(data, fixed.width, fixed.height);
      } catch (err) {
        console.warn("[IG Ratio] couldn't paint the marks out", err);
      }
    }
    const out = new ImageData(box.w, box.h);
    for (let y = 0; y < box.h; y++) {
      const from = ((box.y + y) * src.width + box.x) * 4;
      out.data.set(src.data.subarray(from, from + box.w * 4), y * box.w * 4);
    }
    return out;
  }

  let previewQueued = 0;
  function queuePreview() {
    if (previewQueued) return;
    previewQueued = requestAnimationFrame(() => {
      previewQueued = 0;
      paintPreview(false);
    });
  }

  // The side column shows the crop at full resolution, scaled only by CSS, so
  // what you see is exactly what gets sent. It's sealed like a pasted picture.
  function paintPreview(fresh = true) {
    if (!cropping || !modal) return;
    const view = modal.querySelector('[data-role="cropview"]');
    const ready = !!(cropping.look && cropping.box);
    view.classList.toggle("is-empty", !ready);
    if (!ready) return;
    let host = view.querySelector(".igr-cropcanvas:not(.is-leaving)");
    if (fresh || !host) {
      const old = host;
      if (old) {
        old.classList.add("is-leaving");
        setTimeout(() => old.remove(), 240);
      }
      host = sealed("canvas", "igr-cropcanvas");
      view.appendChild(host);
    }
    const canvas = insideOf(host);
    const pixels = cropPixels();
    canvas.width = pixels.width;
    canvas.height = pixels.height;
    canvas.getContext("2d").putImageData(pixels, 0, 0);
    cropping.canvas = canvas;
    modal.querySelector('[data-role="cropdims"]').textContent = `${pixels.width} × ${pixels.height} px`;
  }

  // PNG, so the crop carries the source's pixels exactly. Only a crop too
  // big to post sensibly falls back to a near-lossless JPEG.
  function cropBlob(canvas = cropping && cropping.canvas) {
    if (!canvas) return Promise.reject(new Error("nothing to crop"));
    return new Promise((ok, no) => canvas.toBlob((png) => {
      if (!png) return no(new Error("could not encode the crop"));
      if (png.size <= 12 * 1024 * 1024) return ok(png);
      canvas.toBlob((jpg) => (jpg ? ok(jpg) : ok(png)), "image/jpeg", 0.95);
    }, "image/png"));
  }

  function cropName(ext, shot = cropping) {
    const p = shot.post;
    if (p.local) return `${p.name} crop${ext}`;
    return fileName(shot.view, ` - crop${ext}`);
  }

  /* --- the side column ---------------------------------------------------- */

  function showCropSide() {
    const side = modal.querySelector('[data-role="cropside"]');
    side.querySelector('[data-role="cropprompt"]').value = cropPrompt;
    side.querySelector('[data-role="cropnote"]').textContent = "";
    side.querySelector('[data-role="cropview"]').innerHTML = "";
    side.querySelector('[data-role="crophint"]').textContent = "";
    side.querySelector('[data-role="cropback"]').setAttribute("aria-label", cropping.post.local ? "Close" : "Back to the post");
    side.querySelector('[data-role="cropback"]').dataset.tip = cropping.post.local ? "Close  Esc" : "Back  Esc";
    side.removeAttribute("aria-hidden");
    side.inert = false;
    side.classList.remove("is-in");
    void side.offsetWidth;
    side.classList.add("is-in");
    modal.querySelector(".igr-vside").inert = true;
    resetAction(side.querySelector('[data-role="cropsend"]'), ICON.send);
    renderCropSide();
    side.focus({ preventScroll: true });
  }

  // For screen readers, said once when it changes — not on every redraw.
  function say(text) {
    if (!modal || !cropping || cropping.said === text) return;
    cropping.said = text;
    modal.querySelector('[data-role="cropsay"]').textContent = text;
  }

  function renderCropSide({ fresh = true } = {}) {
    if (!cropping || !modal) return;
    const side = modal.querySelector('[data-role="cropside"]');
    const q = (r) => side.querySelector(`[data-role="${r}"]`);
    const r = cropping.result;
    const c = r && r.candidates[cropping.pick];

    q("croptitle").textContent = cropping.post.local ? "Crop a screenshot" : "Crop";
    let meta;
    if (cropping.failed) meta = "Couldn't read this picture";
    else if (!r) meta = "Looking for photos…";
    else if (cropping.own) meta = "Your selection";
    else if (cropping.split && c) meta = `Photo ${cropping.part + 1} of ${c.parts.length}`;
    else if (c) meta = r.candidates.length > 1 ? `${kindName(c)} · ${cropping.pick + 1} of ${r.candidates.length}` : kindName(c);
    else meta = r.wholeImage ? "The whole picture" : "No photo found";
    q("cropmeta").textContent = meta;

    // Which photo, when there's more than one. Built once per result; a new
    // pick only moves the highlight.
    const pick = q("croppick");
    const many = !!r && r.candidates.length > 1;
    pick.hidden = !many;
    if (pick.__result !== (many ? r : null)) {
      const had = pick.contains(document.activeElement) ? [...pick.children].indexOf(document.activeElement) : -1;
      pick.__result = many ? r : null;
      pick.innerHTML = "";
      if (many) {
        r.candidates.forEach((cand, i) => {
          const b = el("button", "igr-croppill");
          b.type = "button";
          b.append(el("span", "igr-crop-num", String(i + 1)), el("span", null, kindName(cand)));
          b.onclick = (e) => { if (e.isTrusted) chooseCandidate(i); };
          pick.appendChild(b);
        });
        if (had >= 0 && pick.children[had]) pick.children[had].focus({ preventScroll: true });
      }
    }
    [...pick.children].forEach((b, i) => {
      const on = i === cropping.pick && !cropping.own;
      b.classList.toggle("is-on", on);
      b.setAttribute("aria-pressed", String(on));
    });

    // Whole collage, or its photos one at a time.
    const split = q("cropsplit");
    const pieces = !!c && c.parts.length > 1 && !cropping.own;
    split.hidden = !pieces;
    split.querySelectorAll("[data-split]").forEach((b) => {
      const on = (b.dataset.split === "each") === cropping.split;
      b.classList.toggle("is-on", on);
      b.setAttribute("aria-pressed", String(on));
    });
    split.style.setProperty("--at", cropping.split ? 1 : 0);

    const reset = q("cropreset");
    const resettable = !!cropping.auto && (cropping.own || cropping.result !== cropping.auto || cropping.split);
    if (!resettable && reset.contains(document.activeElement)) side.focus({ preventScroll: true });
    reset.hidden = !resettable;

    // Marks that came with the screenshot.
    const marks = q("cropmarks");
    const baked = marksIn();
    marks.hidden = !baked;
    if (baked) {
      q("cropmarkstext").textContent = cropping.keepMarks ? "Red marks kept in the crop." : "Red marks painted out of the crop.";
      q("cropmarkstoggle").textContent = cropping.keepMarks ? "Remove them" : "Keep them";
    }

    const ready = !!(cropping.look && cropping.box);
    for (const role of ["cropsend", "cropcopy", "cropsave", "cropopen"]) q(role).disabled = !ready;
    const hint = cropping.note || (ready ? "Circle a photo to point at it · drag a corner to adjust" : "");
    if (q("crophint").textContent !== hint) q("crophint").textContent = hint;
    paintPreview(fresh);
    if (ready) say(`${meta}, ${cropping.box.w} by ${cropping.box.h} pixels`);
  }

  function buildCropSide() {
    const side = el("section", "igr-cropside");
    side.dataset.role = "cropside";
    side.tabIndex = -1;
    side.setAttribute("aria-label", "Crop");
    side.setAttribute("aria-hidden", "true");
    side.inert = true;
    side.innerHTML = `
      <header class="igr-vhead">
        <button class="igr-icon" data-role="cropback" aria-label="Back to the post" data-tip="Back  Esc" data-tip-pos="start">${ICON.prev}</button>
        <div class="igr-vid">
          <span class="igr-card-title" data-role="croptitle">Crop</span>
          <span class="igr-card-meta" data-role="cropmeta"></span>
        </div>
        <button class="igr-icon" data-role="cropclose" aria-label="Close preview" data-tip="Close" data-tip-pos="end">${ICON.close}</button>
      </header>
      <div class="igr-cropstage">
        <div class="igr-cropview is-empty" data-role="cropview"></div>
        <div class="igr-cropfacts">
          <span class="igr-cropdims" data-role="cropdims"></span>
          <span class="igr-cropexact">${ICON.tickSm}<span>Original pixels</span></span>
        </div>
      </div>
      <div class="igr-cropcontrols">
        <div class="igr-croppick" data-role="croppick" role="group" aria-label="Photos found" hidden></div>
        <div class="igr-cropsplit" data-role="cropsplit" role="group" aria-label="Collage" hidden>
          <span class="igr-cropsplit-thumb" aria-hidden="true"></span>
          <button type="button" data-split="whole">Whole collage</button>
          <button type="button" data-split="each">Photo by photo</button>
        </div>
        <div class="igr-cropmarks" data-role="cropmarks" hidden>
          <span class="igr-cropmarks-dot" aria-hidden="true"></span>
          <span data-role="cropmarkstext"></span>
          <button type="button" class="igr-linkbtn" data-role="cropmarkstoggle"></button>
        </div>
        <div class="igr-crophintrow">
          <p class="igr-crophint" data-role="crophint" aria-live="polite"></p>
          <button type="button" class="igr-linkbtn" data-role="cropreset" hidden>Reset</button>
        </div>
      </div>
      <label class="igr-cropprompt">
        <span class="igr-eyebrow">Prompt <em>optional</em></span>
        <textarea data-role="cropprompt" rows="2" placeholder="Ask ChatGPT about this image…"></textarea>
      </label>
      <div class="igr-vactions">
        <button class="igr-btn igr-btn--primary igr-btn--send igr-btn--gpt" data-role="cropsend" data-label="Send to ChatGPT">${ICON.send}<span>Send to ChatGPT</span></button>
        <div class="igr-vrow">
          <button class="igr-btn" data-role="cropcopy" data-label="Copy">${ICON.copy}<span>Copy</span></button>
          <button class="igr-btn" data-role="cropsave" data-label="Download">${ICON.down}<span>Download</span></button>
          <button class="igr-btn" data-role="cropopen" data-label="Open">${ICON.external}<span>Open</span></button>
        </div>
      </div>
      <p class="igr-cropnote" data-role="cropnote" role="status" aria-live="polite"></p>
      <p class="igr-sr" data-role="cropsay" aria-live="polite"></p>`;

    const q = (r) => side.querySelector(`[data-role="${r}"]`);
    // Real clicks only, everywhere in here: see the note at the top.
    const on = (role, fn) => { q(role).onclick = (e) => { if (e.isTrusted) fn(e.currentTarget); }; };
    on("cropback", () => exitCrop());
    on("cropclose", () => closePreview());
    on("cropreset", () => resetCrop());
    side.querySelectorAll("[data-split]").forEach((b) => { b.onclick = (e) => { if (e.isTrusted) setSplit(b.dataset.split === "each"); }; });
    on("cropmarkstoggle", () => {
      if (!cropping) return;
      cropping.keepMarks = !cropping.keepMarks;
      renderCropSide();
    });
    const prompt = q("cropprompt");
    prompt.addEventListener("input", () => { cropPrompt = prompt.value.slice(0, 4000); });
    on("cropsend", sendCrop);
    on("cropcopy", copyCrop);
    on("cropsave", saveCrop);
    on("cropopen", openCrop);
    return side;
  }

  function cropNote(text, tone = "") {
    if (!modal) return;
    const note = modal.querySelector('[data-role="cropnote"]');
    note.textContent = text;
    note.className = `igr-cropnote${tone ? ` is-${tone}` : ""}`;
    if (text) swapIn(note);
  }

  /* --- copy, download, open ------------------------------------------------ */

  async function copyCrop(btn) {
    if (!cropping || !cropping.canvas) return;
    try {
      // The promise goes into the ClipboardItem so the click's permission
      // survives the encoding.
      await navigator.clipboard.write([new ClipboardItem({ "image/png": cropBlob().then(toPng) })]);
      flash(btn, "Copied");
      say("Crop copied to the clipboard");
    } catch (err) {
      console.warn("[IG Ratio] crop copy failed", err);
      flash(btn, "Couldn't copy", "bad");
      say("Couldn't copy the crop");
    }
  }

  async function saveCrop(btn) {
    if (!cropping || !cropping.canvas) return;
    const shot = cropping;
    try {
      const blob = await cropBlob();
      saveBlob(blob, cropName(blob.type === "image/png" ? ".png" : ".jpg", shot));
      flash(btn, "Saved");
      say("Crop downloaded");
    } catch (err) {
      console.warn("[IG Ratio] crop save failed", err);
      flash(btn, "Couldn't save", "bad");
      say("Couldn't download the crop");
    }
  }

  // Encoding takes well under the second or so a click stays valid for, so
  // the new tab still counts as something you asked for.
  async function openCrop(btn) {
    if (!cropping || !cropping.canvas) return;
    try {
      const url = URL.createObjectURL(await cropBlob());
      const a = el("a");
      a.href = url;
      a.target = "_blank";
      a.rel = "noopener";
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 60000);
      flash(btn, "Opened");
    } catch (err) {
      console.warn("[IG Ratio] crop open failed", err);
      flash(btn, "Couldn't open", "bad");
    }
  }

  /* --- send to ChatGPT -----------------------------------------------------

  The crop goes into ChatGPT's message box as an attachment, with the
  prompt, through the same bridge as Send to chat. The message itself isn't
  sent: it waits in ChatGPT for you to read and press Enter — though ChatGPT
  uploads an attachment as soon as it lands, and the note says so.

  It always asks which chat; there's no "always send here" for crops, so a
  crop can't end up somewhere you didn't just choose. Once you've chosen, the
  crop also goes on the clipboard — the one moment the browser allows it —
  so that if ChatGPT's page won't take the attachment, a paste always will. */

  async function sendCrop(btn) {
    if (!cropping || !cropping.canvas || btn.dataset.sending) return;
    if (!unlocked()) return showLicence();
    btn.dataset.sending = "1"; // a second click while this one is under way does nothing
    try { await sendCropNow(btn); } finally { delete btn.dataset.sending; }
  }

  async function sendCropNow(btn) {
    const shot = cropping;
    const canvas = shot.canvas;
    const filename = cropName(".png", shot).replace(/^.*[\\/]/, "");
    const prompt = modal.querySelector('[data-role="cropprompt"]').value.trim();
    const blob = cropBlob(canvas);
    blob.catch(() => {}); // reported below, where it's awaited

    const strip = el("span", "igr-chatpost-thumb");
    const thumb = sealed("img", "igr-sealed--cover");
    insideOf(thumb).src = canvas.toDataURL("image/jpeg", 0.7);
    strip.appendChild(thumb);
    const target = await chooseChatTarget(null, {
      apps: ["chatgpt"],
      remember: false,
      title: "Send to ChatGPT",
      sub: prompt ? "The crop goes in with your prompt." : "The crop goes in as an attachment.",
      strip: {
        thumbNode: strip,
        who: `${shot.box.w} × ${shot.box.h} crop`,
        line: prompt || (shot.post.local ? shot.post.name : shot.post.author ? `@${shot.post.author}` : "No prompt"),
        kind: "Crop",
      },
    });
    cropNote("");
    if (target.cancelled) return flash(btn, "Cancelled", "bad");

    // The pick in the picker was a click on this page, so the clipboard is
    // still ours to write.
    let onClipboard = false;
    try {
      await navigator.clipboard.write([new ClipboardItem({ "image/png": blob.then(toPng) })]);
      onClipboard = true;
    } catch (_) { /* said below */ }

    flash(btn, "Attaching…", "busy");
    let image, mime;
    try {
      const b = await blob;
      image = await readAsDataUri(b);
      mime = b.type;
    } catch (err) {
      console.warn("[IG Ratio] crop encode failed", err);
      return flash(btn, "Couldn't prepare it", "bad");
    }
    const copy = onClipboard ? "A copy is on your clipboard too." : "";
    const paste = onClipboard ? "It's on your clipboard — paste it there with Ctrl+V." : "Copy the crop and paste it there.";

    let reply;
    try {
      reply = await chrome.runtime.sendMessage({
        type: "igr-send-to-claude",
        payload: {
          app: "chatgpt",
          tabId: target.tabId,
          newIn: target.newIn || null,
          image,
          mime,
          filename: mime === "image/png" ? filename : filename.replace(/\.png$/, ".jpg"),
          text: prompt,
          url: shot.post.local ? "" : shot.view.url,
          author: shot.post.author || "",
        },
      });
    } catch (err) {
      console.warn("[IG Ratio] crop send failed", err);
      sound("fail");
      flash(btn, "Couldn't reach ChatGPT", "bad");
      return cropNote(`Couldn't reach the ChatGPT tab — is the extension still loaded? ${paste}`, "bad");
    }

    if (!reply || !reply.ok) {
      sound("fail");
      flash(btn, "Didn't go in", "bad");
      return cropNote(`${(reply && reply.reason) || "ChatGPT's page didn't answer."} ${paste}`, "bad");
    }
    const imageIn = reply.image !== undefined ? reply.image : !/^caption only/.test(reply.partial || "");
    const textIn = !prompt || (reply.text !== undefined ? reply.text : !/^image only/.test(reply.partial || ""));
    const uploads = "ChatGPT uploads it as soon as it's attached; your message waits for you to press Enter.";
    if (imageIn && textIn) {
      sound("done");
      flash(btn, "Attached in ChatGPT");
      cropNote(`${prompt ? "The crop and your prompt are" : "The crop is"} in ChatGPT's message box. ${uploads} ${copy}`.trim(), "ok");
    } else if (imageIn) {
      sound("done");
      flash(btn, "Attached, no prompt");
      cropNote(`The crop is attached in ChatGPT, but the prompt didn't go in — type it there. ${uploads}`, "warn");
    } else {
      sound("fail");
      flash(btn, "Image didn't attach", "bad");
      cropNote(`${prompt ? "Your prompt is in ChatGPT's message box, but the" : "The"} crop didn't attach. ${paste}`, "warn");
    }
  }

  /* --- screenshots from outside --------------------------------------------

  Any picture can be cropped, not only a post: paste one (Ctrl+V) or drop one
  on the viewer, or pick one from the panel. If the one you have is marked
  up and you also have the clean original, paste both — same size, same
  picture — and the marked copy only guides the crop while the clean one
  supplies the pixels. */

  function tellShotProblem(text) {
    sound("fail");
    if (cropOpen()) cropNote(text, "bad");
    else if (panel) setStatus(text);
    else console.warn("[IG Ratio]", text);
  }

  // Two pictures are the same scene when they agree everywhere but under the
  // marks — so an unrelated screenshot of the same size never gets paired.
  function sameScene(a, b, skip) {
    const W = a.width, H = a.height;
    const pad = Math.round(Math.max(W, H) * 0.03);
    let diff = 0, n = 0;
    for (let gy = 0; gy < 48; gy++) {
      for (let gx = 0; gx < 48; gx++) {
        const x = Math.floor(((gx + 0.5) / 48) * W), y = Math.floor(((gy + 0.5) / 48) * H);
        if (skip && x >= skip.x - pad && x < skip.x + skip.w + pad && y >= skip.y - pad && y < skip.y + skip.h + pad) continue;
        const o = (y * W + x) * 4;
        diff += Math.abs(a.data[o] - b.data[o]) + Math.abs(a.data[o + 1] - b.data[o + 1]) + Math.abs(a.data[o + 2] - b.data[o + 2]);
        n++;
      }
    }
    return n > 48 * 48 * 0.4 && diff / (n * 3) < 10;
  }

  async function openScreenshot(file) {
    if (!file || !/^image\//.test(file.type) || !finder()) return;
    // Decoded first: a picture the browser can't read (HEIC, say) is turned
    // away with a word, rather than opening a viewer with nothing in it.
    try {
      const probe = await createImageBitmap(file);
      if (probe.close) probe.close();
    } catch (_) {
      return tellShotProblem("Couldn't read that picture — try a PNG or JPEG screenshot.");
    }
    const url = URL.createObjectURL(file);
    const n = ++screenshotCount;
    const stamp = new Date();
    const name = `Screenshot ${stamp.toISOString().slice(0, 10)} ${String(stamp.getHours()).padStart(2, "0")}.${String(stamp.getMinutes()).padStart(2, "0")}${n > 1 ? ` (${n})` : ""}`;

    // A second picture of the same scene as the one being cropped, where one
    // of the two carries red marks, is the clean/marked pair.
    if (cropping && cropping.post.local && cropping.look) {
      const token = cropping.token;
      const held = cropping.look;
      let look;
      try {
        look = await fullLook(url);
      } catch (err) {
        URL.revokeObjectURL(url);
        return tellShotProblem("Couldn't read that picture — try a PNG or JPEG screenshot.");
      }
      if (!cropping || cropping.token !== token) return openLocal(url, name);
      const sameSize = look.image.width === held.image.width && look.image.height === held.image.height;
      const heldMarked = !!(held.full.marks && held.full.marks.baked);
      const newMarked = !!(look.full.marks && look.full.marks.baked);
      const marked = heldMarked ? held : look;
      const clean = heldMarked ? look : held;
      if (!sameSize || heldMarked === newMarked || !sameScene(clean.image, marked.image, marked.full.marks.box)) return openLocal(url, name);
      if (!marked.full.marks.box) return openLocal(url, name);

      const m = marked.full.marks.box;
      const hint = [[m.x, m.y], [m.x + m.w, m.y], [m.x + m.w, m.y + m.h], [m.x, m.y + m.h]];
      const guided = finder().detect(clean.image, { hint });
      if (clean !== held) {
        cropping.look = clean;
        cropping.url = clean.url;
        cropping.post.preview = cropping.post.thumb = clean.url;
        const host = cropping.wrap.querySelector(".igr-frame > .igr-sealed");
        if (host) insideOf(host).src = clean.url;
      }
      // Only the clean copy stays on screen; the marked one's pixels were all it was for.
      const spent = marked.url;
      setTimeout(() => URL.revokeObjectURL(spent), 1000);
      looks.delete(spent);
      lastLocal = clean.url;
      cropping.auto = clean.full;
      useResult(guided, { guided: true });
      cropNote("Using the clean copy for the pixels — the red marks only pointed at the photo.", "ok");
      return;
    }
    openLocal(url, name);
  }

  function forgetLocal() {
    if (!lastLocal) return;
    URL.revokeObjectURL(lastLocal);
    looks.delete(lastLocal);
    lastLocal = null;
  }

  function openLocal(url, name) {
    if (lastLocal !== url) forgetLocal();
    lastLocal = url;
    const post = {
      code: `local-${screenshotCount}`,
      kind: "photo",
      local: true,
      name,
      preview: url,
      thumb: url,
      caption: "",
      author: "",
      url: "",
      time: Math.floor(Date.now() / 1000),
    };
    if (cropping) exitCrop({ silent: true });
    openPreview(0, [post], null);
    // Straight into cropping once the picture is on the stage.
    const host = currentWrap() && currentWrap().querySelector(".igr-frame > .igr-sealed");
    const img = host && insideOf(host);
    const go = () => { if (previewList[viewIndex] === post) enterCrop(); };
    if (img && !img.complete) img.addEventListener("load", go, { once: true });
    else go();
  }

  function imageFrom(dataTransfer) {
    if (!dataTransfer) return null;
    for (const item of dataTransfer.items || []) {
      if (item.kind === "file" && /^image\//.test(item.type)) return item.getAsFile();
    }
    for (const f of dataTransfer.files || []) if (/^image\//.test(f.type)) return f;
    return null;
  }

  // Where the keys or the paste are really going: through shadow roots, and
  // any kind of editable element, not only the obvious ones.
  function typing(e) {
    const n = (e.composedPath && e.composedPath()[0]) || e.target;
    return !!n && n.nodeType === 1 && (n.isContentEditable || !!n.closest("input, textarea, select"));
  }

  // Paste works while the viewer or the panel is up — not on Instagram at
  // large, where a paste belongs to whatever you're typing in.
  document.addEventListener("paste", (e) => {
    if (!e.isTrusted) return;
    const viewerUp = !!modal && modal.classList.contains("is-open");
    if (!viewerUp && !panel) return;
    if (typing(e)) {
      // Our own prompt box takes text as usual; only a bare picture is a screenshot.
      const n = e.composedPath()[0];
      const ours = n.closest && n.closest(".igr-modal, .igr");
      if (!ours || [...(e.clipboardData ? e.clipboardData.types : [])].includes("text/plain")) return;
    }
    const file = imageFrom(e.clipboardData);
    if (!file) return;
    e.preventDefault();
    e.stopPropagation();
    openScreenshot(file);
  }, true);

  function wireDrop(target) {
    let depth = 0;
    const has = (e) => e.isTrusted && [...((e.dataTransfer && e.dataTransfer.types) || [])].includes("Files");
    target.addEventListener("dragenter", (e) => {
      if (!has(e)) return;
      e.preventDefault();
      if (depth++ === 0) target.classList.add("is-dropping");
    });
    target.addEventListener("dragover", (e) => {
      if (!has(e)) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = "copy";
    });
    target.addEventListener("dragleave", () => {
      if (--depth <= 0) { depth = 0; target.classList.remove("is-dropping"); }
    });
    target.addEventListener("drop", (e) => {
      depth = 0;
      target.classList.remove("is-dropping");
      if (!e.isTrusted) return;
      const file = imageFrom(e.dataTransfer);
      if (!file) return;
      e.preventDefault();
      openScreenshot(file);
    });
  }

  function pickScreenshot() {
    const input = el("input");
    input.type = "file";
    input.accept = "image/png,image/jpeg,image/webp,image/gif,image/bmp,image/avif";
    input.onchange = () => { if (input.files && input.files[0]) openScreenshot(input.files[0]); };
    input.click();
  }

  /* --- keys in crop mode ---------------------------------------------------- */

  function cropKey(e) {
    if (!cropOpen()) return false;
    // Composing text in an IME: Escape belongs to the composition.
    if (e.isComposing || e.keyCode === 229) return true;
    if (!e.isTrusted) return true;
    const inPrompt = e.target && e.target.closest && e.target.closest('[data-role="cropprompt"]');
    const mod = e.metaKey || e.ctrlKey;
    const busy = cropping.layer.classList.contains("is-inking") || cropping.layer.classList.contains("is-adjusting");
    if (e.key === "Escape") {
      e.preventDefault();
      if (!busy) exitCrop();
      return true;
    }
    if (mod && e.key === "Enter") {
      e.preventDefault();
      sendCrop(modal.querySelector('[data-role="cropsend"]'));
      return true;
    }
    if (inPrompt) return true; // typing: everything else belongs to the box
    if (mod && (e.key === "c" || e.key === "C") && !String(window.getSelection())) {
      e.preventDefault();
      copyCrop(modal.querySelector('[data-role="cropcopy"]'));
      return true;
    }
    if (mod || e.altKey) return false;
    const corner = e.target && e.target.closest && e.target.closest(".igr-crop-h");
    if (corner && /^Arrow/.test(e.key) && cropping.box) {
      e.preventDefault();
      nudgeCorner(corner.dataset.h, e.key, e.shiftKey);
      return true;
    }
    if (e.key === "ArrowLeft" || e.key === "ArrowUp") { e.preventDefault(); cycleChoice(-1); return true; }
    if (e.key === "ArrowRight" || e.key === "ArrowDown") { e.preventDefault(); cycleChoice(1); return true; }
    if (/^[1-9]$/.test(e.key)) {
      const i = Number(e.key) - 1;
      if (cropping.split) choosePart(i);
      else chooseCandidate(i);
      e.preventDefault();
      return true;
    }
    if ((e.key === "c" || e.key === "C") && !busy) { e.preventDefault(); exitCrop(); return true; }
    return false;
  }

  /* -------------------------------------------------------------- clipboard */

  async function fetchImage(url) {
    const res = await fetch(url, { mode: "cors", credentials: "omit" });
    if (!res.ok) throw new Error(`image fetch failed: ${res.status}`);
    return await res.blob();
  }

  // The image/png slot only takes PNG, so anything else gets repainted.
  async function toPng(blob) {
    if (blob.type === "image/png") return blob;
    const bitmap = await createImageBitmap(blob);
    const canvas = document.createElement("canvas");
    canvas.width = bitmap.width;
    canvas.height = bitmap.height;
    canvas.getContext("2d").drawImage(bitmap, 0, 0);
    return await new Promise((ok, no) =>
      canvas.toBlob((b) => (b ? ok(b) : no(new Error("could not encode PNG"))), "image/png")
    );
  }

  function blobToDataUri(blob) {
    return new Promise((ok, no) => {
      const reader = new FileReader();
      reader.onload = () => ok(reader.result);
      reader.onerror = () => no(new Error("could not read image"));
      reader.readAsDataURL(blob);
    });
  }

  const escapeHtml = (s) =>
    s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
    } catch (_) {
      // Older path, still handy when the clipboard API is blocked.
      const ta = el("textarea");
      ta.value = text;
      ta.style.cssText = "position:fixed;top:-1000px;opacity:0";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
    }
  }

  // Passing promises to ClipboardItem keeps the user gesture alive while the
  // image downloads, which a plain await would spend.
  async function copyImage(url) {
    await navigator.clipboard.write([new ClipboardItem({ "image/png": fetchImage(url).then(toPng) })]);
  }

  /* One clipboard entry carrying three versions of the same post.
   *
   * A clipboard entry is not a list of things to paste — it is one thing
   * described several ways, and the app you paste into picks the version it
   * understands. Handing it only an image and some text means a rich editor
   * takes the image and drops the text, which is exactly the complaint.
   *
   * The fix is the HTML version: it contains the picture and the caption in a
   * single fragment, so an editor that prefers HTML pastes both together.
   * The other two remain as fallbacks for plain text boxes and for targets
   * that accept nothing but a bitmap.
   */
  async function copyBundle(url, caption) {
    const source = fetchImage(url);

    const html = (async () => {
      const raw = await source;
      // Deliberately the original JPEG: a PNG data URI runs several times
      // larger and some editors choke on an oversized paste.
      const uri = await blobToDataUri(raw);
      const body = escapeHtml(caption).replace(/\r?\n/g, "<br>");
      return new Blob([`<div><img src="${uri}" alt=""><p>${body}</p></div>`], { type: "text/html" });
    })();

    await navigator.clipboard.write([
      new ClipboardItem({
        "text/html": html,
        "image/png": source.then(toPng),
        "text/plain": new Blob([caption], { type: "text/plain" }),
      }),
    ]);
  }

  /* Some of these buttons are an icon plus a label, some are label only, and
   * some are icon only. An icon-only button can't say "Sent", so it swaps to a
   * tick or a cross — otherwise the click would appear to do nothing at all.
   *
   * tone: "ok" | "bad" | "busy". Busy states hold until the next flash. */
  function flash(btn, message, tone = "ok") {
    clearTimeout(btn.__resetTimer);
    const label = btn.querySelector("span");
    const iconOnly = !label && !btn.dataset.label;
    const glyph = tone === "busy" ? ICON.dots : tone === "bad" ? ICON.cross : ICON.tick;
    // Buttons with a tooltip say the outcome in it, so an icon that turns
    // into a tick also says what the tick means.
    const tipped = btn.dataset.tip != null;

    if (iconOnly) {
      if (!btn.dataset.icon) btn.dataset.icon = btn.innerHTML;
      btn.innerHTML = glyph;
      swapIn(btn.firstElementChild, "icon");
      btn.classList.toggle("is-bad", tone === "bad");
      btn.classList.toggle("is-ok", tone === "ok");
    } else if (label) {
      // An icon beside the word turns into a spinner, then a tick or a cross.
      const icon = btn.querySelector("svg");
      if (icon) {
        if (!btn.dataset.icon) btn.dataset.icon = icon.outerHTML;
        icon.outerHTML = glyph;
        swapIn(btn.querySelector("svg"), "icon");
      }
      label.textContent = message;
      swapIn(label);
    } else {
      btn.textContent = message;
      swapIn(btn, "text");
    }
    if (tipped) {
      if (btn.dataset.tipRest == null) btn.dataset.tipRest = btn.dataset.tip;
      btn.dataset.tip = message;
      btn.classList.add("is-telling");
    } else {
      btn.title = message;
    }

    if (tone === "busy") return; // the outcome replaces it

    btn.__resetTimer = setTimeout(() => {
      if (iconOnly) {
        btn.innerHTML = btn.dataset.icon;
        swapIn(btn.firstElementChild, "icon");
        btn.classList.remove("is-bad", "is-ok");
      } else if (label) {
        const icon = btn.querySelector("svg");
        if (icon && btn.dataset.icon) {
          icon.outerHTML = btn.dataset.icon;
          delete btn.dataset.icon;
        }
        label.textContent = btn.dataset.label || "";
        swapIn(label);
      } else if (btn.dataset.label) {
        btn.textContent = btn.dataset.label;
        swapIn(btn, "text");
      }
      if (tipped) {
        btn.dataset.tip = btn.dataset.tipRest;
        delete btn.dataset.tipRest;
        btn.classList.remove("is-telling");
      } else {
        btn.title = btn.dataset.title || "";
      }
    }, 1800);
  }

  // Whatever just changed on a control eases in, so "Copied" reads as a
  // reply rather than a flicker. Icons scale up into place; text alone fades.
  function swapIn(node, kind) {
    if (!node || !node.animate || reduceMotion()) return;
    const frames = kind === "icon"
      ? [{ opacity: 0, transform: "scale(0.6) rotate(-12deg)" }, { opacity: 1, transform: "none" }]
      : kind === "text"
        ? [{ color: "transparent" }, { color: getComputedStyle(node).color }]
        : [{ opacity: 0, transform: "translateY(3px)" }, { opacity: 1, transform: "none" }];
    node.animate(frames, { duration: kind === "icon" ? 320 : 260, easing: EASE_OUT });
  }

  async function runCopy(btn, what) {
    const p = viewOf(previewList[viewIndex]);
    if (!p) return;
    const image = p.preview || p.thumb;
    const caption = p.caption || "";

    try {
      if (what === "caption") {
        if (!caption) return flash(btn, "No caption", "bad");
        await copyText(caption);
        return flash(btn, "Copied");
      }
      if (!image) return flash(btn, "No image", "bad");
      if (what === "both" && caption) await copyBundle(image, caption);
      else await copyImage(image);
      flash(btn, "Copied");
    } catch (err) {
      console.warn("[IG Ratio] copy failed", err);
      // Instagram's CDN sometimes refuses a cross-origin read. The link is
      // still worth something, so hand that over instead of nothing.
      if (what !== "caption" && image) {
        await copyText(what === "both" && caption ? `${image}\n\n${caption}` : image);
        return flash(btn, "Link copied");
      }
      flash(btn, "Couldn't copy", "bad");
    }
  }

  /* ------------------------------------------------------- filling the gaps

  The reels tab sends a stripped-down node: counts and a thumbnail, no video
  URL, no caption, no date. Falling back to the cover image would hand you a
  folder of JPEGs labelled with shortcodes, which is no use to anyone.

  Instagram's own media endpoint has all of it, so ask for it the same way the
  page would — same headers, same cookies, one call per post, only when a
  download actually needs it. */

  let lookupsBlocked = false;

  /* An Instagram shortcode is the media id written in base64 with a URL-safe
   * alphabet. Decoding it means a post can be looked up even when the feed
   * response told us nothing at all. */
  const SHORTCODE_ALPHABET =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";

  function pkFromShortcode(code) {
    if (!code || code.length > 24) return null;
    let value = 0n;
    for (const character of code) {
      const index = SHORTCODE_ALPHABET.indexOf(character);
      if (index < 0) return null;
      value = value * 64n + BigInt(index);
    }
    return value > 0n ? value.toString() : null;
  }

  function absorb(p, item) {
    if (!item) return false;
    let gained = false;

    const versions = Array.isArray(item.video_versions)
      ? item.video_versions
          .map((v) => ({ url: v.url, width: v.width || 0, height: v.height || 0 }))
          .filter((v) => v.url)
          .sort((a, b) => b.width - a.width)
      : null;
    if (versions && versions.length && !(p.videos && p.videos.length)) { p.videos = versions; gained = true; }

    const text = item.caption && typeof item.caption.text === "string" ? item.caption.text : null;
    if (text && !p.caption) { p.caption = text.slice(0, 2200); gained = true; }

    if (item.taken_at && !p.time) { p.time = item.taken_at; gained = true; }

    /* The page only ever renders rounded figures — "1.1K" reads back as 1,100.
     * These are the real numbers, so they replace what was scraped rather than
     * only filling blanks. */
    for (const [field, source] of [["likes", "like_count"], ["comments", "comment_count"]]) {
      const value = item[source];
      if (typeof value === "number" && isFinite(value) && p[field] !== value) { p[field] = value; gained = true; }
    }
    const plays = typeof item.play_count === "number" ? item.play_count
      : typeof item.ig_play_count === "number" ? item.ig_play_count
      : typeof item.view_count === "number" ? item.view_count : null;
    if (plays != null && p.views !== plays) { p.views = plays; gained = true; }

    const username = (item.user && item.user.username) || (item.owner && item.owner.username);
    if (username && !p.author) { p.author = username; gained = true; }

    if (!p.slides && Array.isArray(item.carousel_media) && item.carousel_media.length > 1) {
      p.slides = item.carousel_media.map((slide, i) => {
        const options = slide.image_versions2 && slide.image_versions2.candidates;
        const clips = Array.isArray(slide.video_versions)
          ? slide.video_versions
              .map((v) => ({ url: v.url, width: v.width || 0, height: v.height || 0 }))
              .filter((v) => v.url)
              .sort((a, b) => b.width - a.width)
          : null;
        return {
          n: i + 1,
          kind: slide.media_type === 2 || clips ? "reel" : "photo",
          preview: Array.isArray(options) && options.length ? options[0].url : null,
          thumb: Array.isArray(options) && options.length ? options[options.length - 1].url : null,
          videos: clips,
        };
      });
      gained = true;
    }

    const candidates = item.image_versions2 && item.image_versions2.candidates;
    if (Array.isArray(candidates) && candidates.length) {
      if (!p.preview) { p.preview = candidates[0].url; gained = true; }
      if (!p.thumb) { p.thumb = candidates[candidates.length - 1].url; gained = true; }
    }
    return gained;
  }

  async function lookupMedia(p) {
    if (!p || !p.pk || p.__lookedUp || lookupsBlocked) return false;
    // Rows are copies made during ranking, so mark and fill the stored post
    // too — otherwise the next render throws the answer away.
    const stored = state.posts.get(p.code);
    p.__tries = (p.__tries || 0) + 1;
    p.__lookedUp = true;
    if (stored) { stored.__tries = p.__tries; stored.__lookedUp = true; }

    const allowRetry = () => {
      // Two attempts, then leave it alone rather than hammering.
      if (p.__tries >= 2) return;
      p.__lookedUp = false;
      if (stored) stored.__lookedUp = false;
    };
    let res;
    try {
      res = await fetch(`https://www.instagram.com/api/v1/media/${p.pk}/info/`, {
        headers: igHeaders,
        credentials: "include",
      });
    } catch (err) {
      allowRetry();
      throw err;
    }
    if (res.status === 401 || res.status === 403 || res.status === 429) {
      lookupsBlocked = true; // stop asking once Instagram says no
      throw new Error(`lookup refused: ${res.status}`);
    }
    if (!res.ok) { allowRetry(); throw new Error(`lookup failed: ${res.status}`); }
    const data = await res.json();
    const item = data && data.items && data.items[0];
    if (stored && stored !== p) absorb(stored, item);
    return absorb(p, item);
  }

  const needsLookup = (p) =>
    !!p.pk && !p.__lookedUp && ((p.kind === "reel" && !videoUrl(p)) || (!p.caption && !p.time));

  /* -------------------------------------------------------- picking files */

  function assetOf(p) {
    if (p.kind === "reel") {
      const url = videoUrl(p);
      return url ? { url, ext: ".mp4" } : null; // never silently substitute the cover
    }
    const url = p.preview || p.thumb;
    return url ? { url, ext: ".jpg" } : null;
  }

  // A reel with an id can still be fetched, it just needs the lookup first.
  const canDownload = (p) => !!assetOf(p) || (p.kind === "reel" && !!p.pk && !lookupsBlocked);
  const downloadable = () => shownRows.filter(canDownload);

  function toggleAll(on) {
    for (const p of downloadable()) {
      if (on) state.selected.add(p.code);
      else state.selected.delete(p.code);
    }
    render();
  }

  function togglePost(code, on) {
    if (on) state.selected.add(code);
    else state.selected.delete(code);
    refreshPicker();
  }

  function refreshPicker() {
    if (!panel) return;
    const box = panel.querySelector('[data-role="picker"]');
    const all = downloadable();
    box.hidden = !all.length;
    if (!all.length) return;

    const picked = all.filter((p) => state.selected.has(p.code)).length;
    const master = panel.querySelector('[data-role="selall"]');
    master.checked = picked > 0 && picked === all.length;
    master.indeterminate = picked > 0 && picked < all.length;

    panel.querySelector('[data-role="sellabel"]').textContent =
      picked ? `${picked} of ${all.length} selected` : "Select all";

    const go = panel.querySelector('[data-role="zip"]');
    go.disabled = !picked || state.saving;
    const label = picked ? `Download ZIP · ${picked} file${picked === 1 ? "" : "s"}` : "Download ZIP";
    go.innerHTML = `${ICON.down}<span>${label}</span>`;
  }

  async function fetchAsset(url) {
    const res = await fetch(url, { mode: "cors", credentials: "omit" });
    if (!res.ok) throw new Error(`${res.status}`);
    return await res.blob();
  }

  function saveBlob(blob, name) {
    const url = URL.createObjectURL(blob);
    const a = el("a");
    a.href = url;
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }

  async function saveOne(btn, p) {
    if (!p) return;
    if (needsLookup(p)) {
      flash(btn, "Looking up…", "busy");
      try { await lookupMedia(p); } catch (err) { console.warn("[IG Ratio]", err); }
    }
    const asset = assetOf(p);
    if (!asset) return flash(btn, "Nothing to save", "bad");
    flash(btn, "Saving…", "busy");
    try {
      saveBlob(await fetchAsset(asset.url), fileName(p, asset.ext));
      flash(btn, "Saved");
    } catch (err) {
      console.warn("[IG Ratio] download failed", err);
      // Blocked cross-origin reads still open fine in a tab.
      window.open(asset.url, "_blank", "noopener");
      flash(btn, "Opened in tab");
    }
  }

  async function downloadZip() {
    if (state.saving) return;
    if (!unlocked()) return openLicence();
    const picks = [...state.posts.values()].filter((p) => state.selected.has(p.code) && canDownload(p));
    if (!picks.length) return;

    state.saving = true;
    state.cancel = false;
    setBusy(true);
    refreshPicker();
    const entries = [];
    const failed = [];

    // Fill in video URLs, captions and dates before fetching anything, so the
    // files come out named properly rather than as bare shortcodes.
    const gaps = picks.filter(needsLookup);
    for (let i = 0; i < gaps.length; i++) {
      if (state.cancel || lookupsBlocked) break;
      setStatus(`Looking up ${i + 1} of ${gaps.length}`);
      setProgress(((i + 1) / gaps.length) * 100);
      try { await lookupMedia(gaps[i]); } catch (err) { console.warn("[IG Ratio]", err); }
      await sleep(140); // don't hammer
    }

    for (let i = 0; i < picks.length; i++) {
      if (state.cancel) break;
      const p = picks[i];
      setStatus(`Fetching ${i + 1} of ${picks.length}`);
      setProgress(((i + 1) / picks.length) * 100);
      // A carousel is several files, not one.
      const slides = slidesOf(p);
      const parts = slides
        ? slides.map((slide) => ({
            ...p, kind: slide.kind || p.kind, preview: slide.preview, thumb: slide.thumb,
            videos: slide.videos || null, slideNumber: slide.n, slideCount: slides.length,
          }))
        : [p];

      let saved = false;
      for (const part of parts) {
        const partAsset = assetOf(part);
        if (!partAsset) continue;
        try {
          entries.push({
            name: fileName(part, partAsset.ext),
            blob: await fetchAsset(partAsset.url),
            date: p.time ? new Date(p.time * 1000) : undefined,
          });
          saved = true;
        } catch (err) { /* counted below */ }
      }
      if (!saved) failed.push(p.code);
    }

    if (entries.length) {
      setStatus("Building archive");
      const stamp = new Date().toISOString().slice(0, 10);
      saveBlob(await window.__igRatioZip.build(entries), `${handle().replace("@", "")} ${stamp}.zip`);
    }

    setBusy(false);
    setProgress(0);
    state.saving = false;
    refreshPicker();
    render(); // captions and dates picked up along the way
    sound(entries.length ? "done" : "fail");
    setStatus(
      failed.length
        ? `Saved ${entries.length}, ${failed.length} unavailable`
        : `Saved ${entries.length} file${entries.length === 1 ? "" : "s"}`
    );
  }

  /* --------------------------------------------------------- send to Claude

  The image can't travel between tabs as a Blob, so it goes as a data URI and
  is rebuilt on the other side. Downscaled first: a full-size Instagram photo
  is several megabytes, which is slow through the messaging channel and more
  resolution than a chat needs. */

  const SEND_MAX_EDGE = 1600;

  async function toDataUri(url) {
    const blob = await fetchAsset(url);
    if (blob.size <= 900 * 1024) return await readAsDataUri(blob);

    try {
      const bitmap = await createImageBitmap(blob);
      const scale = Math.min(1, SEND_MAX_EDGE / Math.max(bitmap.width, bitmap.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(bitmap.width * scale);
      canvas.height = Math.round(bitmap.height * scale);
      canvas.getContext("2d").drawImage(bitmap, 0, 0, canvas.width, canvas.height);
      return canvas.toDataURL("image/jpeg", 0.86);
    } catch (_) {
      return await readAsDataUri(blob); // not decodable, send as-is
    }
  }

  function readAsDataUri(blob) {
    return new Promise((ok, no) => {
      const reader = new FileReader();
      reader.onload = () => ok(reader.result);
      reader.onerror = () => no(new Error("could not read image"));
      reader.readAsDataURL(blob);
    });
  }

  /* --------------------------------------------------------- choosing a chat

  The picker used to appear only when several tabs were open, which meant most
  people never saw it and couldn't tell the feature existed. Now it always
  asks — unless a destination has been remembered, which is one tick away. That
  makes the choice visible and still gets out of the way for anyone who has
  settled on one chat. */

  const CHAT_PREF = "igratio:chattarget";
  const APP_LABEL = { claude: "Claude", chatgpt: "ChatGPT" };

  function rememberedTarget(key = CHAT_PREF) {
    try {
      const saved = JSON.parse(localStorage.getItem(key) || "null");
      return saved && saved.name ? saved : null;
    } catch (_) {
      return null;
    }
  }

  function rememberTarget(target, key = CHAT_PREF) {
    try {
      if (target) localStorage.setItem(key, JSON.stringify(target));
      else localStorage.removeItem(key);
    } catch (_) {}
  }

  async function chatTabs() {
    try {
      const reply = await chrome.runtime.sendMessage({ type: "igr-list-chat-tabs" });
      return (reply && reply.tabs) || [];
    } catch (_) {
      return [];
    }
  }

  // How long ago a chat was last looked at, in words.
  function ago(t) {
    const s = Math.max(0, (Date.now() - t) / 1000);
    if (s < 45) return "just now";
    if (s < 3600) return `${Math.round(s / 60)} min ago`;
    if (s < 86400) return `${Math.round(s / 3600)} h ago`;
    return "earlier";
  }

  /* Two chats can share a title — two "Claude Code" sessions, two "New chat"s
   * — and the picker used to show only the title, so there was no telling
   * them apart. Each row now also says which conversation it is: whether it's
   * in view, when it was last looked at, and a short form of its address. */
  function chatHint(tab) {
    const parts = [];
    if (tab.active) parts.push("In view");
    else if (tab.seen) parts.push(`Viewed ${ago(tab.seen)}`);
    try {
      const u = new URL(tab.url);
      const bits = u.pathname.split("/").filter(Boolean);
      const id = bits.length ? bits[bits.length - 1] : "";
      const place = bits.length > 1 ? `/${bits[0]}` : "";
      const tail = id ? `/${id.length > 12 ? `…${id.slice(-6)}` : id}` : "";
      parts.push(`${u.host.replace(/^www\./, "")}${place}${tail}`);
    } catch (_) { /* no address to show */ }
    return parts.join(" · ");
  }

  /* opts narrows the picker for a particular job — the crop goes to ChatGPT
   * only — and replaces the post strip with whatever is being sent. */
  function askWhichChat(tabs, post, options = {}) {
    const apps = options.apps || ["claude", "chatgpt"];
    return new Promise((resolve) => {
      if (!chatPicker) {
        chatPicker = el("div", "igr-modal igr-chatmodal");
        chatPicker.setAttribute("role", "dialog");
        chatPicker.setAttribute("aria-modal", "true");
        chatPicker.setAttribute("aria-label", "Choose a chat");
        chatPicker.innerHTML = `
          <div class="igr-scrim" data-role="chatscrim"></div>
          <div class="igr-card igr-chatcard" tabindex="-1">
            <header class="igr-chathead">
              <div class="igr-chathead-text">
                <h3 class="igr-chattitle">Send to a chat</h3>
                <p class="igr-chatsub">The picture and caption go in together.</p>
              </div>
              <button class="igr-icon" data-role="chatclose" aria-label="Cancel" data-tip="Cancel" data-tip-pos="end">${ICON.close}</button>
            </header>
            <div class="igr-chatpost" data-role="chatpost"></div>
            <div class="igr-chatlist" data-role="chatlist" role="listbox" aria-label="Chats"></div>
            <footer class="igr-chatfoot">
              <label class="igr-check igr-chatremember">
                <input type="checkbox" data-role="chatremember">
                <span>Always send here, stop asking</span>
              </label>
            </footer>
          </div>`;
        document.body.appendChild(chatPicker);
      }

      applyTheme();
      const q = (r) => chatPicker.querySelector(`[data-role="${r}"]`);
      const list = q("chatlist");
      list.innerHTML = "";
      chatPicker.querySelector(".igr-chattitle").textContent = options.title || "Send to a chat";
      chatPicker.querySelector(".igr-chatsub").textContent = options.sub || "The picture and caption go in together.";

      // What's being sent, so the choice is made looking at it.
      const strip = q("chatpost");
      strip.innerHTML = "";
      strip.hidden = !post && !options.strip;
      if (options.strip) {
        const s = options.strip;
        const thumb = s.thumbNode || el("span", "igr-chatpost-thumb");
        const text = el("span", "igr-chatpost-text");
        text.append(el("span", "igr-chatpost-who", s.who), el("span", "igr-chatpost-cap", s.line));
        strip.append(thumb, text, el("span", "igr-chatpost-kind", s.kind));
      } else if (post) {
        const thumb = el("span", "igr-chatpost-thumb");
        const src = post.thumb || post.preview;
        if (src) { const img = el("img"); img.alt = ""; img.src = src; thumb.appendChild(img); }
        const text = el("span", "igr-chatpost-text");
        text.append(
          el("span", "igr-chatpost-who", post.author ? `@${post.author}` : "This post"),
          el("span", "igr-chatpost-cap", (post.caption || "").split("\n").find((l) => l.trim()) || "No caption"),
        );
        strip.append(thumb, text, el("span", "igr-chatpost-kind", post.kind === "reel" ? "Reel" : slidesOf(post) ? "Carousel" : "Image"));
      }

      let settled = false;
      const opener = document.activeElement;

      // The page's videos would keep the blur behind the picker repainting;
      // if the viewer is open they're already paused, and this finds none.
      const paused = [...document.querySelectorAll("video")].filter((v) => !v.paused && !v.closest(".igr-modal"));
      paused.forEach((v) => { try { v.pause(); } catch (_) {} });

      const rows = () => [...list.querySelectorAll(".igr-chatrow")];

      // Escape cancels the picker alone, and the arrow keys move through the
      // list. Caught on the way down so the preview underneath doesn't react.
      const onKey = (e) => {
        if (e.key === "Escape") {
          e.preventDefault();
          e.stopImmediatePropagation();
          finish(null);
          return;
        }
        if (!["ArrowDown", "ArrowUp", "Home", "End"].includes(e.key)) return;
        const all = rows();
        if (!all.length) return;
        e.preventDefault();
        e.stopImmediatePropagation();
        const at = all.indexOf(document.activeElement);
        const to = e.key === "Home" ? 0 : e.key === "End" ? all.length - 1
          : at < 0 ? (e.key === "ArrowDown" ? 0 : all.length - 1)
          : (at + (e.key === "ArrowDown" ? 1 : -1) + all.length) % all.length;
        all[to].focus({ preventScroll: false });
      };

      const finish = (value) => {
        if (settled) return;
        settled = true;
        document.removeEventListener("keydown", onKey, true);
        chatPicker.classList.remove("is-open");
        paused.forEach((v) => { if (v.isConnected && v.paused) v.play().catch(() => {}); });
        if (opener && opener.isConnected) opener.focus({ preventScroll: true });
        resolve(value);
      };
      document.addEventListener("keydown", onKey, true);

      q("chatscrim").onclick = () => finish(null);
      q("chatclose").onclick = () => finish(null);
      const remember = q("chatremember");
      remember.checked = false;
      chatPicker.querySelector(".igr-chatfoot").hidden = options.remember === false;

      const pref = options.pref || CHAT_PREF;
      tabs = tabs.filter((t) => apps.includes(t.app));
      let row = 0;
      const group = (label) => {
        const head = el("p", "igr-chatgroup", label);
        head.style.setProperty("--i", Math.min(row++, 10));
        list.appendChild(head);
      };
      const addRow = (opts) => {
        const button = el("button", `igr-chatrow${opts.fresh ? " igr-chatrow--new" : ""}`);
        button.setAttribute("role", "option");
        button.style.setProperty("--i", Math.min(row++, 10));

        const mark = el("span", `igr-chatmark igr-chatmark--${opts.app}`);
        mark.innerHTML = opts.fresh ? ICON.plus : "<span></span>";
        button.appendChild(mark);

        const body = el("span", "igr-chatbody");
        body.append(el("span", "igr-chatname", opts.name));
        const hint = opts.fresh ? `Opens ${opts.app === "claude" ? "claude.ai" : "chatgpt.com"} in a new tab` : chatHint(opts);
        if (hint) body.append(el("span", "igr-chatmeta", hint));
        button.appendChild(body);

        if (!opts.fresh) button.appendChild(el("span", "igr-chatapp", APP_LABEL[opts.app] || opts.app));

        const go = el("span", "igr-chatgo");
        go.innerHTML = ICON.next;
        button.appendChild(go);

        button.onclick = () => {
          if (settled) return;
          const target = { app: opts.app, name: opts.fresh ? "" : opts.name, tabId: opts.id || null,
                           newIn: opts.fresh ? opts.app : null };
          // Remembered by address as well as name, so a chat that shares its
          // title with another can still be the one that's remembered.
          if (remember.checked && !opts.fresh) rememberTarget({ app: opts.app, name: opts.name, url: opts.url || "" }, pref);
          sound("current");

          // The choice is confirmed on the row before the picker goes.
          go.innerHTML = ICON.tick;
          button.classList.add("is-chosen");
          list.classList.add("has-choice");
          setTimeout(() => finish(target), reduceMotion() ? 0 : 260);
        };
        list.appendChild(button);
      };

      if (tabs.length) {
        group("Open chats");
        tabs.forEach((tab) => addRow({ ...tab }));
      }
      group(tabs.length ? "Start a new one" : "Start a chat");
      for (const app of apps) {
        addRow({ app, name: `New ${APP_LABEL[app]} chat`, fresh: true });
      }

      list.classList.remove("has-choice");
      chatPicker.classList.add("is-open");
      chatPicker.querySelector(".igr-card").focus({ preventScroll: true });
    });
  }

  async function chooseChatTarget(post, options = {}) {
    const apps = options.apps || ["claude", "chatgpt"];
    const tabs = (await chatTabs()).filter((t) => apps.includes(t.app));

    // A remembered chat skips the question. Its address is the surest match;
    // failing that (or for one remembered before addresses were kept), its
    // name, as long as exactly one open tab has it.
    const saved = options.remember === false ? null : rememberedTarget(options.pref);
    if (saved && apps.includes(saved.app)) {
      const byUrl = saved.url ? tabs.filter((t) => t.app === saved.app && t.url === saved.url) : [];
      if (byUrl.length) return { tabId: byUrl[0].id };
      const byName = tabs.filter((t) => t.app === saved.app && t.name === saved.name);
      if (byName.length === 1) return { tabId: byName[0].id };
    }

    const picked = await askWhichChat(tabs, post, options);
    if (!picked) return { cancelled: true };
    return { tabId: picked.tabId, newIn: picked.newIn };
  }

  async function sendToClaude(btn, post) {
    if (!post) return;
    if (!unlocked()) return showLicence();

    const view = slidesOf(post) ? viewOf(post) : post;

    if (needsLookup(post)) {
      flash(btn, "Looking up…", "busy");
      try { await lookupMedia(post); } catch (err) { console.warn("[IG Ratio]", err); }
    }

    const still = view.preview || view.thumb;
    const caption = post.caption || "";
    if (!still && !caption) return flash(btn, "Nothing to send", "bad");

    const target = await chooseChatTarget(view);
    if (target.cancelled) return flash(btn, "Cancelled", "bad");

    flash(btn, "Sending…", "busy");

    let image = null;
    if (still) {
      try {
        image = await toDataUri(still);
      } catch (err) {
        console.warn("[IG Ratio] image for Claude failed", err);
      }
    }

    try {
      const reply = await chrome.runtime.sendMessage({
        type: "igr-send-to-claude",
        payload: {
          tabId: target.tabId,
          newIn: target.newIn || null,
          image,
          mime: "image/jpeg",
          filename: fileName(view, ".jpg"),
          text: caption,
          url: view.url,
          author: post.author || "",
        },
      });

      if (reply && reply.ok) {
        sound("done");
        flash(btn, reply.partial ? "Sent, partly" : "Sent");
        if (reply.partial) setStatus(`Sent to Claude — ${reply.partial}`);
        return;
      }
      flash(btn, "Couldn't send", "bad");
      setStatus((reply && reply.reason) || "Couldn't reach that chat");
    } catch (err) {
      console.warn("[IG Ratio] send failed", err);
      flash(btn, "Couldn't send", "bad");
      setStatus("Couldn't reach the chat tab — is the extension still loaded?");
    }
  }

  /* -------------------------------------------------------------------- CSV */

  function exportCsv() {
    const { rows } = ranked();
    if (!rows.length) return;
    const lines = ["rank,shortcode,type,posted,likes,views,comments,likes_per_view,url"];
    rows.forEach((p, i) => {
      lines.push([
        i + 1, p.code, p.kind,
        p.time ? new Date(p.time * 1000).toISOString().slice(0, 10) : "",
        p.likes ?? "", p.views ?? "", p.comments ?? "",
        p.ratio == null ? "" : p.ratio.toFixed(6), p.url,
      ].join(","));
    });
    const blob = new Blob([lines.join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = el("a");
    a.href = url;
    a.download = `ig-ratio-${location.pathname.replace(/\//g, "") || "profile"}-${state.filter}.csv`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }

  /* ------------------------------------------------------------ feed capture

  On a profile you want the whole grid ranked. On the feed you want the one
  post in front of you. So on feed and permalink pages the launcher is
  replaced by a bar that follows the scroll: whatever post is sitting in the
  middle of the window is the one it's holding, updated once scrolling stops.

  The feed's own responses carry more than the profile grid does — caption,
  video renditions, author, date all arrive with the post — so a capture
  usually needs no extra lookup at all. */

  let tally = null;        // the "N kept" counter
  let watcher = null;      // Instagram re-renders posts constantly
  let mountTimer = null;

  function postFromArticle(art) {
    const link = art.querySelector('a[href*="/p/"], a[href*="/reel/"], a[href*="/tv/"]');
    const found = link && (link.getAttribute("href") || "").match(/\/(p|reel|tv)\/([^/?#]+)/);
    if (!found) return null;

    const [, seg, code] = found;
    const known = state.posts.get(code);
    const image = postImage(art);

    const post = known || {
      code,
      order: state.posts.size,
      fromFeed: true,
      kind: seg === "p" ? "photo" : "reel",
      url: `https://www.instagram.com/${seg}/${code}/`,
      thumb: image ? image.src : null,
      alt: image ? (image.alt || "").slice(0, 120) : "",
    };

    // A /p/ post can still be a video, and the feed renders one when it is.
    if (art.querySelector("video")) post.kind = "reel";

    merge(post, readIcons(art)); // the feed shows likes and comments outright
    const fromNetwork = netData.get(code);
    if (fromNetwork) {
      for (const k of ["likes", "views", "comments"]) {
        if (post[k] == null && fromNetwork[k] != null) post[k] = fromNetwork[k];
      }
      for (const k of ["thumb", "preview", "videos", "slides", "caption", "time", "pk", "author"]) {
        if (!post[k] && fromNetwork[k]) post[k] = fromNetwork[k];
      }
      if (fromNetwork.kind) post.kind = fromNetwork.kind;
    }
    if (!post.pk) post.pk = pkFromShortcode(code);
    if (!post.author) {
      const handleLink = [...art.querySelectorAll('a[href^="/"]')]
        .map((a) => (a.getAttribute("href") || "").match(/^\/([^/?#]+)\/?$/))
        .find(Boolean);
      if (handleLink) post.author = handleLink[1];
    }
    return post;
  }

  /* One object per post, reused across preview, download and keep, so that
   * anything a lookup fills in is visible everywhere at once. */
  function postFor(art) {
    const fresh = postFromArticle(art);
    if (!fresh) return null;
    const stored = state.posts.get(fresh.code);
    if (stored) return stored;
    if (art.__igrPost && art.__igrPost.code === fresh.code) return merge(art.__igrPost, fresh);
    art.__igrPost = fresh;
    return fresh;
  }

  function keepPost(post) {
    if (!post) return;
    if (!unlocked()) return showLicence();
    if (!state.posts.has(post.code)) {
      post.order = state.posts.size;
      state.posts.set(post.code, post);
    }
    state.selected.add(post.code);
    refreshCapture();
    if (panel) render();

    // The feed sometimes hands over almost nothing, so fill the gaps now
    // rather than at download time when the name and caption are needed.
    if (needsLookup(post)) {
      lookupMedia(post)
        .then((gained) => { if (gained) { refreshCapture(); if (panel) render(); } })
        .catch((err) => console.warn("[IG Ratio]", err));
    }
  }

  function showLicence() {
    if (!panel) buildPanel();
    openLicence();
  }

  /* --------------------------------------------------------- inline controls

  The controls belong on the post, not in the corner of the window: you decide
  about a post while you are looking at it. They sit in the top-right of the
  post's own header and stay out of the way until you hover it. */

  function hostFor(art) {
    return art.querySelector(".igr-inline");
  }

  /* Where the controls go.
   *
   * Every earlier version trusted the markup, and each broke on a different
   * shape of it. The last one took the avatar for the username — the avatar is
   * a link to the profile too — so on a long name, or a collab, the controls
   * landed on top of the name.
   *
   * This one reads only geometry. It finds the line the username sits on,
   * measures how far the name and everything attached to it runs (a badge,
   * "• 1h", "Follow", a collaborator), finds where Instagram's own icons begin
   * on that line, and fits the controls into the gap: full size, then icons
   * only, and failing both, onto the corner of the photo rather than over
   * anyone's name. */

  const GAP = 10;    // breathing room either side of the controls
  const RUN = 24;    // a jump wider than this ends the name's run of items

  function placeInHeader(art, host) {
    if (host.parentElement !== art) art.appendChild(host);
    // Once per post. This runs on every mutation Instagram makes, and a
    // computed-style read each time forced a style recalculation each time.
    if (art.__igrPlaced) return;
    art.__igrPlaced = true;
    if (getComputedStyle(art).position === "static") art.style.position = "relative";
  }

  // The username: a link straight to a profile, with words in it. The avatar
  // links to the same place but holds only a picture.
  function nameLinkOf(art) {
    return [...art.querySelectorAll('a[href^="/"]')].find((a) =>
      /^\/[^/?#]+\/?$/.test(a.getAttribute("href") || "") &&
      a.textContent.trim() && !a.closest(".igr-inline"));
  }

  // Everything drawn on one horizontal band of the post — text, icons,
  // buttons — as spans sorted left to right.
  function itemsOnBand(art, band) {
    const host = hostFor(art);
    const spans = [];
    const range = document.createRange();
    const walker = document.createTreeWalker(art, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, {
      acceptNode: (n) => (host && (n === host || host.contains(n)) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT),
    });
    while (walker.nextNode()) {
      const n = walker.currentNode;
      let boxes;
      if (n.nodeType === Node.TEXT_NODE) {
        if (!n.nodeValue.trim()) continue;
        range.selectNodeContents(n);
        boxes = range.getClientRects();
      } else if (/^(svg|img|button)$/i.test(n.tagName) || n.getAttribute("role") === "button") {
        boxes = [n.getBoundingClientRect()];
      } else {
        continue;
      }
      for (const b of boxes) {
        if (b.width && b.bottom > band.top && b.top < band.bottom) spans.push({ left: b.left, right: b.right });
      }
    }
    return spans.sort((x, y) => x.left - y.left);
  }

  function measureNameLine(art) {
    const name = nameLinkOf(art);
    if (!name) return null;
    const n = name.getBoundingClientRect();
    if (!n.width || !n.height) return null;

    const inset = Math.min(4, n.height / 4); // keep clear of the lines above and below
    const items = itemsOnBand(art, { top: n.top + inset, bottom: n.bottom - inset })
      .filter((s) => s.right > n.left);

    let end = n.right;
    let icons = null;
    for (const s of items) {
      if (s.right <= end) continue;            // part of what's already counted
      if (s.left - end > RUN) { icons = s.left; break; }
      end = s.right;
    }
    return { centre: (n.top + n.bottom) / 2, nameEnd: end, iconsStart: icons };
  }

  // The post's own photo or video: the largest one, so never the avatar.
  function postMedia(art) {
    const host = hostFor(art);
    let best = null;
    let area = 20000;
    for (const m of art.querySelectorAll("img, video")) {
      if (host && host.contains(m)) continue;
      const b = m.getBoundingClientRect();
      if (b.width * b.height > area) { area = b.width * b.height; best = m; }
    }
    return best;
  }

  // Width in either form, measured rather than assumed.
  function inlineWidth(host, compact) {
    const was = host.classList.contains("igr-inline--compact");
    host.classList.toggle("igr-inline--compact", compact);
    const width = host.offsetWidth;
    host.classList.toggle("igr-inline--compact", was);
    return width;
  }

  function setInlineMode(host, mode) {
    host.classList.toggle("igr-inline--compact", mode === "compact" || mode === "media-compact");
    host.classList.toggle("igr-inline--overlay", mode.startsWith("media"));
  }

  function positionInline(art) {
    const host = hostFor(art);
    if (!host) return;
    const a = art.getBoundingClientRect();
    const full = inlineWidth(host, false);
    const compact = inlineWidth(host, true);
    const line = measureNameLine(art);

    if (line) {
      const limit = (line.iconsStart != null ? line.iconsStart : a.right - 8) - GAP;
      const room = limit - (line.nameEnd + GAP);
      const fits = room >= full ? "full" : room >= compact ? "compact" : null;
      if (fits) {
        setInlineMode(host, fits);
        anchorInline(host, line.centre - a.top, a.right - limit);
        return;
      }
    }

    // No room on the name line: the top-right corner of the photo instead.
    const media = postMedia(art);
    if (media) {
      const m = media.getBoundingClientRect();
      setInlineMode(host, m.width < full + 24 ? "media-compact" : "media");
      anchorInline(host, m.top - a.top + 12, a.right - m.right + 12);
      return;
    }

    // Nothing to measure against at all: tuck it into the top-right corner.
    setInlineMode(host, "compact");
    anchorInline(host, 28, 8);
  }

  // Pinned by its right edge, so a label that changes width ("Keep" to
  // "Kept") grows away from Instagram's icons rather than into them.
  function anchorInline(host, top, right) {
    host.style.top = `${top}px`;
    host.style.left = "auto";
    host.style.right = `${Math.max(0, right)}px`;
  }

  function syncInline(art) {
    const host = hostFor(art);
    if (!host) return;
    const link = art.querySelector('a[href*="/p/"], a[href*="/reel/"], a[href*="/tv/"]');
    const found = link && (link.getAttribute("href") || "").match(/\/(p|reel|tv)\/([^/?#]+)/);
    const keep = host.querySelector('[data-act="keep"]');
    const kept = found ? state.posts.has(found[2]) : false;
    keep.disabled = kept;

    // Redrawn only when the state flips, so the tick draws on exactly once.
    const want = kept ? "kept" : "keep";
    if (keep.dataset.state === want) return;
    keep.dataset.state = want;
    keep.classList.toggle("is-kept", kept);
    keep.innerHTML = `${kept ? ICON.tickSm : ICON.plusSm}<span>${kept ? "Kept" : "Keep"}</span>`;
    keep.dataset.tip = kept ? "In your kept list" : "Keep this post";
    keep.setAttribute("aria-label", kept ? "Kept" : "Keep this post");
  }

  function mountInline(art) {
    const existing = hostFor(art);
    if (existing) {
      // Instagram re-renders posts; re-home the controls if ours drifted.
      // They're only measured when about to be seen — this runs on every
      // mutation Instagram makes, for every post on the page.
      placeInHeader(art, existing);
      if (art.matches(":hover")) positionInline(art);
      return;
    }
    if (!art.querySelector('a[href*="/p/"], a[href*="/reel/"], a[href*="/tv/"]')) return;

    art.classList.add("igr-host");

    const host = el("div", "igr-inline");
    host.innerHTML = `
      <button class="igr-chiplet" data-act="preview" aria-label="Preview this post" data-tip="Preview">${ICON.eye}</button>
      <button class="igr-chiplet" data-act="save" aria-label="Download this post" data-tip="Download">${ICON.down}</button>
      <button class="igr-chiplet" data-act="claude" aria-label="Send this post to a chat" data-tip="Send to a chat">${ICON.send}</button>
      <button class="igr-keep" data-act="keep"></button>
    `;

    host.querySelector('[data-act="preview"]').onclick = (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (!unlocked()) return showLicence();
      const post = postFor(art);
      if (!post) return;
      // Decorate in place rather than on a copy, so a lookup fired from the
      // preview reaches the kept list as well.
      Object.assign(post, decorate(withRatio(post), "ratio"));
      openPreview(0, [post], () => postMedia(art));
    };

    host.querySelector('[data-act="save"]').onclick = (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (!unlocked()) return showLicence();
      saveOne(e.currentTarget, postFor(art));
    };

    host.querySelector('[data-act="claude"]').onclick = (e) => {
      e.preventDefault();
      e.stopPropagation();
      sendToClaude(e.currentTarget, postFor(art));
    };

    host.querySelector('[data-act="keep"]').onclick = (e) => {
      e.preventDefault();
      e.stopPropagation();
      keepPost(postFor(art));
      syncInline(art);
      positionInline(art); // "Kept" is a different width; re-fit it
    };

    art.addEventListener("mouseenter", () => { syncInline(art); positionInline(art); });
    host.addEventListener("focusin", () => positionInline(art)); // reached by Tab, not hover
    placeInHeader(art, host);
    paint(host, resolvedTheme());
    syncInline(art);
  }

  function mountAll() {
    if (pageKind() !== "feed") return;
    for (const art of document.querySelectorAll("article")) mountInline(art);
  }

  // At most every 200ms, and never starved. As a debounce this never ran at
  // all while Instagram kept changing the page — autoplay, timers, lazy images
  // — so new posts could go a long time without their controls.
  function scheduleMount() {
    if (mountTimer) return;
    mountTimer = setTimeout(() => { mountTimer = null; mountAll(); }, 200);
  }

  function buildTally() {
    tally = el("button", "igr-tally");
    tally.hidden = true;
    tally.onclick = () => { if (!panel) buildPanel(); };
    document.body.appendChild(tally);
    applyTheme();
  }

  // Kept for the call sites that already refresh feed state after a change.
  function refreshCapture() {
    if (tally) {
      const count = state.posts.size;
      const wasHidden = tally.hidden;
      tally.hidden = !count || pageKind() !== "feed";
      if (wasHidden && !tally.hidden) liftCorner(true);
      // This runs on every render; only redraw — and animate — on a new count.
      if (tally.dataset.count !== String(count)) {
        const grew = Number(tally.dataset.count || 0) < count && !tally.hidden;
        tally.dataset.count = String(count);
        tally.innerHTML = `${ICON.keep}<span class="igr-tally-text"><span class="igr-tally-n${grew ? " is-changed" : ""}">${count}</span> kept</span>`;
        tally.setAttribute("aria-label", `${count} kept — open the list`);
      }
    }
    for (const art of document.querySelectorAll("article.igr-host")) syncInline(art);
  }

  /* --------------------------------------------------------------- launcher */

  function makeLauncher() {
    const b = el("button", "igr-launch");
    b.innerHTML = `${ICON.chart}<span>Post performance</span>`;
    b.onclick = () => {
      b.classList.add("is-hidden");
      if (!panel) buildPanel();
    };
    return b;
  }

  function isProfilePage() {
    const parts = location.pathname.split("/").filter(Boolean);
    if (!parts.length) return false;
    const reserved = ["explore", "direct", "accounts", "stories", "p", "reel", "reels", "tv", "about", "legal", "challenge"];
    if (reserved.includes(parts[0])) return false;
    return parts.length === 1 || ["reels", "tagged", "saved", "feed"].includes(parts[1]);
  }

  function isFeedPage() {
    const path = location.pathname;
    if (path === "/" || path === "") return true;                 // home feed
    if (/^\/(p|reel|tv)\/[^/]+\/?$/.test(path)) return true;      // a single post
    return /^\/(reels|explore)(\/|$)/.test(path);                  // reels feed, explore
  }

  const pageKind = () => (isProfilePage() ? "profile" : isFeedPage() ? "feed" : null);

  /* Instagram parks its own floating "Messages" pill in the bottom-right
   * corner — exactly where the launcher and the kept counter sit. Rather than
   * cover it, ours step up above whatever small fixed thing is down there. */
  const CORNER = 24;

  // Points across the patch of corner the launcher covers.
  const CORNER_PROBES = [[40, 34], [110, 34], [190, 34], [40, 60], [110, 60], [190, 60]];

  function cornerClearance() {
    let clear = CORNER;
    for (const [dx, dy] of CORNER_PROBES) {
      for (const node of document.elementsFromPoint(innerWidth - dx, innerHeight - dy)) {
        if (node.closest(".igr, .igr-launch, .igr-tally, .igr-modal")) continue;
        let docked = null;
        for (let n = node; n && n !== document.body && n !== document.documentElement; n = n.parentElement) {
          if (getComputedStyle(n).position === "fixed") { docked = n; break; }
        }
        if (!docked) continue;
        const box = docked.getBoundingClientRect();
        // Something docked in the corner, not something covering the page.
        if (box.height < 180 && box.top > innerHeight / 2) {
          clear = Math.max(clear, Math.round(innerHeight - box.top + 12));
        }
        break;
      }
    }
    return clear;
  }

  // Probing forces a layout, so it only runs for what's actually showing, and
  // every few seconds — or straight away when the window changes size or
  // something has just appeared in the corner.
  let cornerAt = 0;
  let cornerSize = "";

  function liftCorner(now = false) {
    const nodes = [launcher, tally].filter((n) => n && n.isConnected && !n.hidden && !n.classList.contains("is-hidden"));
    if (!nodes.length) return;
    const size = `${innerWidth}x${innerHeight}`;
    if (!now && size === cornerSize && Date.now() - cornerAt < 4000) return;
    cornerSize = size;
    cornerAt = Date.now();
    const bottom = `${Math.max(CORNER, cornerClearance())}px`;
    for (const n of nodes) if (n.style.bottom !== bottom) n.style.bottom = bottom;
  }

  function sync() {
    const kind = pageKind();

    if (kind === "profile") {
      if (!launcher) { launcher = makeLauncher(); applyTheme(); }
      if (!launcher.isConnected) document.body.appendChild(launcher);
      if (!panel) launcher.classList.remove("is-hidden");
    } else if (launcher) {
      launcher.remove();
    }

    if (kind === "feed") {
      if (!tally) buildTally();
      if (!tally.isConnected) document.body.appendChild(tally);
      if (!watcher) {
        // Instagram swaps posts in and out as you scroll, so re-mount on change.
        watcher = new MutationObserver(scheduleMount);
        watcher.observe(document.body, { childList: true, subtree: true });
      }
      mountAll();
      refreshCapture();
    } else {
      if (watcher) { watcher.disconnect(); watcher = null; }
      if (tally) tally.hidden = true;
      for (const art of document.querySelectorAll("article.igr-host")) {
        art.classList.remove("igr-host");
        const host = hostFor(art);
        if (host) host.remove();
      }
    }

    if (!kind && panel) closePanel();
    liftCorner();
  }

  loadPrefs();
  checkLicence().then(() => { if (panel) { refreshLicenceUI(); render(); } });

  let lastPath = location.pathname;
  let lastKind = pageKind();

  setInterval(() => {
    if (location.pathname !== lastPath) {
      lastPath = location.pathname;
      const kind = pageKind();
      // Moving between feed pages keeps what you've kept; switching to a
      // profile grid is a different dataset, so that starts clean.
      if (kind !== lastKind || kind === "profile") {
        state.posts.clear();
        state.selected.clear();
      }
      lastKind = kind;
      if (panel) render();
      refreshCapture();
    }
    if (state.theme === "auto") applyTheme();
    sync();
  }, 1000);

  sync();
})();
