/* smartcrop.js - finds the embedded photos in a screenshot of a social post.
 *
 * Classic script, no dependencies: assigns window.__igRatioCrop = { detect, retouch }.
 * Pure computation on an RGBA pixel array, so it runs unchanged in a content
 * script and in Node's vm.
 *
 * Pipeline (see detect()):
 *   1. marks     - hand-drawn red annotation strokes, found by shape (thin, long,
 *                  saturated red), are masked out and used as a hint.
 *   2. bg        - candidate post backgrounds are the *flat* colours that cover
 *                  an image side; typical post colours are tried first.
 *   3. grid      - reduced-resolution cells: content where the cell mean differs
 *                  from the background (robust to JPEG ringing, which averages out).
 *   4. XY-cut    - recursive projection-profile segmentation of the content
 *                  grid on background gutters into layout blocks.
 *   5. classify  - leaf blocks that are large, dense and rectangular are photos;
 *                  text lines, avatars, icons and rules are not - and they are
 *                  the evidence that the colour really is a post background.
 *   6. group     - photo blocks that touch or are separated by thin dividers
 *                  become one collage.
 *   7. refine    - every edge is re-located at full resolution.
 *   8. parts     - collages are split on thin uniform divider bands, or on
 *                  straight seams where photos touch.
 *   9. hint      - an overlay polygon or a baked red loop picks the primary
 *                  candidate, possibly a single photo of a collage.
 * The whole image is reported (wholeImage) only when no background carries
 * text or UI and the flat areas do not look like a letterboxed post either.
 */
(function () {
  "use strict";

  // Local aliases: global lookups are slow inside sandboxed realms (vm contexts).
  var abs = Math.abs, min = Math.min, max = Math.max, round = Math.round;
  var floor = Math.floor, ceil = Math.ceil, sqrt = Math.sqrt;
  var U8 = Uint8Array, U16 = Uint16Array, U32 = Uint32Array, I32 = Int32Array, F32 = Float32Array, F64 = Float64Array;

  /* ------------------------------------------------------------ tuning */

  var GRID_MAX = 340;      // longest side of the analysis grid, in cells
  var CELL_CONTENT = 8;    // cell-mean distance from the background that counts as content
  var PIX_CONTENT = 10;    // per-pixel distance used by the full-resolution edge search
  var MIN_SIDE = 0.08;     // photos are at least this fraction of the short image side
  var MIN_AREA = 0.015;    // ... and cover at least this fraction of the image

  /* ------------------------------------------------------------ helpers */

  function rect(x, y, w, h) { return { x: x, y: y, w: w, h: h }; }

  function iou(a, b) {
    var x0 = max(a.x, b.x), y0 = max(a.y, b.y);
    var x1 = min(a.x + a.w, b.x + b.w), y1 = min(a.y + a.h, b.y + b.h);
    var i = max(0, x1 - x0) * max(0, y1 - y0);
    var u = a.w * a.h + b.w * b.h - i;
    return u > 0 ? i / u : 0;
  }

  function maxChanDiff(D, o, c) {
    var dr = D[o] - c[0], dg = D[o + 1] - c[1], db = D[o + 2] - c[2];
    if (dr < 0) dr = -dr; if (dg < 0) dg = -dg; if (db < 0) db = -db;
    return dr > dg ? (dr > db ? dr : db) : (dg > db ? dg : db);
  }

  /**
   * Chebyshev (square) dilation of a w*h 0/1 mask by k pixels. Separable;
   * both passes walk memory row by row (the vertical one keeps, per column,
   * the distance to the last set pixel).
   */
  function dilate(src, w, h, k) {
    var tmp = new U8(w * h), out = new U8(w * h), x, y, row, last;
    for (y = 0; y < h; y++) {
      row = y * w;
      last = -1e9;
      for (x = 0; x < w; x++) { if (src[row + x]) last = x; if (x - last <= k) tmp[row + x] = 1; }
      last = 1e9;
      for (x = w - 1; x >= 0; x--) { if (src[row + x]) last = x; if (last - x <= k) tmp[row + x] = 1; }
    }
    var dist = new I32(w);
    for (x = 0; x < w; x++) dist[x] = 1e9;
    for (y = 0; y < h; y++) {
      row = y * w;
      for (x = 0; x < w; x++) {
        if (tmp[row + x]) dist[x] = 0; else dist[x]++;
        if (dist[x] <= k) out[row + x] = 1;
      }
    }
    for (x = 0; x < w; x++) dist[x] = 1e9;
    for (y = h - 1; y >= 0; y--) {
      row = y * w;
      for (x = 0; x < w; x++) {
        if (tmp[row + x]) dist[x] = 0; else dist[x]++;
        if (dist[x] <= k) out[row + x] = 1;
      }
    }
    return out;
  }

  function erode(src, w, h, k) {
    var n = w * h, inv = new U8(n), i;
    for (i = 0; i < n; i++) inv[i] = src[i] ? 0 : 1;
    var d = dilate(inv, w, h, k);
    for (i = 0; i < n; i++) d[i] = d[i] ? 0 : 1;
    return d;
  }

  /* ------------------------------------------------------------ 1. red marks */

  // Most of the image a drawing may cover: a loop around a whole post at
  // several pen widths, zig-zags included, stays well under this.
  var MARK_MAX_SHARE = 0.1;

  /**
   * Hand-drawn annotation strokes, in three steps.
   *
   *  a. Seeds: saturated red pixels, 3x3-closed so JPEG-speckled natural reds
   *     become solid blobs. The local thickness of a pixel is the shorter of
   *     the horizontal and vertical runs through it; connected thin pieces
   *     that are long and one-dimensional are unmistakable stroke pieces
   *     (isLongStroke), shorter ones count near those (isStrokeFragment).
   *     They decide whether there is a drawing at all and where its loop is.
   *  b. Pen model: a drawing is one pen - one colour, one width - measured on
   *     the seeds (strokeModel). Seed pieces of another hue are natural reds.
   *  c. Trace: from the seeds, flood over thin pixels of the pen's colour
   *     (traceStroke). This follows the stroke where it runs over or next to
   *     red photo content (pink, orange, skin), which the saturation test
   *     alone merges with the stroke, and never enters natural reds of
   *     another colour or thick regions of the pen's own colour.
   *
   * The reported mask is the traced stroke plus its anti-aliased / JPEG
   * fringe (tinted pixels within 2px), so it hugs the stroke.
   *
   * Works in the bounding window of the red pixels; after the per-pixel
   * passes that need whole masks, everything runs on pixel lists.
   *
   * Returns { baked, box (extent of the pen's seed pieces), mask (W*H), avoid (W*H,
   * mask dilated by 4px, excluded from analysis), color (mean stroke colour) }.
   */
  function findMarks(W, H, D) {
    var none = { baked: false, box: null, mask: null, avoid: null };
    var N = W * H, minDim = min(W, H), i, k, o, x, y, p, P;
    var bx0 = W, by0 = H, bx1 = -1, by1 = -1, cnt = 0;
    // 2: saturated red (seed candidates); 1: reddish, may still be the pen
    // where JPEG or downscaling washed it out
    var cand = new U8(N);
    for (y = 0, i = 0; y < H; y++) {
      for (x = 0; x < W; x++, i++) {
        o = i << 2;
        var r = D[o], g = D[o + 1], b = D[o + 2], e = r - (g > b ? g : b);
        if (e < 40) continue;
        if (r >= 110 && e >= 70) {
          cand[i] = 2; cnt++;
          if (x < bx0) bx0 = x; if (x > bx1) bx1 = x;
          if (y < by0) by0 = y; if (y > by1) by1 = y;
        } else cand[i] = 1;
      }
    }
    if (cnt < minDim * 0.5) return none;

    // work in a local window around the saturated pixels
    var pad = 16;
    var X0 = max(0, bx0 - pad), Y0 = max(0, by0 - pad), X1 = min(W, bx1 + pad + 1), Y1 = min(H, by1 + pad + 1);
    var w = X1 - X0, h = Y1 - Y0, n = w * h;
    var win = { W: W, H: H, X0: X0, Y0: Y0, w: w, h: h, n: n };
    var loc = new U8(n);
    for (y = 0; y < h; y++) {
      var src = (Y0 + y) * W + X0, dst = y * w;
      for (x = 0; x < w; x++) loc[dst + x] = cand[src + x] >> 1;
    }
    var lim = {
      minDim: minDim,
      maxW: max(10, round(minDim * 0.014)),       // thickest stroke considered
      minLen: minDim * 0.15,                       // unmistakable piece length
      relaxedLen: max(10, minDim * 0.015),         // fragment length near accepted pieces
      reach: max(12, round(minDim * 0.05)),        // how near a fragment must be
    };

    // a. seeds: thin pieces of the closed saturated-red mask
    var clo = close3(loc, w, h);
    var hrun = new U16(n), vrun = new U16(n), thin = new U8(n), lab = new I32(n);
    var order = new I32(thinPixels(clo, w, h, lim.maxW, hrun, vrun, thin).thin);
    var pieces = labelPieces(thin, clo, w, h, hrun, vrun, lab, order);
    var nSeed = 0;
    for (p = 1; p < pieces.length; p++) {
      P = pieces[p];
      if (isLongStroke(P, lim)) { P.ok = P.primary = true; nSeed += P.area; }
    }
    var ext = acceptedExtent(pieces, w, h);
    // annotations are drawn around things: tiny accepted sets are natural
    // reds; and a loop is a line, so line work all over the image (stripes,
    // a red pattern) is content
    if (!nSeed || max(ext[2] - ext[0], ext[3] - ext[1]) < minDim * 0.15 || nSeed > N * MARK_MAX_SHARE) return none;
    // shorter pieces of the same drawing near the accepted ones (zig-zags,
    // segments broken where the stroke crosses red photo areas)
    if (acceptNear(pieces, order, null, 0, w, h, lim)) ext = acceptedExtent(pieces, w, h);

    // b. pen colour and width from the unmistakable pieces. A pen is a vivid
    // red; natural reds that pass the shape tests (skin, rust, the rim of a
    // blurred red blob) are duller. Pieces of another hue are not part of
    // the drawing, so they do not widen the hint box either.
    var model = strokeModel(D, win, loc, pieces, order);
    if (model.color[0] - max(model.color[1], model.color[2]) < 100) return none;
    for (p = 1; p < pieces.length; p++) if (!pieces[p].pen) pieces[p].ok = false;
    ext = acceptedExtent(pieces, w, h);
    if (max(ext[2] - ext[0], ext[3] - ext[1]) < minDim * 0.15) return none;

    // c. the full stroke; thin enough for the pen means up to two
    // overlapping passes (a loop closed over its own start). The seed
    // buffers are reused.
    var maxT = min(3 * lim.maxW, max(4, ceil(2 * model.width) + 1));
    var tr = traceStroke(D, win, cand, pieces, order, model, maxT, lim, { hrun: hrun, vrun: vrun, thin: thin, lab: lab });
    var list = tr.list, nb = tr.count;
    if (nb > N * MARK_MAX_SHARE) return none;

    // mask = stroke + fringe (anti-aliasing and JPEG smear tint up to 2px
    // around it); lm: 1 in the mask, 2 looked at and left out
    var mask = new U8(N), lm = new U8(n);
    var scr = 0, scg = 0, scb = 0, scn = 0;
    for (k = 0; k < nb; k++) {
      i = list[k]; lm[i] = 1;
      x = i % w; y = (i - x) / w;
      var gi = (Y0 + y) * W + X0 + x;
      mask[gi] = 1;
      if (loc[i]) { o = gi << 2; scr += D[o]; scg += D[o + 1]; scb += D[o + 2]; scn++; }
    }
    for (k = 0; k < nb; k++) {
      i = list[k]; x = i % w; y = (i - x) / w;
      for (var dy = -2; dy <= 2; dy++) {
        var yy = y + dy;
        if (yy < 0 || yy >= h) continue;
        for (var dx = -2; dx <= 2; dx++) {
          var xx = x + dx;
          if (xx < 0 || xx >= w) continue;
          var q = yy * w + xx;
          if (lm[q]) continue;
          var gq = (Y0 + yy) * W + X0 + xx;
          o = gq << 2;
          if (D[o] - (D[o + 1] > D[o + 2] ? D[o + 1] : D[o + 2]) >= 28) { lm[q] = 1; mask[gq] = 1; } else lm[q] = 2;
        }
      }
    }
    return {
      baked: true,
      box: rect(X0 + ext[0], Y0 + ext[1], ext[2] - ext[0] + 1, ext[3] - ext[1] + 1),
      mask: mask,
      avoid: avoidZone(lm, win, 4),
      color: scn ? [scr / scn, scg / scn, scb / scn] : model.color,
    };
  }

  /**
   * The image-size mask of pixels within k (Chebyshev) of a window pixel with
   * lm === 1, clipped to the window: each horizontal run of the mask paints
   * its rectangle.
   */
  function avoidZone(lm, win, k) {
    var w = win.w, h = win.h, W = win.W, avoid = new U8(W * win.H), x, y, a, xa, xb, yy, row;
    for (y = 0; y < h; y++) {
      row = y * w;
      for (x = 0; x < w; x++) {
        if (lm[row + x] !== 1) continue;
        a = x;
        while (x + 1 < w && lm[row + x + 1] === 1) x++;
        xa = win.X0 + max(0, a - k); xb = win.X0 + min(w - 1, x + k);
        for (yy = max(0, y - k); yy <= min(h - 1, y + k); yy++) {
          var base = (win.Y0 + yy) * W;
          for (var gx = xa; gx <= xb; gx++) avoid[base + gx] = 1;
        }
      }
    }
    return avoid;
  }

  /** 3x3 binary closing: dilation, then erosion (outside the window: unset, then set). */
  function close3(src, w, h) {
    var n = w * h, a = new U8(n), b = new U8(n), i, row, end;
    if (w < 2 || h < 2) { b.set(src); return b; }
    for (row = 0; row < n; row += w) {
      end = row + w - 1;
      a[row] = src[row] | src[row + 1];
      for (i = row + 1; i < end; i++) a[i] = src[i - 1] | src[i] | src[i + 1];
      a[end] = src[end - 1] | src[end];
    }
    for (i = 0; i < w; i++) b[i] = a[i] | a[i + w];
    for (end = n - w; i < end; i++) b[i] = a[i - w] | a[i] | a[i + w];
    for (; i < n; i++) b[i] = a[i - w] | a[i];
    for (row = 0; row < n; row += w) {
      end = row + w - 1;
      a[row] = b[row] & b[row + 1];
      for (i = row + 1; i < end; i++) a[i] = b[i - 1] & b[i] & b[i + 1];
      a[end] = b[end - 1] & b[end];
    }
    for (i = 0; i < w; i++) b[i] = a[i] & a[i + w];
    for (end = n - w; i < end; i++) b[i] = a[i - w] & a[i] & a[i + w];
    for (; i < n; i++) b[i] = a[i - w] & a[i];
    return b;
  }

  /**
   * Horizontal and vertical run length through every set pixel of a w*h
   * mask; sets `thin` where the shorter of the two is at most maxT. Returns
   * the numbers of set and of thin pixels.
   */
  function thinPixels(m, w, h, maxT, hrun, vrun, thin) {
    var n = w * h, x, s, k, i, cnt = 0, set = 0;
    for (var row = 0; row < n; row += w) {
      x = 0;
      while (x < w) {
        if (!m[row + x]) { hrun[row + x] = 0; x++; continue; }
        s = x;
        while (x < w && m[row + x]) x++;
        for (k = s; k < x; k++) hrun[row + k] = x - s;
      }
    }
    // vertical runs: count down each run, then copy its length up
    for (i = 0; i < n; i++) vrun[i] = m[i] ? (i >= w && m[i - w] ? vrun[i - w] + 1 : 1) : 0;
    for (i = n - 1; i >= 0; i--) {
      if (!m[i]) continue;
      set++;
      if (i + w < n && m[i + w]) vrun[i] = vrun[i + w];
      if (hrun[i] <= maxT || vrun[i] <= maxT) { thin[i] = 1; cnt++; }
    }
    return { set: set, thin: cnt };
  }

  /**
   * 8-connected pieces of `thin` (labels into lab, 1-based) with their shape
   * statistics: area, mean thickness t, length (area / t), bounding box and
   * touch - the share of pixels next to a thick pixel of `solid`. The pixels
   * of piece P are order[P.start .. P.end).
   */
  function labelPieces(thin, solid, w, h, hrun, vrun, lab, order) {
    var n = w * h, pieces = [null], tail = 0;
    for (var start = 0; start < n; start++) {
      if (!thin[start] || lab[start]) continue;
      var id = pieces.length, head = tail, sumT = 0, touch = 0;
      var x0 = w, y0 = h, x1 = -1, y1 = -1;
      order[tail++] = start; lab[start] = id;
      for (var rd = head; rd < tail; rd++) {
        var j = order[rd], jx = j % w, jy = (j - jx) / w, tj = 0;
        sumT += hrun[j] < vrun[j] ? hrun[j] : vrun[j];
        if (jx < x0) x0 = jx; if (jx > x1) x1 = jx;
        if (jy < y0) y0 = jy; if (jy > y1) y1 = jy;
        for (var dy = -1; dy <= 1; dy++) {
          var yy = jy + dy;
          if (yy < 0 || yy >= h) continue;
          for (var dx = -1; dx <= 1; dx++) {
            var xx = jx + dx;
            if (xx < 0 || xx >= w) continue;
            var q = yy * w + xx;
            if (thin[q]) { if (!lab[q]) { lab[q] = id; order[tail++] = q; } }
            else if (solid[q]) tj = 1;
          }
        }
        touch += tj;
      }
      var area = tail - head, t = sumT / area;
      pieces.push({ area: area, t: t, len: area / max(1, t), touch: touch / area,
        x0: x0, y0: y0, x1: x1, y1: y1, start: head, end: tail,
        ok: false, tried: false, primary: false, pen: false, penPx: 0 });
    }
    return pieces;
  }

  /**
   * Unmistakable stroke piece: long, thin and one-dimensional (a curve's
   * length is bounded by its bounding box - a loop is at most its perimeter
   * plus zig-zag - while a speckled 2-D region packs far more "length" into
   * its box), and not the rim of a solid red region (rims border thick red
   * everywhere).
   */
  function isLongStroke(P, lim) {
    var bw = P.x1 - P.x0 + 1, bh = P.y1 - P.y0 + 1;
    return P.len >= lim.minLen && max(bw, bh) >= lim.minDim * 0.1 && P.len / P.t >= 12 &&
      P.len <= 3.5 * (bw + bh) && P.touch <= 0.35;
  }

  /** A shorter piece that still reads as a line; only taken near accepted pieces. */
  function isStrokeFragment(P, lim) {
    return P.len >= lim.relaxedLen && P.len / P.t >= 4 && P.touch <= 0.5;
  }

  /** Bounding box [x0, y0, x1, y1] of the accepted pieces. */
  function acceptedExtent(pieces, w, h) {
    var e = [w, h, -1, -1];
    for (var p = 1; p < pieces.length; p++) {
      var Q = pieces[p];
      if (!Q.ok) continue;
      if (Q.x0 < e[0]) e[0] = Q.x0; if (Q.y0 < e[1]) e[1] = Q.y0;
      if (Q.x1 > e[2]) e[2] = Q.x1; if (Q.y1 > e[3]) e[3] = Q.y1;
    }
    return e;
  }

  /**
   * Accepts the fragments (not yet ok, not ruled out by `tried`) with a pixel
   * within lim.reach (Chebyshev) of an accepted piece or of one of the first
   * nExtra pixels of `extra`; returns whether any was. Proximity is tested on
   * a grid of 4px cells, which errs by at most a cell toward accepting.
   */
  function acceptNear(pieces, order, extra, nExtra, w, h, lim) {
    var cs = 4, gw = ceil(w / cs), gh = ceil(h / cs), occ = new U8(gw * gh), p, P, k, i, x, more = false;
    var cand = [];
    for (p = 1; p < pieces.length; p++) {
      P = pieces[p];
      if (!P.ok && !P.tried && isStrokeFragment(P, lim)) cand.push(P);
    }
    if (!cand.length) return false;
    for (p = 1; p < pieces.length; p++) {
      P = pieces[p];
      if (!P.ok) continue;
      for (k = P.start; k < P.end; k++) {
        i = order[k]; x = i % w;
        occ[((i - x) / w / cs | 0) * gw + (x / cs | 0)] = 1;
      }
    }
    for (k = 0; k < nExtra; k++) {
      i = extra[k]; x = i % w;
      occ[((i - x) / w / cs | 0) * gw + (x / cs | 0)] = 1;
    }
    var near = dilate(occ, gw, gh, ceil(lim.reach / cs));
    for (var c = 0; c < cand.length; c++) {
      P = cand[c];
      for (k = P.start; k < P.end; k++) {
        i = order[k]; x = i % w;
        if (near[((i - x) / w / cs | 0) * gw + (x / cs | 0)]) { P.ok = true; more = true; break; }
      }
    }
    return more;
  }

  /** Value below which `frac` of the counts of a 256-bin histogram lie. */
  function histQuantile(hist, total, frac) {
    var need = total * frac, acc = 0;
    for (var v = 0; v < 256; v++) { acc += hist[v]; if (acc > need) return v; }
    return 255;
  }

  /**
   * Pen model from the saturated pixels of the stage-1 pieces:
   *  - colour: per-channel median of their more saturated half (the rest is
   *    fringe mixed with whatever is underneath);
   *  - tolerances, from how far JPEG noise scatters those pixels: per RGB
   *    channel; the range of their luma (a darker or lighter red of the pen's
   *    hue - shadowed paint, a dark red photo region - differs from the pen
   *    mainly in luma, which JPEG keeps sharp, while a pen washed out by its
   *    background only moves toward that background's luma); and their hue;
   *  - width: the area-weighted mean thickness of the pieces.
   * Every accepted piece is then checked against the pen (sets piece.pen): a
   * piece of the drawing has pen-coloured pixels along its middle even where
   * downscaling washed out the rest, a natural red (skin, paint, the rim of a
   * blurred red blob) has a colour of its own.
   */
  function strokeModel(D, win, loc, pieces, order) {
    var hr = new U32(256), hg = new U32(256), hb = new U32(256), he = new U32(256);
    var hy = new U32(256), hd = new U32(256), hh = new U32(256);
    var w = win.w, W = win.W, X0 = win.X0, Y0 = win.Y0, p, P, k, i, o, tot = 0, sel = 0;
    function offset(j) { var jx = j % w; return ((Y0 + (j - jx) / w) * W + X0 + jx) << 2; }
    function redness(q) { return D[q] - (D[q + 1] > D[q + 2] ? D[q + 1] : D[q + 2]); }
    for (p = 1; p < pieces.length; p++) {
      P = pieces[p];
      if (!P.primary) continue;
      for (k = P.start; k < P.end; k++) if (loc[order[k]]) { he[redness(offset(order[k]))]++; tot++; }
    }
    var eMid = histQuantile(he, tot, 0.5);
    for (p = 1; p < pieces.length; p++) {
      P = pieces[p];
      if (!P.primary) continue;
      for (k = P.start; k < P.end; k++) {
        if (!loc[order[k]]) continue;
        o = offset(order[k]);
        if (redness(o) < eMid) continue;
        hr[D[o]]++; hg[D[o + 1]]++; hb[D[o + 2]]++; sel++;
      }
    }
    var S = [histQuantile(hr, sel, 0.5), histQuantile(hg, sel, 0.5), histQuantile(hb, sel, 0.5)];
    var pen = { color: S, y: 0.299 * S[0] + 0.587 * S[1] + 0.114 * S[2], tol: 0, yLo: 0, yHi: 0, width: 4,
      hue: (S[1] - S[2]) / max(1, S[0] - min(S[1], S[2])), hueTol: 0 };
    for (p = 1; p < pieces.length; p++) {
      P = pieces[p];
      if (!P.primary) continue;
      for (k = P.start; k < P.end; k++) {
        if (!loc[order[k]]) continue;
        o = offset(order[k]);
        if (redness(o) < eMid) continue;
        hd[max(abs(D[o] - S[0]), abs(D[o + 1] - S[1]), abs(D[o + 2] - S[2]))]++;
        hh[min(255, round(255 * abs(hueOf(D, o) - pen.hue)))]++;
        hy[max(0, min(255, round(0.299 * D[o] + 0.587 * D[o + 1] + 0.114 * D[o + 2] - pen.y) + 128))]++;
      }
    }
    pen.tol = min(64, max(22, round(histQuantile(hd, sel, 0.9) * 1.25) + 14));
    pen.yLo = max(-pen.tol, min(-16, round((histQuantile(hy, sel, 0.05) - 128) * 1.25) - 10));
    pen.yHi = min(pen.tol, max(16, round((histQuantile(hy, sel, 0.95) - 128) * 1.25) + 10));
    pen.hueTol = min(0.4, max(0.12, histQuantile(hh, sel, 0.9) / 255 * 1.25 + 0.05));
    var sumA = 0, sumT = 0;
    for (p = 1; p < pieces.length; p++) {
      P = pieces[p];
      if (!P.ok) continue;
      for (k = P.start; k < P.end; k++) {
        i = order[k];
        if (loc[i] && nearPen(D, offset(i), pen, false)) P.penPx++;
      }
      P.pen = P.penPx >= max(3, 0.1 * P.area);
      if (P.primary) { sumA += P.area; sumT += P.area * P.t; }
    }
    if (sumA) pen.width = sumT / sumA;
    return pen;
  }

  /**
   * Whether the pixel at byte offset o has the pen's colour: every channel
   * and the luma within the pen tolerances. `loose` doubles them, for the
   * pen washed out by a neutral background (downscaled thin lines): that
   * keeps the pen's hue, so the hue must then match too, which keeps out
   * skin and orange pixels next to the stroke. (A hue test on every pixel
   * would rather hurt: it breaks JPEG-noisy pen-coloured photo regions into
   * speckle that looks thin.)
   */
  function nearPen(D, o, pen, loose) {
    var t = pen.tol, lo = pen.yLo, hi = pen.yHi;
    if (loose) { t = min(80, 2 * t + 10); lo = max(-80, 2 * lo - 10); hi = min(80, 2 * hi + 10); }
    var r = D[o], g = D[o + 1], b = D[o + 2], S = pen.color;
    if (r - S[0] > t || S[0] - r > t || g - S[1] > t || S[1] - g > t || b - S[2] > t || S[2] - b > t) return false;
    var dy = 0.299 * r + 0.587 * g + 0.114 * b - pen.y;
    if (dy < lo || dy > hi) return false;
    return !loose || abs(hueOf(D, o) - pen.hue) <= pen.hueTol;
  }

  /** Hue of a reddish pixel as (G - B) / chroma: 0 pure red, toward +1 orange, toward -1 magenta. */
  function hueOf(D, o) {
    var r = D[o], g = D[o + 1], b = D[o + 2], c = r - (g < b ? g : b);
    return c > 0 ? (g - b) / c : 1;
  }

  /**
   * Full stroke: pixels of the pen colour (nearPen; 3x3-closed against JPEG
   * speckle) that are thin (run-length thickness <= maxT) and 8-connected to
   * the seeds. Where the stroke folds or crosses
   * itself it is locally thick; such thick pieces are taken when small, while
   * large thick regions of the pen colour are photo content and stay out.
   * Where such a region cuts the stroke, the part beyond it is picked up as a
   * piece of its own (long, or a fragment near the traced stroke).
   * `buf` holds w*h scratch arrays (hrun, vrun, thin, lab) that are
   * overwritten. Returns { list, count }: the stroke's window pixels.
   */
  function traceStroke(D, win, cand, pieces, order, model, maxT, lim, buf) {
    var w = win.w, h = win.h, n = win.n, W = win.W, X0 = win.X0, Y0 = win.Y0;
    var x, y, i, k, o, p, P;
    var C = new U8(n);
    for (y = 0; y < h; y++) {
      var gi = (Y0 + y) * W + X0;
      for (x = 0, i = y * w; x < w; x++, i++, gi++) {
        if (!cand[gi]) continue;
        o = gi << 2;
        if (nearPen(D, o, model, false)) C[i] = 1;
      }
    }
    var Cc = close3(C, w, h);
    var hrun = buf.hrun, vrun = buf.vrun, thin = buf.thin, lab = buf.lab;
    thin.fill(0);
    var nC = thinPixels(Cc, w, h, maxT, hrun, vrun, thin).set;

    // folds and crossings of the pen are a few pen widths across
    var pw = ceil(model.width) + 2, maxBlob = 6 * pw * pw;
    var body = new U8(n), seen = new U8(n), members = new I32(maxBlob);
    var nSeedPx = 0;
    for (p = 1; p < pieces.length; p++) if (pieces[p].pen) nSeedPx += pieces[p].area;
    // the body is pen-coloured seed pixels and pixels of Cc
    var list = new I32(nSeedPx + nC), cnt = 0;
    // Pen-coloured seed pieces are stroke by shape, also where downscaling
    // washed their pixels out of the colour tolerance (a thin line mixed with
    // the background) - but not the natural red pixels a closed piece picked
    // up where the stroke touches red content, which are far off the pen.
    for (p = 1; p < pieces.length; p++) {
      P = pieces[p];
      if (!P.pen) continue;
      for (k = P.start; k < P.end; k++) {
        i = order[k]; x = i % w;
        o = ((Y0 + (i - x) / w) * W + X0 + x) << 2;
        if (!nearPen(D, o, model, true)) continue;
        body[i] = 1; list[cnt++] = i;
      }
    }
    var grow = { list: list, count: cnt };
    floodStroke(body, grow, 0, Cc, thin, seen, members, maxBlob, w, h);

    // pen-coloured pieces the flood did not reach
    var rest = new U8(n), nRest = 0;
    for (i = 0; i < n; i++) if (thin[i] && !body[i]) { rest[i] = 1; nRest++; }
    if (nRest) {
      lab.fill(0);
      var rorder = new I32(nRest);
      var rp = labelPieces(rest, Cc, w, h, hrun, vrun, lab, rorder);
      var from = grow.count;
      // as wide as the pen: a JPEG-speckled patch of a pen-coloured photo
      // region also breaks into thin-looking pieces, but wider ones
      var maxPieceT = 1.5 * model.width + 1;
      for (p = 1; p < rp.length; p++) {
        P = rp[p];
        if (P.t > maxPieceT) P.tried = true;
        else if (isLongStroke(P, lim)) P.ok = true;
      }
      acceptNear(rp, rorder, list, from, w, h, lim);
      for (p = 1; p < rp.length; p++) {
        P = rp[p];
        if (!P.ok) continue;
        for (k = P.start; k < P.end; k++) { body[rorder[k]] = 1; grow.list[grow.count++] = rorder[k]; }
      }
      if (grow.count > from) floodStroke(body, grow, from, Cc, thin, seen, members, maxBlob, w, h);
    }
    return { list: grow.list, count: grow.count };
  }

  /**
   * Grows `body` breadth-first from grow.list[from ..] over 8-connected thin
   * pixels of `solid`, and over thick pieces of it of at most maxBlob pixels
   * (each thick piece is measured once; `seen` marks them). New pixels are
   * appended to grow.list.
   */
  function floodStroke(body, grow, from, solid, thin, seen, members, maxBlob, w, h) {
    var list = grow.list, tail = grow.count, tstack = [];
    for (var rd = from; rd < tail; rd++) {
      var j = list[rd], jx = j % w, jy = (j - jx) / w;
      for (var dy = -1; dy <= 1; dy++) {
        var yy = jy + dy;
        if (yy < 0 || yy >= h) continue;
        for (var dx = -1; dx <= 1; dx++) {
          var xx = jx + dx;
          if (xx < 0 || xx >= w) continue;
          var q = yy * w + xx;
          if (body[q] || !solid[q]) continue;
          if (thin[q]) { body[q] = 1; list[tail++] = q; continue; }
          if (seen[q]) continue;
          // a thick piece touching the stroke: measure it once
          var cnt = 0;
          tstack.length = 0; tstack.push(q); seen[q] = 1;
          while (tstack.length) {
            var t = tstack.pop(), tx = t % w, ty = (t - tx) / w;
            if (cnt < maxBlob) members[cnt] = t;
            cnt++;
            for (var ey = -1; ey <= 1; ey++) {
              var uy = ty + ey;
              if (uy < 0 || uy >= h) continue;
              for (var ex = -1; ex <= 1; ex++) {
                var ux = tx + ex;
                if (ux < 0 || ux >= w) continue;
                var u = uy * w + ux;
                if (solid[u] && !thin[u] && !seen[u]) { seen[u] = 1; tstack.push(u); }
              }
            }
          }
          if (cnt <= maxBlob) for (var k = 0; k < cnt; k++) { body[members[k]] = 1; list[tail++] = members[k]; }
        }
      }
    }
    grow.count = tail;
  }

  /**
   * Pixels near a stroke: inside the stroke mask the true colour is unknown.
   * In the surrounding halo a pixel is background tinted by the stroke when
   * it is either a mix of the two (anti-aliasing, downscaling: on the RGB
   * segment between them) or JPEG chroma bleed (background luma, chroma
   * pulled toward the stroke's - JPEG keeps luma sharp but smears colour).
   * Returns -1 unknown, 0 tinted background, 1 use the pixel as is.
   */
  function makeStrokeModel(marks, bg) {
    if (!marks.baked) return null;
    var mask = marks.mask, avoid = marks.avoid, sc = marks.color;
    var v0 = sc[0] - bg[0], v1 = sc[1] - bg[1], v2 = sc[2] - bg[2];
    var vv = v0 * v0 + v1 * v1 + v2 * v2 || 1;
    // stroke chroma relative to the background, on unscaled (B - Y, R - Y) axes
    var sY = 0.299 * sc[0] + 0.587 * sc[1] + 0.114 * sc[2], bY = 0.299 * bg[0] + 0.587 * bg[1] + 0.114 * bg[2];
    var u0 = (sc[2] - sY) - (bg[2] - bY), u1 = (sc[0] - sY) - (bg[0] - bY);
    var uu = u0 * u0 + u1 * u1 || 1;
    return function (D, i) {
      if (!avoid[i]) return 1;
      if (mask[i]) return -1;
      var o = i << 2, p0 = D[o] - bg[0], p1 = D[o + 1] - bg[1], p2 = D[o + 2] - bg[2];
      var t = (p0 * v0 + p1 * v1 + p2 * v2) / vv;
      t = t < 0 ? 0 : t > 1 ? 1 : t;
      var e0 = p0 - t * v0, e1 = p1 - t * v1, e2 = p2 - t * v2;
      if (e0 * e0 + e1 * e1 + e2 * e2 <= 196) return 0;
      var dY = 0.299 * p0 + 0.587 * p1 + 0.114 * p2;
      if (dY > 12 || dY < -12) return 1;
      var c0 = p2 - dY, c1 = p0 - dY, s = (c0 * u0 + c1 * u1) / uu;
      s = s < 0 ? 0 : s > 1 ? 1 : s;
      var f0 = c0 - s * u0, f1 = c1 - s * u1;
      return f0 * f0 + f1 * f1 <= 100 ? 0 : 1;
    };
  }

  /* ------------------------------------------------------------ 2. background */

  /**
   * Candidate background colours: the strongest peaks of a histogram of
   * sampled pixels that equal their right and lower neighbours (within JPEG
   * noise), quantised to 4 levels per step - at most six, distinct, each
   * holding at least 0.5% of the samples (a meme's caption band is small
   * next to the flat areas of its photo). For each: how much of the
   * best-covered image side is that colour (margin - posts have background
   * margins, photographs rarely do) and, for colours with a margin, how much
   * of the image is that colour (share) and how much of that area is
   * noise-free (flat - a screenshot's background is, a sky or a wall is not
   * quite).
   */
  function findBackground(W, H, D, avoid) {
    var hist = new U32(1 << 18);
    var step = max(1, round(sqrt(W * H / 250000)));
    var samples = 0, x, y, i, o, k, j;
    for (y = 0; y < H - 1; y += step) {
      for (x = 0; x < W - 1; x += step) {
        i = y * W + x;
        samples++;
        if (avoid && avoid[i]) continue;
        o = i << 2;
        var oR = o + 4, oD = o + (W << 2);
        if (abs(D[o] - D[oR]) > 3 || abs(D[o + 1] - D[oR + 1]) > 3 || abs(D[o + 2] - D[oR + 2]) > 3) continue;
        if (abs(D[o] - D[oD]) > 3 || abs(D[o + 1] - D[oD + 1]) > 3 || abs(D[o + 2] - D[oD + 2]) > 3) continue;
        hist[((D[o] >> 2) << 12) | ((D[o + 1] >> 2) << 6) | (D[o + 2] >> 2)]++;
      }
    }
    // peaks, each suppressing its neighbourhood (+-2 steps per channel),
    // picked from the well-filled bins - and the fullest bin always
    var occ = [], minPeak = samples * 0.005, top = 0;
    for (k = 0; k < hist.length; k++) {
      if (hist[k] > hist[top]) top = k;
      if (hist[k] >= minPeak) occ.push(k);
    }
    if (!occ.length && hist[top]) occ.push(top);
    var bins = [], peakOf = new Int8Array(1 << 18);
    while (bins.length < 6) {
      var best = 0, bi = -1;
      for (k = 0; k < occ.length; k++) if (hist[occ[k]] > best) { best = hist[occ[k]]; bi = occ[k]; }
      if (bi < 0) break;
      bins.push(bi);
      peakOf[bi] = bins.length;
      var qr = bi >> 12, qg = (bi >> 6) & 63, qb = bi & 63;
      for (var dr = -2; dr <= 2; dr++) for (var dg = -2; dg <= 2; dg++) for (var db = -2; db <= 2; db++) {
        var r2 = qr + dr, g2 = qg + dg, b2 = qb + db;
        if (r2 >= 0 && r2 < 64 && g2 >= 0 && g2 < 64 && b2 >= 0 && b2 < 64) hist[(r2 << 12) | (g2 << 6) | b2] = 0;
      }
    }
    // mean colour of each peak's own bin
    var n = bins.length, sum = new F64(n * 3), cnt = new F64(n);
    for (y = 0; y < H - 1; y += step) {
      for (x = 0; x < W - 1; x += step) {
        o = (y * W + x) << 2;
        j = peakOf[((D[o] >> 2) << 12) | ((D[o + 1] >> 2) << 6) | (D[o + 2] >> 2)] - 1;
        if (j >= 0) { sum[3 * j] += D[o]; sum[3 * j + 1] += D[o + 1]; sum[3 * j + 2] += D[o + 2]; cnt[j]++; }
      }
    }
    var out = [];
    for (j = 0; j < n; j++) out.push({ color: cnt[j] ? [sum[3 * j] / cnt[j], sum[3 * j + 1] / cnt[j], sum[3 * j + 2] / cnt[j]] : [255, 255, 255], share: 0, margin: 0, flat: 0 });
    if (!n) out.push({ color: [255, 255, 255], share: 0, margin: 0, flat: 0 });
    // background coverage of the outer 3 pixels of each side
    for (j = 0; j < out.length; j++) {
      var bg = out[j].color, sides = [0, 0, 0, 0];
      for (var t = 0; t < 3; t++) {
        for (x = 0; x < W; x++) {
          if (maxChanDiff(D, (t * W + x) << 2, bg) <= 10) sides[0]++;
          if (maxChanDiff(D, ((H - 1 - t) * W + x) << 2, bg) <= 10) sides[1]++;
        }
        for (y = 0; y < H; y++) {
          if (maxChanDiff(D, (y * W + t) << 2, bg) <= 10) sides[2]++;
          if (maxChanDiff(D, (y * W + W - 1 - t) << 2, bg) <= 10) sides[3]++;
        }
      }
      out[j].margin = max(sides[0] / (3 * W), sides[1] / (3 * W), sides[2] / (3 * H), sides[3] / (3 * H));
    }
    var sel = out.filter(function (b) { return b.margin >= 0.8; }), m = sel.length;
    if (!m) return out;
    var close = new F64(m), exact = new F64(m);
    for (y = 0; y < H - 1; y += step) {
      for (x = 0; x < W - 1; x += step) {
        o = (y * W + x) << 2;
        for (j = 0; j < m; j++) {
          var d = maxChanDiff(D, o, sel[j].color);
          if (d <= 6) { close[j]++; if (d <= 2) exact[j]++; }
        }
      }
    }
    for (j = 0; j < m; j++) {
      sel[j].share = close[j] / max(1, samples);
      sel[j].flat = close[j] ? exact[j] / close[j] : 0;
    }
    return out;
  }

  /**
   * Colours posts are laid out on: near-white and near-black neutrals, and
   * the dark blue-greys of dim themes.
   */
  function typicalBackground(c) {
    var hi = max(c[0], c[1], c[2]), lo = min(c[0], c[1], c[2]);
    return (hi - lo <= 12 && (lo >= 225 || hi <= 50)) || (hi <= 60 && hi - lo <= 25 && c[2] >= c[0]);
  }

  /* ------------------------------------------------------------ 3. grid */

  /**
   * Per-cell statistics over pixels not covered by red marks: pixel count,
   * colour sums and the number of pixels at background colour.
   */
  function buildGrid(W, H, D, bg, avoid, stroke, c) {
    var gw = ceil(W / c), gh = ceil(H / c), G = gw * gh;
    var n = new I32(G), sr = new F64(G), sg = new F64(G), sb = new F64(G), nbg = new I32(G), nhalo = new I32(G);
    var cxOf = new I32(W), x, y;
    for (x = 0; x < W; x++) cxOf[x] = (x / c) | 0;
    var br = bg[0], bgg = bg[1], bb = bg[2];
    for (y = 0; y < H; y++) {
      var base = ((y / c) | 0) * gw, row = y * W;
      for (x = 0; x < W; x++) {
        var i = row + x, o = i << 2, R = D[o], Gc = D[o + 1], B = D[o + 2];
        var k = base + cxOf[x];
        if (avoid && avoid[i]) {
          var sv = stroke(D, i);
          if (sv < 0) continue;
          if (sv === 0) { R = br; Gc = bgg; B = bb; }
          nhalo[k]++;
        }
        n[k]++; sr[k] += R; sg[k] += Gc; sb[k] += B;
        var dr = R - br, dg = Gc - bgg, db = B - bb;
        if (dr <= 8 && dr >= -8 && dg <= 8 && dg >= -8 && db <= 8 && db >= -8) nbg[k]++;
      }
    }
    var dMean = new F32(G);
    for (var j = 0; j < G; j++) {
      var m = n[j];
      if (!m) { dMean[j] = -1; continue; }
      dMean[j] = max(abs(sr[j] / m - br), abs(sg[j] / m - bgg), abs(sb[j] / m - bb));
    }
    return { gw: gw, gh: gh, c: c, n: n, nbg: nbg, nhalo: nhalo, dMean: dMean };
  }

  /** Content / background decision per cell; cells hidden by marks are inferred. */
  function contentMask(grid) {
    var gw = grid.gw, gh = grid.gh, G = gw * gh;
    var M = new U8(G), unknown = new U8(G), anyUnknown = false;
    var minN = grid.c * grid.c * 0.25;
    for (var j = 0; j < G; j++) {
      if (grid.n[j] < minN) { unknown[j] = 1; anyUnknown = true; continue; }
      // around strokes JPEG ringing survives the halo model: ask for more
      var thr = grid.nhalo[j] > grid.n[j] * 0.3 ? 3 * CELL_CONTENT : CELL_CONTENT;
      if (grid.dMean[j] > thr) M[j] = 1;
    }
    if (!anyUnknown) return M;
    // a hidden cell is content when content lies on both sides of it
    var R = 3, out = new U8(M);
    for (var y = 0; y < gh; y++) for (var x = 0; x < gw; x++) {
      var k = y * gw + x;
      if (!unknown[k]) continue;
      var l = 0, r = 0, u = 0, d = 0, s;
      for (s = 1; s <= R && x - s >= 0; s++) if (!unknown[k - s]) { l = M[k - s]; break; }
      for (s = 1; s <= R && x + s < gw; s++) if (!unknown[k + s]) { r = M[k + s]; break; }
      for (s = 1; s <= R && y - s >= 0; s++) if (!unknown[k - s * gw]) { u = M[k - s * gw]; break; }
      for (s = 1; s <= R && y + s < gh; s++) if (!unknown[k + s * gw]) { d = M[k + s * gw]; break; }
      out[k] = (l && r) || (u && d) ? 1 : 0;
    }
    return out;
  }

  /* ------------------------------------------------------------ 4. XY-cut */

  /**
   * Recursive XY-cut on the content grid with an explicit stack. A row or
   * column is a gutter when it holds (almost) no content; the small tolerance
   * lets cuts pass thin frame lines such as a quoted-post outline. Blocks are
   * trimmed with the same tolerance. Returns leaf blocks in cell units.
   */
  function xyCut(M, gw, gh, minLeaf) {
    var rowPS = new I32(gh * (gw + 1)), colPS = new I32(gw * (gh + 1)), x, y;
    for (y = 0; y < gh; y++) {
      var b = y * (gw + 1), acc = 0;
      for (x = 0; x < gw; x++) { acc += M[y * gw + x]; rowPS[b + x + 1] = acc; }
    }
    for (x = 0; x < gw; x++) {
      var b2 = x * (gh + 1), acc2 = 0;
      for (y = 0; y < gh; y++) { acc2 += M[y * gw + x]; colPS[b2 + y + 1] = acc2; }
    }
    function rowCount(yy, x0, x1) { var o = yy * (gw + 1); return rowPS[o + x1] - rowPS[o + x0]; }
    function colCount(xx, y0, y1) { var o = xx * (gh + 1); return colPS[o + y1] - colPS[o + y0]; }
    function tolFor(len) { return len >= 40 ? floor(len * 0.02) : 0; }

    var leaves = [], stack = [[0, 0, gw, gh]], guard = 0;
    while (stack.length && guard++ < 100000) {
      var blk = stack.pop();
      var x0 = blk[0], y0 = blk[1], x1 = blk[2], y1 = blk[3];
      var tr = tolFor(x1 - x0), tc = tolFor(y1 - y0);
      while (y0 < y1 && rowCount(y0, x0, x1) <= tr) y0++;
      while (y1 > y0 && rowCount(y1 - 1, x0, x1) <= tr) y1--;
      while (x0 < x1 && colCount(x0, y0, y1) <= tc) x0++;
      while (x1 > x0 && colCount(x1 - 1, y0, y1) <= tc) x1--;
      if (x1 <= x0 || y1 <= y0) continue;
      var bw = x1 - x0, bh = y1 - y0;
      if (bw < minLeaf || bh < minLeaf) { leaves.push({ x0: x0, y0: y0, x1: x1, y1: y1, small: true }); continue; }
      tr = tolFor(bw);
      var segs = splitProfile(function (t) { return rowCount(t, x0, x1); }, y0, y1, tr);
      if (segs.length > 1) {
        for (var s = 0; s < segs.length; s++) stack.push([x0, segs[s][0], x1, segs[s][1]]);
        continue;
      }
      tc = tolFor(bh);
      segs = splitProfile(function (t) { return colCount(t, y0, y1); }, x0, x1, tc);
      if (segs.length > 1) {
        for (var s2 = 0; s2 < segs.length; s2++) stack.push([segs[s2][0], y0, segs[s2][1], y1]);
        continue;
      }
      leaves.push({ x0: x0, y0: y0, x1: x1, y1: y1, small: false });
    }
    return leaves;
  }

  /**
   * Splits [a,b) into runs separated by gutters. A line is a gutter when its
   * content count is at most `tol`, or when it is a deep valley: under 12% of
   * the fullest lines on both sides nearby (stray stroke fragments or noise
   * in the gap between a caption and a photo).
   */
  function splitProfile(count, a, b, tol) {
    var n = b - a, cnt = new I32(n), t;
    for (t = 0; t < n; t++) cnt[t] = count(a + t);
    var K = max(3, round(n * 0.03)), prevMax = new I32(n), nextMax = new I32(n);
    for (t = 0; t < n; t++) {
      var pm = 0;
      for (var u = max(0, t - K); u < t; u++) if (cnt[u] > pm) pm = cnt[u];
      prevMax[t] = pm;
      var nm = 0;
      for (var v = t + 1; v <= min(n - 1, t + K); v++) if (cnt[v] > nm) nm = cnt[v];
      nextMax[t] = nm;
    }
    var segs = [], start = -1;
    for (t = 0; t < n; t++) {
      var c = cnt[t];
      var g = c <= tol || (c <= 0.12 * min(prevMax[t], nextMax[t]) && c * 8 < n);
      if (!g && start < 0) start = t;
      if (g && start >= 0) { segs.push([a + start, a + t]); start = -1; }
    }
    if (start >= 0) segs.push([a + start, b]);
    return segs;
  }

  /* ------------------------------------------------------------ 5. classify */

  /**
   * Density / rectangularity of a block, its share of background pixels,
   * and whether its outermost cell rows and columns are all content (an
   * outline drawn around it).
   */
  function blockStats(M, grid, b) {
    var gw = grid.gw, bw = b.x1 - b.x0, bh = b.y1 - b.y0, x, y;
    var on = 0, fullRows = 0, fullCols = 0, px = 0, bgp = 0, rimT = 0, rimB = 0;
    var colOn = new I32(bw);
    for (y = b.y0; y < b.y1; y++) {
      var r = 0;
      for (x = b.x0; x < b.x1; x++) {
        var k = y * gw + x;
        px += grid.n[k]; bgp += grid.nbg[k];
        if (M[k]) { r++; colOn[x - b.x0]++; }
      }
      on += r;
      if (r >= bw * 0.6) fullRows++;
      if (y === b.y0) rimT = r / bw;
      if (y === b.y1 - 1) rimB = r / bw;
    }
    for (x = 0; x < bw; x++) if (colOn[x] >= bh * 0.6) fullCols++;
    var rimL = 0, rimR = 0;
    for (y = b.y0; y < b.y1; y++) { rimL += M[y * gw + b.x0]; rimR += M[y * gw + b.x1 - 1]; }
    var rim = min(rimT, rimB, rimL / bh, rimR / bh);
    return { fill: on / (bw * bh), rows: fullRows / bh, cols: fullCols / bw, bgFrac: px ? bgp / px : 1, outlined: rim >= 0.9 };
  }

  /**
   * Photos are dense rectangles. A dark photo on a dark background is not
   * dense, but a media outline drawn around it still marks it as one.
   */
  function isPhotoBlock(st) {
    if (st.fill >= 0.72 && st.rows >= 0.7 && st.cols >= 0.7 && st.bgFrac <= 0.5) return true;
    return st.outlined && st.fill >= 0.5 && st.bgFrac <= 0.5;
  }

  /**
   * A block of one flat colour (a bar, a blank video frame): nearly all its
   * inner cells (the rim straddles the block's edge) sit at the same
   * distance from the background. Photos have texture; there is nothing in
   * such a block to crop.
   */
  function flatBlock(grid, M, b) {
    var gw = grid.gw, hist = new I32(512), n = 0, x, y, k;
    for (y = b.y0 + 1; y < b.y1 - 1; y++) for (x = b.x0 + 1; x < b.x1 - 1; x++) {
      k = y * gw + x;
      if (M[k] && grid.dMean[k] >= 0) { hist[min(511, round(grid.dMean[k] * 2))]++; n++; }
    }
    if (!n) return false;
    var best = 0;
    for (k = 0; k < 512; k++) {
      var w = 0;
      for (var j = max(0, k - 8); j <= min(511, k + 8); j++) w += hist[j];
      if (w > best) best = w;
    }
    return best >= 0.97 * n;
  }

  /* ------------------------------------------------------------ 6. group */

  function adjacent(A, B, gap) {
    var hx = max(A.x0, B.x0) - min(A.x1, B.x1); // horizontal gap (negative = overlap)
    var vy = max(A.y0, B.y0) - min(A.y1, B.y1);
    var minW = min(A.x1 - A.x0, B.x1 - B.x0), minH = min(A.y1 - A.y0, B.y1 - B.y0);
    if (hx <= gap && -vy >= 0.5 * minH) return true; // side by side
    if (vy <= gap && -hx >= 0.5 * minW) return true; // stacked
    return false;
  }

  function groupBlocks(blocks, gap) {
    var groups = blocks.map(function (p) { return { x0: p.x0, y0: p.y0, x1: p.x1, y1: p.y1, members: [p] }; });
    var merged = true;
    while (merged) {
      merged = false;
      for (var a = 0; a < groups.length && !merged; a++) {
        for (var q = a + 1; q < groups.length && !merged; q++) {
          if (!adjacent(groups[a], groups[q], gap)) continue;
          var A = groups[a], B = groups[q];
          A.x0 = min(A.x0, B.x0); A.y0 = min(A.y0, B.y0);
          A.x1 = max(A.x1, B.x1); A.y1 = max(A.y1, B.y1);
          A.members = A.members.concat(B.members);
          groups.splice(q, 1);
          merged = true;
        }
      }
    }
    return groups;
  }

  /* ------------------------------------------------------------ 7. refine */

  /**
   * Pixel classifier for the edge search: 1 content, 0 background, -1 under
   * a stroke, -2 hidden (off the background, but explainable as stroke tint
   * in the stroke's halo - background or a photo edge under the smear).
   */
  function makePixelTest(D, bg, avoid, stroke, thr) {
    var b0 = bg[0], b1 = bg[1], b2 = bg[2];
    return function (i) {
      var o = i << 2, d = abs(D[o] - b0), d1 = abs(D[o + 1] - b1), d2 = abs(D[o + 2] - b2);
      if (d1 > d) d = d1;
      if (d2 > d) d = d2;
      if (avoid && avoid[i]) {
        var sv = stroke(D, i);
        if (sv < 0) return -1;
        if (sv === 0) return d > thr ? -2 : 0;
      }
      return d > thr ? 1 : 0;
    };
  }

  /**
   * Re-locates the four edges of a coarse box at full resolution (two passes,
   * the second with the span from the first). Returns the box and, per side,
   * how consistently the sampled lines agree on the edge (1 = a straight cut).
   */
  function refineBox(W, H, test, box, c, bg, D) {
    var e = [box.x, box.y, box.x + box.w, box.y + box.h], cons = [0, 0, 0, 0];
    var m = 2 * c + 4;
    for (var pass = 0; pass < 2; pass++) {
      var l = refineEdge(W, H, test, e, 0, m, D, bg), t = refineEdge(W, H, test, e, 1, m, D, bg);
      var r = refineEdge(W, H, test, e, 2, m, D, bg), b = refineEdge(W, H, test, e, 3, m, D, bg);
      if (r.pos - l.pos >= 4 && b.pos - t.pos >= 4) e = [l.pos, t.pos, r.pos, b.pos];
      cons = [l.cons, t.cons, r.cons, b.cons];
      m = max(4, c + 2);
    }
    return { box: rect(e[0], e[1], e[2] - e[0], e[3] - e[1]), cons: cons };
  }

  /**
   * side 0..3 = left, top, right, bottom of edges e = [x0, y0, x1, y1]
   * (x1/y1 exclusive). Each sampled line across the edge is scanned from the
   * outside inward for the first two consecutive content pixels ("the
   * departure"; stroke pixels are skipped). A line is clean when nothing a
   * stroke may hide lies before its departure, otherwise ambiguous: the edge
   * is somewhere under the stroke. If the scan start is itself inside
   * content, the window grows.
   */
  function refineEdge(W, H, test, e, side, m, D, bg) {
    var alongX = side === 1 || side === 3;           // lines run along x (top/bottom edge)
    var a0 = alongX ? e[0] : e[1], a1 = alongX ? e[2] : e[3];
    // Lines cover all but the ends (rounded corners, a pixel of box error):
    // a stroke running along the edge leaves few clean lines, so the ends
    // matter.
    var len = a1 - a0, s0 = a0 + floor(len * 0.08), s1 = a1 - floor(len * 0.08);
    if (s1 <= s0) { s0 = a0; s1 = a1; }
    var nLines = min(120, s1 - s0), lim = alongX ? H : W;
    var edge = e[side], dir = side < 2 ? 1 : -1;     // inward direction
    var first = side < 2 ? edge : edge - 1;          // first pixel inside the coarse box
    function px(line, p) { return alongX ? test(p * W + line) : test(line * W + p); }
    function lineAt(k) { return s0 + floor((k + 0.5) * (s1 - s0) / nLines); }

    // grow the outward reach while the outer end of the window is still
    // content (stroke tint is not)
    var reach = m, outer;
    for (var tries = 0; tries < 6; tries++) {
      outer = first - dir * reach;
      if (outer < 0) { outer = 0; break; }
      if (outer > lim - 1) { outer = lim - 1; break; }
      var on = 0, tot = 0;
      for (var k = 0; k < nLines; k++) { var v = px(lineAt(k), outer); if (v !== -1) { tot++; if (v === 1) on++; } }
      if (!tot || on / tot < 0.4) break;
      reach *= 2;
    }
    // inward the scan may go deep: a coarse box that swallowed a stroke or a
    // stray mark at its border has its real edge well inside
    var extent = alongX ? e[3] - e[1] : e[2] - e[0];
    var inner = first + dir * max(m, floor(extent * 0.3));
    inner = max(0, min(lim - 1, inner));
    var span = abs(inner - outer) + 1;
    var atBorder = outer === 0 || outer === lim - 1;
    var clean = [], amb = [], thin = [], past = [], hits = new I32(span + 1);
    // One scan of a line from offset t0: the departure, whether anything a
    // stroke may hide came before it, and the departure's best edge
    // estimate. The edge lies under the last hidden stretch before the
    // departure. None (background between a stroke and the departure: a
    // loop drawn just outside the photo): the departure is the edge - or a
    // dark photo's interior, which is why such lines stay ambiguous. A pixel
    // or two of tint: the photo's own tinted rim. A long stretch: its middle.
    // A lone content pixel right before a stroke is the stroke's own fringe
    // as often as the photo: a departure confirmed only across the stroke is
    // ambiguous too, its estimate the middle of the stroke.
    var sc = { found: -1, hidden: -1, sawBg: false, firstHit: -1, est: -1 };
    function depart(line, t0) {
      var hidden = -1, sawBg = false, hs = -1, cand = -1, candHidden = -1, candBg = false, candHs = -1;
      var across = false, t;
      sc.found = -1; sc.firstHit = -1;
      for (t = t0; t < span; t++) {
        var v = px(line, outer + dir * t);
        if (v < 0) { if (hidden < 0) hidden = t; if (hs < 0) hs = t; if (cand >= 0) across = true; continue; }
        if (v === 1) {
          if (sc.firstHit < 0) sc.firstHit = t;
          if (cand >= 0) { sc.found = cand; break; }
          cand = t; candHidden = hidden; candBg = sawBg; candHs = hs;
        } else { cand = -1; sawBg = true; hs = -1; across = false; }
      }
      var f = sc.found;
      sc.sawBg = candBg;
      if (f >= 0 && across) { sc.hidden = f; sc.est = (f + t) >> 1; return f; }
      sc.hidden = candHidden;
      sc.est = f < 0 ? -1 : candHidden < 0 || candHs < 0 ? f : f - candHs <= 2 ? candHs : (candHs + f) >> 1;
      return f;
    }
    for (k = 0; k < nLines; k++) {
      var line = lineAt(k), found = depart(line, 0);
      if (sc.firstHit >= 0) hits[sc.firstHit]++;
      if (found < 0) continue;
      if (sc.hidden < 0) {
        // A thin line - at most 3 content pixels, then background again -
        // may be a frame around the photo: note where the line is and
        // where the scan, continued past it, departs next.
        var run = 0, gap = 0, t;
        for (t = found; t < span && run <= 3 && px(line, outer + dir * t) === 1; t++) run++;
        for (; t < span && gap < 2 && px(line, outer + dir * t) === 0; t++) gap++;
        var isThin = run <= 3 && gap >= 2;
        clean.push(found);
        thin.push(isThin ? found : -1);
        past.push(isThin ? (depart(line, t) >= 0 ? sc.est : -1) : found);
      }
      else if (!sc.sawBg && atBorder) clean.push(0);   // hidden from the image border on
      else amb.push(sc.est);
    }
    // The edge is the outermost dense cluster of departures: lines where the
    // photo border contrasts with the background agree to the pixel, while
    // lines whose photo pixels match the background depart further in.
    // Departures near the coarse edge are trusted first (dark photos on dark
    // backgrounds have few contrasting lines) - unless most lines agree on a
    // crisp edge further in: then the near ones were a caption, a timestamp
    // or JPEG ringing the coarse box swallowed - or, when they are a thin
    // detached line, a frame around the photo (a quoted post's outline).
    // Only when nothing is near is the deep part of the scan used.
    // Ambiguous lines count only when clean ones are too few - or are the
    // minority (a stroke drawn along the edge): then a handful of clean
    // departures on stroke fragments must not outvote them.
    var pos = clean.concat(amb), nearLim = reach + m;
    var needNear = max(3, round(nLines * 0.05)), need = max(3, round(nLines * 0.12));
    var lead = clean.length >= amb.length ? clean : pos;
    var q = strongCluster(lead, needNear, nearLim), framed = false;
    if (q >= 0) {
      var nq = windowCount(lead, q), frame = windowCount(thin, q) >= 0.7 * nq;
      var deep = frame ? deepCluster(past, q + 3, span, round(nLines * 0.4)) : deepCluster(lead, q + 3, span, round(nLines * 0.55));
      if (deep >= 0 && (frame || windowCount(lead, deep) >= 2 * nq)) { q = deep; framed = frame; }
    }
    if (q < 0) q = strongCluster(pos, needNear, nearLim);
    if (q < 0) q = strongCluster(clean, need, span);
    if (q < 0) q = strongCluster(pos, need, span);
    if (q < 0) {
      if (pos.length < max(3, nLines * 0.2)) return { pos: edge, cons: 0 };
      pos.sort(function (a, b) { return a - b; });
      q = pos[floor(pos.length * 0.3)];
    }
    if (!framed) q = outlineSnap(W, D, bg, alongX, outer, dir, lineAt, nLines, hits, q);
    var agree = 0;
    for (k = 0; k < pos.length; k++) if (abs(pos[k] - q) <= 2) agree++;
    var p0 = outer + dir * q;
    return { pos: dir > 0 ? p0 : p0 + 1, cons: agree / nLines };
  }

  /** Departures within the 3-pixel window around offset q. */
  function windowCount(list, q) {
    var n = 0;
    for (var k = 0; k < list.length; k++) if (abs(list[k] - q) <= 1) n++;
    return n;
  }

  /** Most popular offset >= from whose 3-pixel window holds >= need departures, or -1. */
  function deepCluster(list, from, lim, need) {
    var hist = new I32(lim + 3), k, best = -1, bestN = 0;
    for (k = 0; k < list.length; k++) if (list[k] >= from && list[k] <= lim) hist[list[k]]++;
    for (k = from; k <= lim; k++) {
      var n = (k > 0 ? hist[k - 1] : 0) + hist[k] + hist[k + 1];
      if (n > bestN) { bestN = n; best = k; }
    }
    return bestN >= need ? best : -1;
  }

  /**
   * Media outline. Posts draw a 1px border around their media; on a dark
   * photo that border is the only visible edge and the departures start
   * inside the photo. A thin line that almost every line meets first, at
   * the same offset outside the found edge, with photo-like (not flat
   * background) pixels between it and the edge, is that border: the photo
   * starts right inside it. A frame around padding (a quoted post) has flat
   * background inside and is left alone.
   */
  function outlineSnap(W, D, bg, alongX, outer, dir, lineAt, nLines, hits, q) {
    if (q < 4) return q;
    var o = -1;
    for (var t = 0; t + 1 < q - 2; t++) if (hits[t] + hits[t + 1] >= 0.85 * nLines) { o = hits[t + 1] > hits[t] ? t + 1 : t; break; }
    if (o < 0) return q;
    // between the line and the edge: flat background or dark photo?
    var off = 0, n = 0;
    for (var k = 0; k < nLines; k += 2) {
      var line = lineAt(k);
      for (t = o + 2; t < q; t++) {
        var p = outer + dir * t, i = alongX ? p * W + line : line * W + p;
        if (maxChanDiff(D, i << 2, bg) > 2) off++;
        n++;
      }
    }
    return n && off >= 0.5 * n ? o + 1 : q;
  }

  /**
   * Departure clusters: offsets (from the outer end of a scan) where several
   * lines first meet content within a 3-pixel window. Returns the most popular
   * offset of the outermost window that holds at least `need` departures and
   * at least half as many as the strongest window, or -1. Only offsets <= lim
   * are considered.
   */
  function strongCluster(list, need, lim) {
    var hist = new I32(lim + 3), n = 0, k;
    for (k = 0; k < list.length; k++) if (list[k] <= lim) { hist[list[k]]++; n++; }
    if (n < need) return -1;
    var best = 0;
    for (k = 0; k <= lim; k++) best = max(best, hist[k] + hist[k + 1] + hist[k + 2]);
    if (best < need) return -1;
    var thr = max(need, best * 0.5);
    for (k = 0; k <= lim; k++) {
      if (hist[k] + hist[k + 1] + hist[k + 2] < thr) continue;
      var m = k;
      if (hist[k + 1] > hist[m]) m = k + 1;
      if (hist[k + 2] > hist[m]) m = k + 2;
      return m;
    }
    return -1;
  }

  /* ------------------------------------------------------------ 8. parts */

  /**
   * Splits a collage on thin uniform bands that run across the whole region
   * (dividers of background, white or black). Recurses with an explicit stack.
   */
  function splitParts(W, D, avoid, stroke, bg, box) {
    var parts = [], stack = [[box.x, box.y, box.x + box.w, box.y + box.h, 0]];
    var minPart = max(16, floor(min(box.w, box.h) * 0.12));
    while (stack.length) {
      var r = stack.pop();
      var cut = r[4] < 4 ? findDivider(W, D, avoid, stroke, bg, r[0], r[1], r[2], r[3], minPart) : null;
      if (!cut) { parts.push(rect(r[0], r[1], r[2] - r[0], r[3] - r[1])); continue; }
      if (cut.vertical) {
        stack.push([r[0], r[1], cut.a, r[3], r[4] + 1]);
        stack.push([cut.b, r[1], r[2], r[3], r[4] + 1]);
      } else {
        stack.push([r[0], r[1], r[2], cut.a, r[4] + 1]);
        stack.push([r[0], cut.b, r[2], r[3], r[4] + 1]);
      }
    }
    parts.sort(function (p, q) { return p.y - q.y || p.x - q.x; });
    return parts;
  }

  function findDivider(W, D, avoid, stroke, bg, x0, y0, x1, y1, minPart) {
    var v = bandSearch(W, D, avoid, stroke, bg, x0, y0, x1, y1, true, minPart);
    var h = bandSearch(W, D, avoid, stroke, bg, x0, y0, x1, y1, false, minPart);
    if (v && h) return v.score >= h.score ? v : h;
    if (v || h) return v || h;
    // Photos that touch, or whose thin divider a downscale blended away:
    // a straight seam across the whole region, splitting it into two
    // photo-sized parts.
    var R = rect(x0, y0, x1 - x0, y1 - y0), best = null;
    for (var o = 0; o < 2; o++) {
      var vert = o === 0, a = vert ? x0 : y0, L = vert ? x1 - x0 : y1 - y0;
      var sm = findSeam(W, D, avoid, R, vert, a + max(minPart, floor(L * 0.3)), a + L - max(minPart, floor(L * 0.3)), 0.85, 24);
      if (sm && (!best || sm.score > best.score)) best = { a: sm.a, b: sm.b, score: sm.score, vertical: vert };
    }
    return best;
  }

  /**
   * vertical=true looks for columns that are uniform over [y0,y1). A divider
   * is a narrow run of uniform lines of one colour whose neighbours on both
   * sides clearly differ from that colour (pixel-wise, so smooth photo areas
   * next to the band still count as different). Soft transition lines from
   * JPEG / resampling are given to the divider.
   */
  function bandSearch(W, D, avoid, stroke, bg, x0, y0, x1, y1, vertical, minPart) {
    // gaps between collage photos are the page background, white or black
    function dividerColour(c) {
      return maxChanDiff([c[0], c[1], c[2]], 0, bg) <= 14 || min(c[0], c[1], c[2]) >= 222 || max(c[0], c[1], c[2]) <= 32;
    }
    var L = vertical ? x1 - x0 : y1 - y0, A = vertical ? y1 - y0 : x1 - x0;
    if (L < 2 * minPart + 1 || A < 30) return null;
    // the outer 6% of each line is ignored: rounded corners and a pixel of
    // box error must not make a divider look non-uniform
    var stepA = max(1, floor(A / 300)), l, a;
    var aLo = floor(A * 0.06), aHi = A - aLo;
    // Collage photos are a quarter of the region or more; a uniform band
    // closer to the region's edge is a flat stripe inside a photo. Only the
    // lines that can hold a divider, or neighbour one, are profiled.
    var edgeMin = max(minPart, floor(L * 0.25)), lA = max(0, edgeMin - 3), lB = min(L, L - edgeMin + 3);
    var sR = new F64(L), sG = new F64(L), sB = new F64(L), sq = new F64(L), cnt = new F64(L);
    function sample(l, i) {
      var o = i << 2, R = D[o], G = D[o + 1], B = D[o + 2];
      if (avoid && avoid[i]) {
        // under a stroke: unknown, or background tinted by the stroke halo
        var sv = stroke(D, i);
        if (sv < 0) return;
        if (sv === 0) { R = bg[0]; G = bg[1]; B = bg[2]; }
      }
      var Y = (R + G + G + B) * 0.25;
      sR[l] += R; sG[l] += G; sB[l] += B; sq[l] += Y * Y; cnt[l]++;
    }
    // walk memory row by row in both orientations
    if (vertical) {
      for (a = aLo; a < aHi; a += stepA) for (l = lA; l < lB; l++) sample(l, (y0 + a) * W + x0 + l);
    } else {
      for (l = lA; l < lB; l++) for (a = aLo; a < aHi; a += stepA) sample(l, (y0 + l) * W + x0 + a);
    }
    var sd = new F32(L), mR = new F32(L), mG = new F32(L), mB = new F32(L);
    for (l = 0; l < L; l++) {
      var n = cnt[l];
      if (n < 4) { sd[l] = 99; continue; }
      mR[l] = sR[l] / n; mG[l] = sG[l] / n; mB[l] = sB[l] / n;
      var my = (mR[l] + 2 * mG[l] + mB[l]) * 0.25;
      sd[l] = sqrt(max(0, sq[l] / n - my * my));
    }
    function same(p, q) { return abs(mR[p] - mR[q]) <= 6 && abs(mG[p] - mG[q]) <= 6 && abs(mB[p] - mB[q]) <= 6; }
    // mean per-pixel distance of line q from colour col
    function contrast(q, col) {
      if (q < 0 || q >= L) return 0;
      var sum = 0, k = 0;
      for (var t = aLo; t < aHi; t += stepA) {
        var j = vertical ? (y0 + t) * W + x0 + q : (y0 + q) * W + x0 + t;
        if (avoid && avoid[j]) {
          var sv2 = stroke(D, j);
          if (sv2 < 0) continue;
          if (sv2 === 0) { sum += maxChanDiff(bg, 0, col); k++; continue; }
        }
        sum += maxChanDiff(D, j << 2, col); k++;
      }
      return k ? sum / k : 0;
    }
    var maxBand = max(4, round(L * 0.02)) + 2, best = null;
    var l0 = edgeMin;
    while (l0 < L - edgeMin) {
      if (sd[l0] > 5.5) { l0++; continue; }
      var l1 = l0 + 1;
      while (l1 < L - edgeMin && sd[l1] <= 5.5 && same(l1, l1 - 1)) l1++;
      var col = [0, 0, 0];
      for (l = l0; l < l1; l++) { col[0] += mR[l]; col[1] += mG[l]; col[2] += mB[l]; }
      col[0] /= l1 - l0; col[1] /= l1 - l0; col[2] /= l1 - l0;
      if (l1 - l0 <= maxBand && dividerColour(col)) {
        var cl = [contrast(l0 - 1, col), contrast(l0 - 2, col), contrast(l0 - 3, col)];
        var cr = [contrast(l1, col), contrast(l1 + 1, col), contrast(l1 + 2, col)];
        var left = max(cl[0], cl[1], cl[2]), right = max(cr[0], cr[1], cr[2]);
        var sc = min(left, right);
        if (sc >= 10 && (!best || sc > best.score)) {
          var g0 = l0, g1 = l1;
          for (var t2 = 0; t2 < 2 && cl[t2] < 0.55 * left; t2++) g0--;
          for (var t3 = 0; t3 < 2 && cr[t3] < 0.55 * right; t3++) g1++;
          var base = vertical ? x0 : y0;
          best = { a: base + g0, b: base + g1, score: sc, vertical: vertical };
        }
      }
      l0 = l1;
    }
    return best;
  }

  /* ------------------------------------------------------------ 9. hint */

  function polygonBox(poly, W, H) {
    if (!poly || poly.length < 3) return null;
    var x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    for (var i = 0; i < poly.length; i++) {
      var p = poly[i];
      if (!p || !isFinite(p[0]) || !isFinite(p[1])) continue;
      if (p[0] < x0) x0 = p[0]; if (p[0] > x1) x1 = p[0];
      if (p[1] < y0) y0 = p[1]; if (p[1] > y1) y1 = p[1];
    }
    if (!(x1 > x0 && y1 > y0)) return null;
    x0 = max(0, min(W - 1, floor(x0))); y0 = max(0, min(H - 1, floor(y0)));
    x1 = max(x0 + 1, min(W, ceil(x1))); y1 = max(y0 + 1, min(H, ceil(y1)));
    return rect(x0, y0, x1 - x0, y1 - y0);
  }

  /** Fraction of box b that box h covers. */
  function coverage(b, h) {
    var x0 = max(b.x, h.x), y0 = max(b.y, h.y);
    var x1 = min(b.x + b.w, h.x + h.w), y1 = min(b.y + b.h, h.y + h.h);
    return b.w * b.h > 0 ? max(0, x1 - x0) * max(0, y1 - y0) / (b.w * b.h) : 0;
  }

  /**
   * Straight seam between two collage photos inside region R, searched at
   * positions lo..hi (exclusive edge coordinates: the seam at p lies between
   * pixels p-1 and p) - vertical seams when `vertical`. Per sampled line the
   * nearest unmasked pixels before and after p are compared; stroke pixels
   * are skipped, so a seam a red loop runs along still shows through. A seam
   * runs across the whole region, photo texture does not: the strength of a
   * position is the median difference over all lines (at least minScore,
   * default 16), and a share minFrac (default 70%) of the lines must show a
   * clear step there.
   * Returns { a, b, score } - the band [a, b) between the two photos (a == b
   * when they touch) - or null.
   */
  function findSeam(W, D, avoid, R, vertical, lo, hi, minFrac, minScore) {
    minFrac = minFrac || 0.7;
    minScore = minScore || 16;
    lo = max(lo, vertical ? R.x + 1 : R.y + 1);
    hi = min(hi, vertical ? R.x + R.w - 1 : R.y + R.h - 1);
    var nPos = hi - lo + 1;
    if (nPos < 3) return null;
    var reach = 24;                                   // how far a stroke may hide pixels
    var A0 = vertical ? R.y : R.x, A = vertical ? R.h : R.w;
    var aLo = A0 + floor(A * 0.06), aHi = A0 + A - floor(A * 0.06);
    var nLines = min(160, aHi - aLo);
    if (nLines < 8) return null;
    var s0 = max(vertical ? R.x : R.y, lo - reach), s1 = min(vertical ? R.x + R.w : R.y + R.h, hi + reach);
    var L = s1 - s0, prevOk = new I32(L), nextOk = new I32(L);
    var diff = new U8(nPos * nLines), known = new I32(nPos), steps = new I32(nPos);
    var visSteps = new I32(nPos), visKnown = new I32(nPos), k, t, p;
    // every 12th line first: most searches (a single photo, no seam) end there
    var order = [], nFirst;
    for (k = 0; k < nLines; k += 12) order.push(k);
    nFirst = order.length;
    for (k = 0; k < nLines; k++) if (k % 12) order.push(k);
    for (var j = 0; j < nLines; j++) {
      if (j === nFirst) {
        var any = false;
        for (p = 0; p < nPos && !any; p++) any = known[p] > 0 && steps[p] >= (minFrac - 0.2) * known[p];
        if (!any) return null;
      }
      k = order[j];
      var line = aLo + floor((k + 0.5) * (aHi - aLo) / nLines);
      var base = vertical ? line * W : line, stride = vertical ? 1 : W;
      // nearest unmasked pixel at or before / at or after every position
      var last = -1;
      for (t = 0; t < L; t++) { if (!avoid || !avoid[base + (s0 + t) * stride]) last = t; prevOk[t] = last; }
      last = -1;
      for (t = L - 1; t >= 0; t--) { if (!avoid || !avoid[base + (s0 + t) * stride]) last = t; nextOk[t] = last; }
      for (p = 0; p < nPos; p++) {
        var rel = lo + p - s0, pa = rel > 0 ? prevOk[rel - 1] : -1, pb = rel < L ? nextOk[rel] : -1;
        if (pa < 0 || pb < 0 || rel - pa > reach || pb - rel > reach) continue;
        var oa = (base + (s0 + pa) * stride) << 2, ob = (base + (s0 + pb) * stride) << 2;
        var d = abs(D[oa] - D[ob]), d1 = abs(D[oa + 1] - D[ob + 1]), d2 = abs(D[oa + 2] - D[ob + 2]);
        if (d1 > d) d = d1;
        if (d2 > d) d = d2;
        diff[p * nLines + known[p]] = d;
        known[p]++;
        if (d >= 16) steps[p]++;
        if (pa === rel - 1 && pb === rel) { visKnown[p]++; if (d >= 16) visSteps[p]++; }
      }
    }
    // median per position by counting (differences are bytes)
    var score = new F32(nPos), cnt = new I32(256), best = -1, bestS = 0;
    for (p = 0; p < nPos; p++) {
      var n = known[p];
      if (n < nLines * 0.5) continue;
      cnt.fill(0);
      for (t = 0; t < n; t++) cnt[diff[p * nLines + t]]++;
      var acc = 0, med = 0;
      while (med < 255 && acc + cnt[med] <= n >> 1) acc += cnt[med++];
      score[p] = med;
      if (steps[p] >= minFrac * n && med > bestS) { bestS = med; best = p; }
    }
    if (best < 0 || bestS < minScore) return null;
    // the seam must stand out from the rest of the window
    var sorted = Array.prototype.slice.call(score).sort(function (u, v) { return u - v; });
    if (bestS < 2.5 * max(4, sorted[floor(nPos * 0.3)])) return null;
    // Localise. Where a stroke covers the seam every position under it
    // compares the two photos, so the strength plateaus; lines on which the
    // seam is in plain view pin it down. A divider band shows as two steps
    // a few pixels apart with a valley between.
    var gapMax = max(4, round((vertical ? R.w : R.h) * 0.02)) + 2;
    var pl = best, pr = best;
    while (pl > 0 && score[pl - 1] >= 0.6 * bestS) pl--;
    while (pr < nPos - 1 && score[pr + 1] >= 0.6 * bestS) pr++;
    var w0 = max(0, pl - gapMax), w1 = min(nPos - 1, pr + gapMax), prof = score, vMax = 0;
    for (p = w0; p <= w1; p++) vMax = max(vMax, visSteps[p]);
    if (vMax >= max(6, nLines * 0.08)) { prof = visSteps; best = w0; for (p = w0; p <= w1; p++) if (visSteps[p] > visSteps[best]) best = p; }
    else best = (pl + pr) >> 1;                       // hidden: the stroke was drawn along it
    var top = prof[best], a = best, b = best;
    for (p = max(w0, best - gapMax); p <= min(w1, best + gapMax); p++) {
      if (abs(p - best) < 2 || prof[p] < 0.5 * top) continue;
      var valley = Infinity;
      for (t = min(p, best) + 1; t < max(p, best); t++) valley = min(valley, prof[t]);
      if (valley < 0.5 * min(prof[p], top)) { if (p < a) a = p; if (p > b) b = p; }
    }
    return { a: lo + a, b: lo + b, score: bestS };
  }

  /**
   * A hint that leaves a large slab of region R outside it, across a
   * straight collage seam, points at the photo on its side of the seam.
   * Each hint side well inside R is searched for a seam from a little
   * outside the side (a loop drawn on the photo) to well inside it (a loop
   * that overshoots onto the neighbour). Returns the sub-box or null.
   */
  function hintSubBox(W, D, avoid, R, hb) {
    var e = [R.x, R.y, R.x + R.w, R.y + R.h], cut = false;
    for (var side = 0; side < 4; side++) {
      var vertical = side === 0 || side === 2;
      var r0 = vertical ? R.x : R.y, ext = vertical ? R.w : R.h;
      var hs = side === 0 ? hb.x : side === 1 ? hb.y : side === 2 ? hb.x + hb.w : hb.y + hb.h;
      var hExt = vertical ? hb.w : hb.h;
      // the slab cut off must be a photo-sized share of the region
      var minSlab = max(16, floor(ext * 0.2));
      var inward = side < 2 ? 1 : -1;
      var lo, hi;
      if (side < 2) { lo = hs - floor(hExt * 0.2); hi = hs + floor(hExt * 0.4); }
      else { lo = hs - floor(hExt * 0.4); hi = hs + floor(hExt * 0.2); }
      lo = max(lo, r0 + minSlab); hi = min(hi, r0 + ext - minSlab);
      if (hi - lo < 2) continue;
      var seam = findSeam(W, D, avoid, R, vertical, lo, hi);
      if (!seam) continue;
      // the target starts after the band on its own side
      var pos = inward > 0 ? seam.b : seam.a;
      var slab = vertical
        ? (side === 0 ? rect(R.x, R.y, pos - R.x, R.h) : rect(pos, R.y, R.x + R.w - pos, R.h))
        : (side === 1 ? rect(R.x, R.y, R.w, pos - R.y) : rect(R.x, pos, R.w, R.y + R.h - pos));
      if (coverage(slab, hb) > 0.45) continue;      // the hint wants that slab too
      e[side] = pos;
      cut = true;
    }
    if (!cut || e[2] - e[0] < 16 || e[3] - e[1] < 16) return null;
    var sub = rect(e[0], e[1], e[2] - e[0], e[3] - e[1]);
    return coverage(sub, hb) >= 0.6 ? sub : null;
  }

  /** Whether box S holds a collage seam well inside it (more than one photo). */
  function innerSeam(W, D, avoid, S) {
    return !!(findSeam(W, D, avoid, S, true, S.x + floor(S.w * 0.2), S.x + S.w - floor(S.w * 0.2)) ||
      findSeam(W, D, avoid, S, false, S.y + floor(S.h * 0.2), S.y + S.h - floor(S.h * 0.2)));
  }

  /**
   * Index of the candidate the hint points at. A hint that clearly targets
   * one photo of a collage - most of one photo, little of the others - adds
   * that photo as its own candidate and picks it; one that encloses most of
   * several photos keeps the collage. The photo comes from the collage's
   * parts, or, where a stroke hides the dividers, from a seam next to the
   * hint's sides. Parts can also be over-split (a uniform band inside a
   * photo looks like a divider): when the hint covers several of them, the
   * collage itself is cut at the seams next to the hint, as long as what
   * remains holds no seam of its own.
   */
  function applyHint(cands, hintBox, W, D, avoid) {
    var bestI = -1, bestV = 0.05;
    for (var k = 0; k < cands.length; k++) {
      var v = iou(cands[k], hintBox);
      if (v > bestV) { bestV = v; bestI = k; }
    }
    if (bestI < 0) return -1;
    var C = cands[bestI], parts = C.parts.length > 1 ? C.parts : [C];
    var covs = parts.map(function (p) { return coverage(p, hintBox); });
    var order = covs.map(function (_, i) { return i; }).sort(function (i, j) { return covs[j] - covs[i]; });
    var c1 = covs[order[0]], c2 = order.length > 1 ? covs[order[1]] : 0;
    if (c1 < 0.3) return bestI;
    var target = null;
    if (c2 < 0.5) {
      var region = parts[order[0]];
      target = hintSubBox(W, D, avoid, region, hintBox);
      if (!target && region !== C && c1 >= 0.55 && c1 - c2 >= 0.25) target = region;
    }
    if (!target && parts.length > 1) {
      var sub = hintSubBox(W, D, avoid, C, hintBox);
      if (sub && !innerSeam(W, D, avoid, sub)) target = sub;
    }
    if (!target) return bestI;
    cands.push({ x: target.x, y: target.y, w: target.w, h: target.h, score: 0.8, kind: "photo", parts: [] });
    return cands.length - 1;
  }

  /* ------------------------------------------------------------ layout */

  /**
   * One background hypothesis: the content grid, its XY-cut leaves, the
   * photo blocks among them grouped into collages, and how many marks stand
   * on the background (see uiMarks).
   */
  function layout(W, H, D, marks, bgc) {
    var avoid = marks.avoid, c = max(1, ceil(max(W, H) / GRID_MAX));
    var stroke = makeStrokeModel(marks, bgc);
    var grid = buildGrid(W, H, D, bgc, avoid, stroke, c);
    var M = contentMask(grid);
    var minDim = min(W, H), minSide = max(24, minDim * MIN_SIDE);
    var leaves = xyCut(M, grid.gw, grid.gh, max(2, floor(minSide / c)));
    var photos = [];
    for (var i = 0; i < leaves.length; i++) {
      var b = leaves[i];
      if (b.small) continue;
      var pw = (b.x1 - b.x0) * c, ph = (b.y1 - b.y0) * c;
      if (pw < minSide || ph < minSide || pw * ph < W * H * MIN_AREA) continue;
      b.stats = blockStats(M, grid, b);
      if (isPhotoBlock(b.stats) && !flatBlock(grid, M, b)) { b.photo = true; photos.push(b); }
    }
    var groups = groupBlocks(photos, max(2, ceil(max(2 * c, minDim * 0.015) / c)));
    var marksOn = uiMarks(W, H, D, bgc, grid, M, leaves, groups);
    return { c: c, stroke: stroke, grid: grid, M: M, leaves: leaves, groups: groups, ui: marksOn.ui, solid: marksOn.solid };
  }

  /**
   * Evidence that a colour is a post's background rather than a flat part
   * of a photograph: marks standing on it. Scores the small leaves outside
   * the photo groups that are mostly background pixels carrying strong
   * strokes: a text line (wide, short, its strokes alternating with
   * background every few pixels) scores 2 - one caption line is enough -
   * and any other mark (icon, avatar, button) 2/3. Also reports whether a
   * large non-photo leaf has substantial content (a photograph's non-flat
   * part, such as a subject in front of a backdrop).
   */
  function uiMarks(W, H, D, bgc, grid, M, leaves, groups) {
    var gw = grid.gw, c = grid.c, ui = 0, solid = false;
    for (var i = 0; i < leaves.length; i++) {
      var b = leaves[i];
      if (b.photo) continue;
      var cx = (b.x0 + b.x1) / 2, cy = (b.y0 + b.y1) / 2, inside = false;
      for (var g = 0; g < groups.length && !inside; g++) {
        var G = groups[g];
        inside = cx >= G.x0 - 1 && cx <= G.x1 + 1 && cy >= G.y0 - 1 && cy <= G.y1 + 1;
      }
      if (inside) continue;
      var px = 0, bgp = 0, on = 0, peak = 0;
      for (var y = b.y0; y < b.y1; y++) for (var x = b.x0; x < b.x1; x++) {
        var k = y * gw + x;
        px += grid.n[k]; bgp += grid.nbg[k];
        if (M[k]) { on++; if (grid.dMean[k] > peak) peak = grid.dMean[k]; }
      }
      if (!px || on < 2) continue;
      var bw = (b.x1 - b.x0) * c, bh = (b.y1 - b.y0) * c;
      if (bh > H * 0.1 || bw * bh > W * H * 0.06) {
        if (on * c * c >= W * H * MIN_AREA) solid = true;
        continue;
      }
      if (bgp / px < 0.3 || peak < 40) continue;
      ui += bw >= 3 * bh && strokeRate(W, H, D, bgc, b, c) >= 0.05 ? 2 : 2 / 3;
    }
    return { ui: ui, solid: solid };
  }

  /** Background/stroke alternations per pixel along three rows of a leaf. */
  function strokeRate(W, H, D, bgc, b, c) {
    var x0 = b.x0 * c, x1 = min(W, b.x1 * c), y0 = b.y0 * c, h = min(H, b.y1 * c) - y0, n = 0;
    for (var r = 1; r <= 3; r++) {
      var y = y0 + floor(h * (0.25 + r * 0.125)), prev = false;
      for (var x = x0; x < x1; x++) {
        var on = maxChanDiff(D, (y * W + x) << 2, bgc) > 40;
        if (on !== prev && x > x0) n++;
        prev = on;
      }
    }
    return n / (3 * max(1, x1 - x0));
  }

  /**
   * A photo on a typical, noise-free post background whose edges away from
   * the image border are straight cuts (most sampled lines agree).
   */
  function letterboxed(cand, bg, W, H) {
    if (!typicalBackground(bg.color) || bg.flat < 0.85) return false;
    var atBorder = [cand.x <= 1, cand.y <= 1, cand.x + cand.w >= W - 1, cand.y + cand.h >= H - 1], inner = 0;
    for (var s = 0; s < 4; s++) {
      if (atBorder[s]) continue;
      inner++;
      if (cand.cons[s] < 0.6) return false;
    }
    return inner > 0;
  }

  /* ------------------------------------------------------------ detect */

  function detect(img, opts) {
    opts = opts || {};
    var W = img.width, H = img.height, D = img.data;
    var dbg = opts.debug ? { times: {} } : null, tm = Date.now();
    function lap(k) { if (dbg) { var t = Date.now(); dbg.times[k] = t - tm; tm = t; } }

    var marks = findMarks(W, H, D);
    lap("marks");
    var avoid = marks.avoid;
    var bgs = findBackground(W, H, D, avoid);
    lap("bg");
    var result = {
      width: W, height: H, candidates: [], primary: -1, wholeImage: false,
      marks: { baked: marks.baked, box: marks.box, mask: marks.mask },
      hint: { source: null, box: null },
    };
    var hintBox = opts.hint ? polygonBox(opts.hint, W, H) : null;
    if (hintBox) result.hint = { source: "overlay", box: hintBox };
    else if (marks.baked && marks.box) { hintBox = marks.box; result.hint = { source: "baked", box: hintBox }; }
    if (dbg) { dbg.bgs = bgs; result.debug = dbg; }

    function whole() {
      result.wholeImage = true;
      result.candidates = [{ x: 0, y: 0, w: W, h: H, score: 0.9, kind: "photo", parts: [] }];
      result.primary = 0;
      return result;
    }
    // Background hypotheses: flat colours covering (most of) an image side,
    // typical noise-free post colours first, then the largest. None: a
    // photograph. The first colour with marks on it wins - a meme's thin
    // caption band over a photo with large flat areas of other colours is
    // laid out on the band's colour.
    var hyps = bgs.filter(function (b) { return b.margin >= 0.8; });
    function postLike(b) { return typicalBackground(b.color) && b.flat >= 0.85 ? 1 : 0; }
    hyps.sort(function (p, q) { return postLike(q) - postLike(p) || q.share - p.share; });
    if (!hyps.length) return whole();
    var L = null, bg = null;
    for (var h = 0; h < hyps.length && h < 2; h++) {
      var Lh = layout(W, H, D, marks, hyps[h].color);
      if (dbg) (dbg.hyps = dbg.hyps || []).push({ color: hyps[h].color, ui: Lh.ui, solid: Lh.solid, leaves: Lh.leaves.length, groups: Lh.groups.length });
      if (!L || Lh.ui >= 2) { L = Lh; bg = hyps[h]; }
      if (Lh.ui >= 2) break;
    }
    if (dbg) { dbg.bg = bg; dbg.ui = L.ui; }
    lap("layout");

    var c = L.c, groups = L.groups, stroke = L.stroke;
    var test = makePixelTest(D, bg.color, avoid, stroke, PIX_CONTENT);
    var cands = [], i;
    for (var g = 0; g < groups.length; g++) {
      var G = groups[g];
      var coarse = rect(G.x0 * c, G.y0 * c, min(W, G.x1 * c) - G.x0 * c, min(H, G.y1 * c) - G.y0 * c);
      var ref = refineBox(W, H, test, coarse, c, bg.color, D);
      var box = ref.box;
      var parts = splitParts(W, D, avoid, stroke, bg.color, box);
      var consMean = (ref.cons[0] + ref.cons[1] + ref.cons[2] + ref.cons[3]) / 4;
      cands.push({
        x: box.x, y: box.y, w: box.w, h: box.h,
        score: round(100 * min(1, 0.4 + 0.6 * consMean)) / 100,
        kind: parts.length > 1 ? "collage" : "photo",
        parts: parts.length > 1 ? parts : [],
        cons: ref.cons,
      });
    }
    lap("refine");
    cands.sort(function (p, q) { return q.w * q.h - p.w * p.h; });
    // Whole image only when nothing marks a post: no text or UI on the
    // background. Without any, flat bands are still a post background when
    // they look like one - a typical, noise-free colour that the photo meets
    // in straight edges (a letterboxed photo); otherwise they are part of
    // the photograph (sky, wall, studio backdrop).
    if (!cands.length) {
      var on = 0;
      for (i = 0; i < L.M.length; i++) on += L.M[i];
      if (on > 0.45 * L.M.length || (L.ui < 2 && L.solid)) return whole();
    } else if (L.ui < 2 && !letterboxed(cands[0], bg, W, H)) return whole();
    for (i = 0; i < cands.length; i++) delete cands[i].cons;
    result.candidates = cands;
    if (cands.length) result.primary = 0;
    if (hintBox && cands.length) {
      var hp = applyHint(cands, hintBox, W, D, avoid);
      if (hp >= 0) result.primary = hp;
    }
    lap("hint");
    if (dbg) { dbg.c = c; dbg.gw = L.grid.gw; dbg.gh = L.grid.gh; dbg.M = L.M; dbg.grid = L.grid; dbg.leaves = L.leaves; dbg.groups = groups; }
    return result;
  }

  /* ------------------------------------------------------------ retouch */

  // Unmarked slivers at most this wide between a stroke and the crop border
  // are not used as fill sources (see retouch).
  var RETOUCH_EDGE = 3;

  /**
   * Crops `box` (clipped to the image) and repairs the red-mark pixels:
   * result.marks.mask dilated by 1px for anti-aliasing. Each repaired pixel
   * is interpolated from the nearest unmarked pixels to its left, right,
   * above and below inside the crop, with inverse-distance weights (linear
   * interpolation along each axis); each source is the mean of the unmarked
   * pixels across the search direction (3 taps), so JPEG noise does not
   * streak through the repair. Deterministic, no synthesis, and every other
   * pixel is copied byte for byte.
   *
   * Pixels outside the crop are never used, nor are unmarked slivers of at
   * most RETOUCH_EDGE px between the mask and the crop border: a stroke that
   * runs along a photo edge is filled from the photo side, not from the
   * strip of background the box may have caught beyond the edge.
   */
  function retouch(img, box, result) {
    var W = img.width, H = img.height, D = img.data;
    var bx = max(0, box.x | 0), by = max(0, box.y | 0);
    var bw = max(0, min(W, (box.x | 0) + (box.w | 0)) - bx), bh = max(0, min(H, (box.y | 0) + (box.h | 0)) - by);
    var out = new Uint8ClampedArray(bw * bh * 4), x, y, k;
    for (y = 0; y < bh; y++) {
      var so = ((by + y) * W + bx) << 2;
      out.set(D.subarray(so, so + bw * 4), y * bw * 4);
    }
    var res = { width: bw, height: bh, data: out };
    var mask = result && result.marks && result.marks.mask;
    if (!mask || !bw || !bh) return res;

    // pixels to repair, in crop coordinates: mask pixels (also those just
    // outside the crop) dilated by 1px
    var m = new U8(bw * bh), any = false;
    for (var gy = max(0, by - 1), gy1 = min(H - 1, by + bh); gy <= gy1; gy++) {
      for (var gx = max(0, bx - 1), gx1 = min(W - 1, bx + bw); gx <= gx1; gx++) {
        if (!mask[gy * W + gx]) continue;
        any = true;
        var cx = gx - bx, cy = gy - by;
        for (y = max(0, cy - 1); y <= min(bh - 1, cy + 1); y++) {
          for (x = max(0, cx - 1); x <= min(bw - 1, cx + 1); x++) m[y * bw + x] = 1;
        }
      }
    }
    if (!any) return res;

    var EDGE = RETOUCH_EDGE;
    // source value: mean of the unmarked crop pixels among (x, y) and its two
    // neighbours along (ax, ay); written to src[0..2], returns false if none
    var src = [0, 0, 0];
    function sample(sx, sy, ax, ay) {
      var r = 0, g = 0, b = 0, c = 0;
      for (var t = -1; t <= 1; t++) {
        var tx = sx + t * ax, ty = sy + t * ay;
        if (tx < 0 || ty < 0 || tx >= bw || ty >= bh || m[ty * bw + tx]) continue;
        var q = ((by + ty) * W + bx + tx) << 2;
        r += D[q]; g += D[q + 1]; b += D[q + 2]; c++;
      }
      if (!c) return false;
      src[0] = r / c; src[1] = g / c; src[2] = b / c;
      return true;
    }

    // One pass over the rows. Per column, the vertical run of marked pixels
    // the scan is in: its first row and the first unmarked row below it
    // (found once, when the run starts). The unmarked pixels just above and
    // below a run are its vertical sources, unless they are a sliver: the
    // run is the column's first (last) and at most EDGE rows from the border.
    var vStart = new I32(bw), vEnd = new I32(bw), seenT = new U8(bw), upOk = new U8(bw), dnOk = new U8(bw);
    for (y = 0; y < bh; y++) {
      var row = y * bw, firstRun = true;
      for (x = 0; x < bw; x++) {
        if (!m[row + x]) continue;
        var a = x;
        while (x + 1 < bw && m[row + x + 1]) x++;
        var b = x;
        // horizontal sources at a - 1 and b + 1, unless they are slivers
        var L = a - 1, R = b + 1;
        if (firstRun && a <= EDGE) L = -1;
        if (R < bw && bw - 1 - b <= EDGE) {
          for (k = R; k < bw && !m[row + k]; k++);
          if (k === bw) R = bw;
        }
        firstRun = false;
        var hasL = L >= 0 && sample(L, y, 0, 1), lr = src[0], lg = src[1], lb = src[2];
        var hasR = R < bw && sample(R, y, 0, 1), rr = src[0], rg = src[1], rb = src[2];
        for (var px = a; px <= b; px++) {
          k = row + px;
          if (y === 0 || !m[k - bw]) {
            // a vertical run starts here
            var e = y + 1;
            while (e < bh && m[e * bw + px]) e++;
            vStart[px] = y; vEnd[px] = e;
            upOk[px] = y > 0 && (seenT[px] || y > EDGE) ? 1 : 0;
            seenT[px] = 1;
            var ok = e < bh;
            if (ok && bh - e <= EDGE) {
              var f = e;
              while (f < bh && !m[f * bw + px]) f++;
              ok = f < bh;
            }
            dnOk[px] = ok ? 1 : 0;
          }
          var sr = 0, sg = 0, sb = 0, ws = 0, wt;
          if (hasL) { wt = 1 / (px - L); sr += lr * wt; sg += lg * wt; sb += lb * wt; ws += wt; }
          if (hasR) { wt = 1 / (R - px); sr += rr * wt; sg += rg * wt; sb += rb * wt; ws += wt; }
          if (upOk[px] && sample(px, vStart[px] - 1, 1, 0)) {
            wt = 1 / (y - vStart[px] + 1); sr += src[0] * wt; sg += src[1] * wt; sb += src[2] * wt; ws += wt;
          }
          if (dnOk[px] && sample(px, vEnd[px], 1, 0)) {
            wt = 1 / (vEnd[px] - y); sr += src[0] * wt; sg += src[1] * wt; sb += src[2] * wt; ws += wt;
          }
          if (ws > 0) {
            var o = k << 2;
            out[o] = round(sr / ws); out[o + 1] = round(sg / ws); out[o + 2] = round(sb / ws);
          }
        }
      }
    }
    return res;
  }

  window.__igRatioCrop = { detect: detect, retouch: retouch };
})();
