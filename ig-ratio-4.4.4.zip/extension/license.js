/* IG Ratio — licence checking.
 *
 * Keys are signed with ECDSA P-256. Only the PUBLIC key lives here, so a copy
 * of this extension cannot mint new keys — that needs the private key, which
 * stays in the generator and never ships.
 *
 * Be clear-eyed about what this does and doesn't do. An unpacked extension is
 * plain JavaScript on the customer's own machine: anyone willing to open this
 * file can delete the check. What signing buys you is that nobody can forge or
 * share a *valid* key, and that expiry dates hold. It stops casual sharing and
 * keeps honest customers honest. It is not copy protection, and no purely
 * client-side scheme can be. If the revenue matters, the same key should be
 * checked against a server you control.
 */

(() => {
  "use strict";
  if (window.__igRatioLicence) return;

  const PUBLIC_JWK = {"kty": "EC", "crv": "P-256", "x": "icsbTfKFrIPNnsnw83hTGyk6k4EKjCtm30O51FlkA-0", "y": "LTuDw4Gy03PmNDqqgNTTdyH86qTEEoxNFA078aFwfQg", "ext": true, "key_ops": ["verify"]};

  const b64urlToBytes = (s) => {
    const pad = s.replace(/-/g, "+").replace(/_/g, "/");
    const bin = atob(pad + "=".repeat((4 - (pad.length % 4)) % 4));
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  };

  let keyPromise = null;
  function publicKey() {
    if (!keyPromise) {
      keyPromise = crypto.subtle.importKey(
        "jwk", PUBLIC_JWK, { name: "ECDSA", namedCurve: "P-256" }, false, ["verify"]
      );
    }
    return keyPromise;
  }

  const PLANS = { monthly: "Monthly", quarterly: "Quarterly", yearly: "Yearly", lifetime: "Lifetime" };

  /**
   * @param {string} key  "<payload>.<signature>", both base64url
   * @returns {Promise<{ok: boolean, reason?: string, holder?: string, plan?: string,
   *                     expires?: string|null, issued?: string, id?: string}>}
   */
  async function verify(key) {
    const trimmed = String(key || "").trim().replace(/\s+/g, "");
    if (!trimmed) return { ok: false, reason: "Enter a key" };

    const dot = trimmed.indexOf(".");
    if (dot < 1) return { ok: false, reason: "That doesn't look like a key" };

    const payloadPart = trimmed.slice(0, dot);
    const signaturePart = trimmed.slice(dot + 1);

    let payload;
    try {
      payload = JSON.parse(new TextDecoder().decode(b64urlToBytes(payloadPart)));
    } catch (_) {
      return { ok: false, reason: "That key is damaged — check it copied in full" };
    }

    let good = false;
    try {
      good = await crypto.subtle.verify(
        { name: "ECDSA", hash: "SHA-256" },
        await publicKey(),
        b64urlToBytes(signaturePart),
        new TextEncoder().encode(payloadPart)
      );
    } catch (_) {
      return { ok: false, reason: "That key is damaged — check it copied in full" };
    }
    if (!good) return { ok: false, reason: "That key isn't valid" };

    const expires = payload.e && payload.e !== "never" ? payload.e : null;
    if (expires) {
      const end = new Date(`${expires}T23:59:59`);
      if (!isNaN(end) && Date.now() > end.getTime()) {
        return { ok: false, reason: `That subscription ended on ${expires}`, expired: true,
                 holder: payload.n || "", plan: PLANS[payload.p] || payload.p || "" };
      }
    }

    return {
      ok: true,
      holder: payload.n || "",
      plan: PLANS[payload.p] || payload.p || "",
      expires,
      issued: payload.t || "",
      id: payload.i || "",
    };
  }

  window.__igRatioLicence = { verify, PLANS };
})();
